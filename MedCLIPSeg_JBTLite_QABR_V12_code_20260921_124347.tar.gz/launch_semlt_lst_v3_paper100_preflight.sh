#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"

[[ -f datasets/dataloader.py ]] || { echo "[FAIL] missing datasets/dataloader.py"; exit 2; }
[[ -e data ]] || { echo "[FAIL] missing data path"; exit 2; }
[[ -e checkpoints ]] || { echo "[FAIL] missing checkpoints path"; exit 2; }
"${PYTHON}" -c \
  'from datasets.dataloader import DatasetSegmentation, RandomGenerator, ValGenerator; print("[PASS] dataloader import")'
"${PYTHON}" -m py_compile \
  utils/semlt_autozero_transport.py utils/semlt_autozero_loss.py \
  trainers/medclipseg_unimedclip.py train.py test.py \
  tools/test_semlt_lst_v3_contract.py tools/check_semlt_lst_v3_paper100_configs.py
"${PYTHON}" tools/test_semlt_lst_v3_contract.py
"${PYTHON}" tools/check_semlt_lst_v3_paper100_configs.py
echo "[PASS] SemLT-LST v3 PAPER100 preflight"
