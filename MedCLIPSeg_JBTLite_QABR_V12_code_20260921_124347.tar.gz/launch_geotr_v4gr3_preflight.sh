#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
cd "${PROJECT}" || exit 1
"${PYTHON}" -m py_compile utils/multi_hypothesis_composition.py utils/multi_hypothesis_composition_loss.py trainers/medclipseg_unimedclip.py train.py
"${PYTHON}" tools/test_geotr_v4gr3_contract.py
"${PYTHON}" tools/check_geotr_v4gr3_configs.py
"${PYTHON}" tools/test_geotr_v4gr2_contract.py
"${PYTHON}" tools/test_geotr_v4g_optimizer_ownership.py
"${PYTHON}" tools/test_geotr_v4gr3_shared_trajectory_contract.py
"${PYTHON}" tools/test_geotr_v4gr2_shared_trajectory_contract.py
# Historical regressions remain mandatory.
"${PYTHON}" tools/test_geotr_v4f_contract.py
"${PYTHON}" tools/test_geotr_v4e_contract.py
"${PYTHON}" tools/test_geotr_v4d_contract.py
"${PYTHON}" tools/test_geotr_v4c_contract.py
echo "[PASS] GEOTR-V4G-R3 preflight finished"
