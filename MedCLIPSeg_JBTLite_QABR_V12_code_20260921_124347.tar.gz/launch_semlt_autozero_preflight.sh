#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"

cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"

echo "============================================================"
echo "[1/3] AutoZero configuration/integration contract"
echo "============================================================"
"${PYTHON}" tools/check_semlt_autozero_configs.py

echo "============================================================"
echo "[2/3] AutoZero mathematical/gradient contract"
echo "============================================================"
"${PYTHON}" tools/test_semlt_autozero_contract.py

echo "============================================================"
echo "[3/3] Python compilation"
echo "============================================================"
"${PYTHON}" -m py_compile \
  utils/semlt_autozero_transport.py \
  utils/semlt_autozero_loss.py \
  trainers/medclipseg_unimedclip.py \
  train.py \
  test.py

printf '\n[PASS] SemLT-AutoZero preflight complete\n'
