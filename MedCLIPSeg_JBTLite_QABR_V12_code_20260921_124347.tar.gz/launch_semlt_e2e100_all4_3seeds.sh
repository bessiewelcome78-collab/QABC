#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPUS="${GPUS:-0,1,2,3}"
EXP_ID="${EXP_ID:-$(date +%Y%m%d_%H%M%S)}"
for seed in 42 123 789; do
  echo "================ SEED ${seed} ================"
  PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPUS="${GPUS}" SEED="${seed}" EXP_ID="${EXP_ID}" \
    bash "${PROJECT}/launch_semlt_e2e100_all4_seed.sh"
done
