#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
cd "${PROJECT}" || exit 1
SEED="${SEED:-42}"
GPU_A0="${GPU_A0:-0}"; GPU_A1="${GPU_A1:-1}"; GPU_A2="${GPU_A2:-2}"; GPU_A3="${GPU_A3:-3}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs
GPU="${GPU_A0}" SEED="${SEED}" bash launch_geotr_c2r_a0_formal150.sh > "logs/GEOTR_C2R_A0_FORMAL150_driver_${STAMP}.log" 2>&1 & P0=$!
GPU="${GPU_A1}" SEED="${SEED}" bash launch_geotr_c2r_a1_formal150.sh > "logs/GEOTR_C2R_A1_FORMAL150_driver_${STAMP}.log" 2>&1 & P1=$!
GPU="${GPU_A2}" SEED="${SEED}" bash launch_geotr_c2r_a2_formal150.sh > "logs/GEOTR_C2R_A2_FORMAL150_driver_${STAMP}.log" 2>&1 & P2=$!
GPU="${GPU_A3}" SEED="${SEED}" bash launch_geotr_c2r_a3_formal150.sh > "logs/GEOTR_C2R_A3_FORMAL150_driver_${STAMP}.log" 2>&1 & P3=$!
FAIL=0
for p in "$P0" "$P1" "$P2" "$P3"; do wait "$p" || FAIL=1; done
[[ "$FAIL" == 0 ]] || { echo "[ERROR] one or more C2R FORMAL150 runs failed"; exit 1; }
echo "[PASS] GEOTR-C2R A0-A3 FORMAL150 finished"
