#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"; SEED="${SEED:-42}"
cd "${PROJECT}" || exit 1
export TOKENIZERS_PARALLELISM=false
export PYTHONPATH="${PROJECT}:${PYTHONPATH:-}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs runs
LOG="logs/GEOTR_AEFR_IFR_A3_DIAG20_seed${SEED}_gpu${GPU}_${STAMP}.log"
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "configs/BUSI_GEOTR_AEFR_IFR_A3_DIAG20.yaml" \
  --seed "${SEED}" \
  --output-dir "runs/GEOTR_AEFR_IFR_A3_DIAG20_seed${SEED}_${STAMP}" \
  2>&1 | tee "${LOG}"
"${PYTHON}" tools/diagnose_geotr_aefr_log.py "${LOG}" --tail 5 || true
echo "[PASS] GEOTR-AEFR IFR_A3 DIAG20 finished: ${LOG}"
