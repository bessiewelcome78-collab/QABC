#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
PROTOCOL="${PROTOCOL:-paper100}"
MODE="${MODE:-fresh}"
RUN_DIR="${RUN_DIR:-}"
RUN_TAG="${RUN_TAG:-}"
ALLOW_TEST_RETRY="${ALLOW_TEST_RETRY:-0}"
cd "${PROJECT}"

[[ -f launch_geotr_m1_formal543_pipeline.sh ]] || {
  echo "[FAIL] FORMAL54.3 pipeline is missing; reinstall the FORMAL543 package"; exit 2;
}

STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p logs
SUPERVISOR_LOG="logs/GEOTR_M1_FORMAL543_${PROTOCOL}_${MODE}_seed${SEED}_gpu${GPU}_${STAMP}.nohup.log"
PID_FILE="${SUPERVISOR_LOG%.log}.pid"

nohup env \
  PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPU="${GPU}" SEED="${SEED}" \
  PROTOCOL="${PROTOCOL}" MODE="${MODE}" RUN_DIR="${RUN_DIR}" RUN_TAG="${RUN_TAG}" \
  ALLOW_TEST_RETRY="${ALLOW_TEST_RETRY}" \
  bash "${PROJECT}/launch_geotr_m1_formal543_pipeline.sh" \
  > "${SUPERVISOR_LOG}" 2>&1 < /dev/null &
PID=$!
echo "${PID}" > "${PID_FILE}"

echo "[STARTED] FORMAL54.3 pid=${PID}"
echo "          log=${SUPERVISOR_LOG}"
echo "          status: ps -p ${PID} -o pid,etime,stat,cmd"
echo "          follow: tail -f ${SUPERVISOR_LOG}"
