#!/usr/bin/env bash
set -Eeuo pipefail

# Sequential all-dataset Paper100 driver.  Dataset order is intentionally fixed
# to the requested BUSI -> Kvasir -> ISIC -> BTMRI order.  With multiple seeds,
# every seed completes all four datasets before the next seed begins.

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEEDS="${SEEDS:-42}"
DATASETS="${DATASETS:-BUSI Kvasir ISIC BTMRI}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MASTER_ROOT="${MASTER_ROOT:-${PROJECT}/runs/OACD_R3_HCRV_FORMAL100_${ROOT_ID}}"

if [[ "${ALLOW_FORMAL100:-0}" != "1" ]]; then
  echo "Set ALLOW_FORMAL100=1 only after reviewing the DIAG20 readiness report." >&2
  exit 9
fi

cd "${PROJECT}"
[[ -x "${PYTHON}" ]] || { echo "python is not executable: ${PYTHON}" >&2; exit 2; }
[[ -f datasets/dataloader.py ]] || { echo "missing datasets/dataloader.py" >&2; exit 3; }
[[ -s open_clip_lib/bpe_simple_vocab_16e6.txt.gz ]] || {
  echo "missing open_clip_lib/bpe_simple_vocab_16e6.txt.gz" >&2; exit 3;
}

for dataset in ${DATASETS}; do
  case "${dataset}" in
    BUSI|Kvasir|ISIC|BTMRI) ;;
    *) echo "Unsupported dataset in DATASETS: ${dataset}" >&2; exit 4 ;;
  esac
done

export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
"${PYTHON}" tools/check_oacd_r3_static.py
"${PYTHON}" tools/test_oacd_r3_hcrv_contract.py
"${PYTHON}" -c "import train; print('[PASS] train.py complete import')"

mkdir -p "${MASTER_ROOT}"
{
  echo "root_id=${ROOT_ID}"
  echo "master_root=${MASTER_ROOT}"
  echo "datasets=${DATASETS}"
  echo "seeds=${SEEDS}"
  echo "gpu=${GPU}"
  echo "python=${PYTHON}"
  echo "started_at=$(date --iso-8601=seconds)"
  sha256sum configs/ucfnrt_oacd_r3/OACD_R3_HCRV_PAPER100.yaml
} > "${MASTER_ROOT}/FORMAL100_MANIFEST.txt"

for seed in ${SEEDS}; do
  [[ "${seed}" =~ ^[0-9]+$ ]] || { echo "Invalid seed: ${seed}" >&2; exit 4; }
  for dataset in ${DATASETS}; do
    echo "================================================================================"
    echo "FORMAL100 START | dataset=${dataset} | seed=${seed} | root=${MASTER_ROOT}"
    echo "================================================================================"
    PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPU="${GPU}" \
      DATASET="${dataset}" SEED="${seed}" ROOT_ID="${ROOT_ID}" \
      MASTER_ROOT="${MASTER_ROOT}" ALLOW_FORMAL100=1 \
      bash "${PROJECT}/launch_oacd_r3_hcrv_paper100_one_dataset.sh"
  done
done

date --iso-8601=seconds > "${MASTER_ROOT}/ALL4_COMPLETE"
echo "OACD-R3-HCRV all requested Formal100 runs complete: ${MASTER_ROOT}"
