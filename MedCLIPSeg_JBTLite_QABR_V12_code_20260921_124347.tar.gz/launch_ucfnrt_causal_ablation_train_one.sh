#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:?DATASET required}"
VARIANT="${VARIANT:?VARIANT required}"
GPU="${GPU:?physical GPU index required}"
SEED="${SEED:-42}"
ROOT_ID="${ROOT_ID:?ROOT_ID required}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"
case "$DATASET" in BUSI|BTMRI|ISIC|Kvasir) ;; *) echo "[FAIL] bad DATASET=$DATASET"; exit 2;; esac
case "$VARIANT" in NO_POSTERIOR|NO_RAY|DIRECT_SIGNED|SEG_ONLY) ;; *) echo "[FAIL] bad VARIANT=$VARIANT"; exit 2;; esac
cd "$PROJECT"; export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"; export TOKENIZERS_PARALLELISM=false
export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True}"; unset PYTORCH_CUDA_ALLOC_CONF 2>/dev/null || true
CONFIG="configs/ucfnrt_causal_ablation/${DATASET}_${VARIANT}_PAPER100.yaml"
RUN_TAG="SEMLT_UCFNRT_ABL_${VARIANT}_${DATASET}"
RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"
RUN_DIR="${PROJECT}/runs/UCFNRT_CAUSAL_ABL_${ROOT_ID}/seed${SEED}/${DATASET}/${VARIANT}"
STATE_DIR="${RUN_DIR}/formal_state"; mkdir -p "$PROJECT/logs"
SUCCESS="${STATE_DIR}/TRAIN_SUCCESS.lock"
MANIFEST="${STATE_DIR}/TRAIN_MANIFEST.json"
LOG="${PROJECT}/logs/UCFNRT_ABL_${ROOT_ID}_${DATASET}_${VARIANT}_S${SEED}.train.log"
if [[ -f "$SUCCESS" ]]; then echo "[SKIP PASS] $DATASET $VARIANT already trained"; exit 0; fi
[[ ! -e "${RUN_DIR}/FORMAL_TEST_OPENED.lock" ]] || { echo "[FAIL] test already opened in incomplete run: $RUN_DIR"; exit 3; }
# Fail closed rather than silently changing batch/MC.
FREE="$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | awk -F',' -v g="$GPU" '$1+0==g{gsub(/ /,"",$2);print $2;exit}')"
[[ -n "$FREE" ]] || { echo "[FAIL] GPU $GPU not found"; exit 4; }
if (( FREE < MIN_FREE_MIB )); then echo "[FAIL] GPU$GPU free=${FREE}MiB < ${MIN_FREE_MIB}MiB"; exit 5; fi
if [[ "${QUEUE_LOCK_HELD:-0}" != 1 ]] && command -v flock >/dev/null 2>&1; then
  exec 9>"${PROJECT}/.ucfnrt_causal_ablation_gpu${GPU}.lock"; flock -n 9 || { echo "[FAIL] GPU$GPU ablation lock busy"; exit 6; }
fi
# Archive an incomplete attempt before a clean restart.
if [[ -d "$RUN_DIR" && ! -f "$SUCCESS" ]]; then
  ARCH="${PROJECT}/runs/UCFNRT_CAUSAL_ABL_${ROOT_ID}/seed${SEED}/${DATASET}/failed_attempts/${VARIANT}_$(date +%Y%m%d_%H%M%S)"
  mkdir -p "$(dirname "$ARCH")"; mv "$RUN_DIR" "$ARCH"
  echo "[RECOVER] archived incomplete attempt -> $ARCH"
fi
mkdir -p "$STATE_DIR"
cat <<EOF
================================================================================
[UC-FNRT CAUSAL ABLATION TRAIN]
DATASET=$DATASET VARIANT=$VARIANT GPU=$GPU SEED=$SEED
CONFIG=$CONFIG
RUN_DIR=$RUN_DIR
LOCKED: epochs=100 batch=24 trainMC=10 testMC=30 radius=8 last-epoch
TEST STATUS: SEALED (this script never calls test.py)
================================================================================
EOF
CUDA_VISIBLE_DEVICES="$GPU" "$PYTHON" -u train.py --config-file "$CONFIG" --seed "$SEED" --output-dir "$RUN_DIR" 2>&1 | tee "$LOG"
CKPT="${RUN_DIR}/${DATASET}/trained_models/seed${SEED}/${RUN_NAME}_last_epoch.pth"
[[ -f "$CKPT" ]] || { echo "[FAIL] last_epoch checkpoint missing: $CKPT"; exit 10; }
BASE_SHA="$($PYTHON tools/ucfnrt_base_state_hash.py "$CKPT")"
CKPT_SHA="$(sha256sum "$CKPT" | awk '{print $1}')"
CONFIG_SHA="$(sha256sum "$CONFIG" | awk '{print $1}')"
TRANSPORT_SHA="$(sha256sum utils/semlt_autozero_transport.py | awk '{print $1}')"
LOSS_SHA="$(sha256sum utils/semlt_autozero_loss.py | awk '{print $1}')"
"$PYTHON" - "$MANIFEST" "$DATASET" "$VARIANT" "$SEED" "$GPU" "$CKPT" "$CKPT_SHA" "$BASE_SHA" "$CONFIG" "$CONFIG_SHA" "$TRANSPORT_SHA" "$LOSS_SHA" <<'PY'
import json,sys
from pathlib import Path
(out,ds,var,seed,gpu,ckpt,cksha,basesha,cfg,cfgsha,trsha,lossha)=sys.argv[1:]
obj={'schema_version':1,'protocol':'UC-FNRT_causal_ablation_v1','dataset':ds,'variant':var,'seed':int(seed),'gpu':int(gpu),'checkpoint':str(Path(ckpt).resolve()),'checkpoint_sha256':cksha,'base_pvl_state_sha256':basesha,'config':cfg,'config_sha256':cfgsha,'transport_sha256':trsha,'loss_sha256':lossha,'test_opened':False,'checkpoint_policy':'physical_last_epoch'}
Path(out).write_text(json.dumps(obj,indent=2)+'\n')
PY
printf 'completed_at=%s\ncheckpoint=%s\nbase_pvl_state_sha256=%s\n' "$(date --iso-8601=seconds)" "$CKPT" "$BASE_SHA" > "$SUCCESS"
echo "[PASS] TRAIN SEALED: $DATASET $VARIANT base_sha=$BASE_SHA"
