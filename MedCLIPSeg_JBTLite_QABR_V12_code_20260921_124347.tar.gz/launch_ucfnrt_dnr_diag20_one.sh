#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:?physical GPU index required}"
VARIANT="${VARIANT:?D0_MATCHED_CONTROL or D1_DISTRIBUTIONAL_OFFSET required}"
SEED="${SEED:-42}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"

case "$VARIANT" in
  D0_MATCHED_CONTROL|D1_DISTRIBUTIONAL_OFFSET) ;;
  *) echo "[FAIL] unknown VARIANT=$VARIANT"; exit 2 ;;
esac

cd "$PROJECT"
export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"
export TOKENIZERS_PARALLELISM=false
export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True}"
unset PYTORCH_CUDA_ALLOC_CONF 2>/dev/null || true

CONFIG="configs/ucfnrt_distributional_rootfix/BUSI_${VARIANT}_DIAG20.yaml"
[[ -f "$CONFIG" ]] || { echo "[FAIL] missing config: $CONFIG"; exit 3; }

FREE="$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits \
  | awk -F',' -v g="$GPU" '$1+0==g{gsub(/ /,"",$2);print $2;exit}')"
[[ -n "$FREE" ]] || { echo "[FAIL] GPU$GPU not found"; exit 4; }
if (( FREE < MIN_FREE_MIB )); then
  echo "[FAIL] GPU$GPU free=${FREE}MiB < ${MIN_FREE_MIB}MiB"
  exit 5
fi

RUN_ROOT="$PROJECT/runs/UCFNRT_DNR_ROOTFIX_DIAG20_${ROOT_ID}/seed${SEED}/BUSI/${VARIANT}"
STATE_DIR="$RUN_ROOT/formal_state"
LOG="$PROJECT/logs/UCFNRT_DNR_ROOTFIX_${ROOT_ID}_${VARIANT}_S${SEED}.log"
SUCCESS="$STATE_DIR/TRAIN_SUCCESS.lock"
mkdir -p "$PROJECT/logs"

if [[ -f "$SUCCESS" ]]; then
  echo "[SKIP PASS] $VARIANT already complete: $SUCCESS"
  exit 0
fi

if [[ -d "$RUN_ROOT" && -n "$(find "$RUN_ROOT" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  ARCH="$PROJECT/runs/UCFNRT_DNR_ROOTFIX_DIAG20_${ROOT_ID}/seed${SEED}/BUSI/failed_attempts/${VARIANT}_$(date +%Y%m%d_%H%M%S)"
  mkdir -p "$(dirname "$ARCH")"
  mv "$RUN_ROOT" "$ARCH"
  echo "[RECOVER] archived incomplete attempt -> $ARCH"
fi
mkdir -p "$STATE_DIR"

cat <<EOF
================================================================================
UC-FNRT DNR ROOT-FIX | TRAIN-ONLY DIAG20
VARIANT=$VARIANT GPU=$GPU SEED=$SEED
CONFIG=$CONFIG
RUN_ROOT=$RUN_ROOT
LOCKED: BUSI | 20 physical epochs | scheduler horizon100 | batch24 | TrainMC10 | radius8
LOCKED EVIDENCE: raw posterior + raw bilateral normal ray
TEST STATUS: SEALED. This launcher NEVER calls test.py.
CAUSAL DESIGN: D0/D1 both register the same 17-bin head; only D1 uses it.
================================================================================
EOF

CUDA_VISIBLE_DEVICES="$GPU" "$PYTHON" -u train.py \
  --config-file "$CONFIG" \
  --seed "$SEED" \
  --output-dir "$RUN_ROOT" 2>&1 | tee "$LOG"

mapfile -t CKPTS < <(find "$RUN_ROOT/BUSI/trained_models/seed${SEED}" \
  -maxdepth 1 -type f -name '*_last_epoch.pth' -print 2>/dev/null | sort)
if (( ${#CKPTS[@]} != 1 )); then
  echo "[FAIL] expected exactly one physical last-epoch checkpoint, got ${#CKPTS[@]}"
  printf '  %s\n' "${CKPTS[@]:-}"
  exit 10
fi

mkdir -p "$STATE_DIR"
printf 'completed_at=%s\nvariant=%s\ncheckpoint=%s\n' \
  "$(date --iso-8601=seconds)" "$VARIANT" "${CKPTS[0]}" > "$SUCCESS"
echo "[PASS] $VARIANT DIAG20 TRAIN SEALED; Test unopened"
