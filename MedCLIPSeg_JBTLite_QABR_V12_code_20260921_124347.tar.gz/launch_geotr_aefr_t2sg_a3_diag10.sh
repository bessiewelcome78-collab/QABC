#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-3}"; SEED="${SEED:-42}"
cd "${PROJECT}" || exit 1
export TOKENIZERS_PARALLELISM=false
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs runs
LOG="logs/GEOTR_AEFR_T2SG_A3_DIAG10_seed${SEED}_gpu${GPU}_${STAMP}.log"
PYTHONPATH=. "${PYTHON}" tools/test_geotr_aefr_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_aefr_integration.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_aefr_configs.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_aefr_transition_contract.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_aefr_transition_configs.py
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "configs/BUSI_GEOTR_AEFR_T2SG_A3_DIAG10.yaml" \
  --seed "${SEED}" \
  --output-dir "runs/GEOTR_AEFR_T2SG_A3_DIAG10_seed${SEED}_${STAMP}" \
  2>&1 | tee "${LOG}"
"${PYTHON}" tools/diagnose_geotr_aefr_log.py "${LOG}" || true
echo "[PASS] GEOTR-AEFR T2SG_A3 DIAG10 finished: ${LOG}"
