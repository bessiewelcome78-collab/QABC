#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}:${PYTHONPATH:-}"
export TOKENIZERS_PARALLELISM=false

echo "=============================================================================================================="
echo "GEOTR-M1 EXACT PREFLIGHT | controlled extraction of the validated Stage-1 Transport"
echo "PROJECT=${PROJECT}"
echo "PYTHON=${PYTHON}"
echo "=============================================================================================================="

"${PYTHON}" -m py_compile \
  utils/geotr_m1_transport.py utils/geotr_m1_loss.py \
  trainers/medclipseg_unimedclip.py train.py test.py \
  tools/check_geotr_m1_exact_config.py \
  tools/check_geotr_m1_exact_routing.py \
  tools/test_geotr_m1_exact_integration.py \
  tools/test_geotr_m1_legacy_equivalence.py
"${PYTHON}" tools/check_geotr_m1_exact_config.py
"${PYTHON}" tools/check_geotr_m1_exact_routing.py
"${PYTHON}" tools/test_geotr_m1_exact_integration.py
"${PYTHON}" tools/test_geotr_m1_legacy_equivalence.py

echo "[PASS] GEOTR-M1 exact preflight finished"
echo "       M1: historical image/semantic/text FiLM -> diag residual -> softplus-scale flow -> logit warp"
echo "       Objective: historical BCE+Dice Geometry loss; extra SemLT regularizers are absent"
echo "       RNG: reset after model/optimizer construction for controlled model-side stochasticity"
echo "       Selection: native_m1_dice, tie-break native_m1_nsd"
echo "       M2/M3: not constructed, not optimized, not deployed"

