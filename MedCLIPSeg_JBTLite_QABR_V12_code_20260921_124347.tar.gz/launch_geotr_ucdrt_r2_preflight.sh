#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "$0")" && pwd)}"
PYTHON="${PYTHON:-python}"
cd "${PROJECT}"
"${PYTHON}" -m py_compile \
  utils/slr_transition_refiner.py \
  utils/slr_transition_refiner_r2.py \
  utils/multi_hypothesis_composition.py \
  utils/multi_hypothesis_composition_loss.py \
  train.py \
  tools/test_geotr_ucdrt_r2_contract.py \
  tools/test_geotr_ucdrt_r2_integration.py \
  tools/check_geotr_ucdrt_r2_configs.py \
  tools/diagnose_geotr_ucdrt_r2_log.py
"${PYTHON}" tools/test_geotr_ucdrt_r2_contract.py
"${PYTHON}" tools/test_geotr_ucdrt_r2_integration.py
"${PYTHON}" tools/check_geotr_ucdrt_r2_configs.py
# R1 and SLR2.3 are retained as true ablation controls.
"${PYTHON}" tools/test_geotr_ucdrt_contract.py
"${PYTHON}" tools/test_geotr_ucdrt_loss_contract.py
"${PYTHON}" tools/test_geotr_ucdrt_integration.py
"${PYTHON}" tools/test_geotr_slr_contract.py
"${PYTHON}" tools/test_geotr_slr_integration.py
printf '%s\n' '[PASS] GEOTR-UCDRT-R2 preflight + UCDRT-R1/SLR2.3 regression contracts'
