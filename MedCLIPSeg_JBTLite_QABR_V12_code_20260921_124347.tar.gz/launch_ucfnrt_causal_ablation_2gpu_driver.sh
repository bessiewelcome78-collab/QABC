#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"; PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
SEED="${SEED:-42}"; ROOT_ID="${ROOT_ID:?ROOT_ID required}"; GPU_A="${GPU_A:-0}"; GPU_B="${GPU_B:-1}"; MATRIX="${MATRIX:-PRIMARY2}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"; POLL_SECONDS="${POLL_SECONDS:-60}"; VARIANTS="NO_POSTERIOR NO_RAY DIRECT_SIGNED SEG_ONLY"
[[ "$GPU_A" != "$GPU_B" ]] || { echo "[FAIL] two distinct physical GPUs required"; exit 2; }
case "$MATRIX" in
  PRIMARY2) DATASETS_A="BUSI"; DATASETS_B="Kvasir" ;;
  ROBUST2) DATASETS_A="BUSI"; DATASETS_B="ISIC" ;;
  ALL4) DATASETS_A="BUSI ISIC Kvasir"; DATASETS_B="BTMRI" ;;
  *) echo "[FAIL] MATRIX must be PRIMARY2|ROBUST2|ALL4"; exit 2;;
esac
cd "$PROJECT"; mkdir -p logs
MASTER="${PROJECT}/logs/UCFNRT_CAUSAL_ABL_${ROOT_ID}_S${SEED}_${MATRIX}.master.log"
echo "[DRIVER] ROOT_ID=$ROOT_ID seed=$SEED matrix=$MATRIX GPU_A=$GPU_A[$DATASETS_A] GPU_B=$GPU_B[$DATASETS_B]"
(
  PROJECT="$PROJECT" PYTHON="$PYTHON" GPU="$GPU_A" SEED="$SEED" ROOT_ID="$ROOT_ID" DATASETS="$DATASETS_A" VARIANTS="$VARIANTS" MIN_FREE_MIB="$MIN_FREE_MIB" POLL_SECONDS="$POLL_SECONDS" bash launch_ucfnrt_causal_ablation_queue.sh
) >"${MASTER}.gpu${GPU_A}.train" 2>&1 & PA=$!
(
  PROJECT="$PROJECT" PYTHON="$PYTHON" GPU="$GPU_B" SEED="$SEED" ROOT_ID="$ROOT_ID" DATASETS="$DATASETS_B" VARIANTS="$VARIANTS" MIN_FREE_MIB="$MIN_FREE_MIB" POLL_SECONDS="$POLL_SECONDS" bash launch_ucfnrt_causal_ablation_queue.sh
) >"${MASTER}.gpu${GPU_B}.train" 2>&1 & PB=$!
status=0; wait "$PA" || status=1; wait "$PB" || status=1; ((status==0)) || { echo "[FAIL] training queue failed"; exit 30; }
# Global pre-Test seal: every preregistered selected run must exist and the
# semantic-host state must be bitwise identical across all four interventions.
ROOT="${PROJECT}/runs/UCFNRT_CAUSAL_ABL_${ROOT_ID}/seed${SEED}"; DATASETS_ALL="$DATASETS_A $DATASETS_B"
for ds in $DATASETS_ALL; do
  ref=""
  for var in $VARIANTS; do
    state="$ROOT/$ds/$var/formal_state"; [[ -f "$state/TRAIN_SUCCESS.lock" && -f "$state/TRAIN_MANIFEST.json" ]] || { echo "[FAIL] missing train seal $ds $var"; exit 31; }
    h="$($PYTHON -c 'import json,sys;print(json.load(open(sys.argv[1]))["base_pvl_state_sha256"])' "$state/TRAIN_MANIFEST.json")"
    if [[ -z "$ref" ]]; then ref="$h"; else [[ "$h" == "$ref" ]] || { echo "[FAIL] Base/PVL trajectory mismatch $ds $var: $h != $ref"; exit 32; }; fi
  done
  echo "[PASS] $ds Base/PVL bitwise common across all causal interventions: $ref"
done
SEAL="$ROOT/GLOBAL_TRAIN_SEAL.lock"; {
  echo "sealed_at=$(date --iso-8601=seconds)"; echo "matrix=$MATRIX"; echo "datasets=$DATASETS_ALL"; echo "variants=$VARIANTS"; echo "seed=$SEED";
  sha256sum configs/ucfnrt_causal_ablation/UC_FNRT_CAUSAL_ABLATION_SPEC.json utils/semlt_autozero_transport.py utils/semlt_autozero_loss.py train.py;
} > "$SEAL"
echo "[PASS] GLOBAL TRAIN SEAL created. Test may open now."
# Automatic one-shot Test wave, still two GPUs in parallel; each GPU remains serial.
(
  PROJECT="$PROJECT" PYTHON="$PYTHON" GPU="$GPU_A" SEED="$SEED" ROOT_ID="$ROOT_ID" DATASETS="$DATASETS_A" VARIANTS="$VARIANTS" bash launch_ucfnrt_causal_ablation_test_queue.sh
) >"${MASTER}.gpu${GPU_A}.test" 2>&1 & TA=$!
(
  PROJECT="$PROJECT" PYTHON="$PYTHON" GPU="$GPU_B" SEED="$SEED" ROOT_ID="$ROOT_ID" DATASETS="$DATASETS_B" VARIANTS="$VARIANTS" bash launch_ucfnrt_causal_ablation_test_queue.sh
) >"${MASTER}.gpu${GPU_B}.test" 2>&1 & TB=$!
status=0; wait "$TA" || status=1; wait "$TB" || status=1; ((status==0)) || { echo "[FAIL] test queue failed"; exit 40; }
"$PYTHON" tools/collect_ucfnrt_causal_ablation.py --project "$PROJECT" --root-id "$ROOT_ID" --seed "$SEED" --datasets $DATASETS_ALL
echo "[PASS] UC-FNRT causal ablation complete ROOT_ID=$ROOT_ID"
