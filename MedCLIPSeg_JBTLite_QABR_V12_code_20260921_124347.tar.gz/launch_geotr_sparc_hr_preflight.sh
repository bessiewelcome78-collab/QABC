#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
cd "${PROJECT}" || exit 1
export PYTHONPATH="${PROJECT}:${PYTHONPATH:-}"
export TOKENIZERS_PARALLELISM=false

echo "=============================================================================================================="
echo "GEOTR SPARC-HR3.1 PREFLIGHT | validity-masked boundary-safe routing"
echo "PROJECT=${PROJECT}"
echo "PYTHON=${PYTHON}"
echo "=============================================================================================================="

"${PYTHON}" -m py_compile \
  utils/sparc_hr_composer.py \
  utils/sparc_hr_loss.py \
  utils/slr_paired_hr_dataset.py \
  utils/v547_semantic_safe_augment.py \
  utils/multi_hypothesis_composition.py \
  utils/multi_hypothesis_composition_loss.py \
  trainers/medclipseg_unimedclip.py \
  train.py test.py \
  tools/check_geotr_sparc_hr_config.py \
  tools/check_geotr_sparc_hr_metric_routing.py \
  tools/test_geotr_sparc_hr_contract.py \
  tools/test_geotr_sparc_hr_integration.py \
  tools/test_sparc_hr_policy_objective.py \
  tools/check_sparc_hr_diag10_readiness.py

"${PYTHON}" tools/check_geotr_sparc_hr_config.py
"${PYTHON}" tools/check_geotr_sparc_hr_metric_routing.py
"${PYTHON}" tools/test_geotr_sparc_hr_contract.py
"${PYTHON}" tools/test_sparc_hr_policy_objective.py
"${PYTHON}" tools/test_geotr_sparc_hr_integration.py

echo "[PASS] SPARC-HR3.1 SafeDCRR preflight finished"
echo "       M1: unchanged Transport, trained from scratch with deep supervision"
echo "       M2: diverse posterior + absolute proposal + reachable ADD/REMOVE"
echo "       Router: invalid/no-op/duplicate sources are masked before softmax"
echo "       Objective: focal attainable-advantage distillation + harm control"
echo "       Deployment: boundary-only, confidence-gated hard routing without STE"
echo "       Validation: Base/M1/M2 at 448, dense/source oracle and routing-mass audit"
