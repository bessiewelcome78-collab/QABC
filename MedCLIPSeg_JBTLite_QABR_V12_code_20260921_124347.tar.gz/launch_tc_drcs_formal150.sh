#!/usr/bin/env bash
set -Eeuo pipefail
cd /home/tsz-25/MedCLIPSeg-pristine || exit 1
GPU="${GPU:-0}"; SEED="${SEED:-42}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
export TOKENIZERS_PARALLELISM=false
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs runs
LOG="logs/TC_DRCS_FORMAL150_seed${SEED}_gpu${GPU}_${STAMP}.log"
"${PYTHON}" tools/test_tc_drcs_contract.py
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
 --config-file configs/BUSI_TC_DRCS_FORMAL150.yaml --seed "${SEED}" \
 --output-dir "runs/TC_DRCS_FORMAL150_seed${SEED}_${STAMP}" 2>&1 | tee "${LOG}"
"${PYTHON}" tools/diagnose_tc_drcs_log.py "${LOG}"
echo "[PASS] TC-DRCS FORMAL150 finished: ${LOG}"
