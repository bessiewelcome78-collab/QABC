#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
SEED="${SEED:-42}"
EXP_ID="${EXP_ID:-}"
RADIUS="${RADIUS:-5}"
RADII="${RADII:-1,2,3,5,8}"
NULL_REPEATS="${NULL_REPEATS:-0}"
REQUIRE_ALL4="${REQUIRE_ALL4:-0}"

if [[ -z "${EXP_ID}" ]]; then
  for p in \
    "${PROJECT}/logs/SEMLT_E2E100_TABLE1_LAST_EXPID.txt" \
    "${PROJECT}/logs/SEMLT_E2E100_LAST_EXPID.txt"; do
    if [[ -s "$p" ]]; then
      EXP_ID="$(tr -d '\r\n ' < "$p")"
      break
    fi
  done
fi

[[ -n "${EXP_ID}" ]] || {
  echo "[FAIL] Set EXP_ID=<SEMLT_E2E100 experiment id>"
  exit 2
}

RUN_ROOT="${PROJECT}/runs/SEMLT_E2E100_MAIN_${EXP_ID}"
OUT_ROOT="${RUN_ROOT}/hypothesis_diagnosis/seed${SEED}"

mkdir -p "${OUT_ROOT}" "${PROJECT}/logs"

DATASETS=(BUSI BTMRI ISIC Kvasir)
SUMMARIES=()
DONE=()
SKIPPED=()

echo "============================================================"
echo "SemLT hypothesis diagnosis"
echo "RUN_ROOT      = ${RUN_ROOT}"
echo "SEED          = ${SEED}"
echo "RADII         = ${RADII}"
echo "RADIUS        = ${RADIUS}"
echo "REQUIRE_ALL4  = ${REQUIRE_ALL4}"
echo "============================================================"

for DS in "${DATASETS[@]}"; do
  MANIFEST="${RUN_ROOT}/${DS}/seed${SEED}/SEMLT_E2E100_manifest.json"

  if [[ ! -s "${MANIFEST}" ]]; then
    MSG="${DS}: missing manifest ${MANIFEST}"
    if [[ "${REQUIRE_ALL4}" == "1" ]]; then
      echo "[FAIL] ${MSG}" >&2
      exit 3
    fi
    echo "[SKIP] ${MSG}"
    SKIPPED+=("${MSG}")
    continue
  fi

  set +e
  META_TEXT="$("${PYTHON}" - "${MANIFEST}" <<'PY'
import json
import sys
from pathlib import Path

manifest = Path(sys.argv[1])
m = json.loads(manifest.read_text())

if not bool(m.get("test_success", False)):
    print("INCOMPLETE")
    sys.exit(20)

required = ("config", "result_root", "run_tag")
missing = [k for k in required if not m.get(k)]
if missing:
    print("BAD_MANIFEST:" + ",".join(missing))
    sys.exit(21)

r = Path(m["result_root"])
tag = m["run_tag"]
run = f"MedCLIPSeg_unimedclip_ViT-B-16_{tag}"

print(m["config"])
print(r / f"{run}_BaseNative_Prompt-original")
print(r / f"{run}_M1Native_Prompt-original")
PY
)"
  META_STATUS=$?
  set -e

  if [[ ${META_STATUS} -ne 0 ]]; then
    if [[ ${META_STATUS} -eq 20 ]]; then
      MSG="${DS}: formal Test is not complete (manifest test_success != true)"
    else
      MSG="${DS}: invalid formal-test manifest (status=${META_STATUS}; ${META_TEXT})"
    fi
    if [[ "${REQUIRE_ALL4}" == "1" ]]; then
      echo "[FAIL] ${MSG}" >&2
      exit 4
    fi
    echo "[SKIP] ${MSG}"
    SKIPPED+=("${MSG}")
    continue
  fi

  mapfile -t META <<< "${META_TEXT}"

  if (( ${#META[@]} < 3 )); then
    MSG="${DS}: manifest metadata parser returned ${#META[@]} fields, expected 3"
    if [[ "${REQUIRE_ALL4}" == "1" ]]; then
      echo "[FAIL] ${MSG}" >&2
      exit 5
    fi
    echo "[SKIP] ${MSG}"
    SKIPPED+=("${MSG}")
    continue
  fi

  CFG="${META[0]}"
  BASE_DIR="${META[1]}"
  M1_DIR="${META[2]}"

  if [[ ! -d "${BASE_DIR}" ]]; then
    MSG="${DS}: missing Base predictions ${BASE_DIR}"
    if [[ "${REQUIRE_ALL4}" == "1" ]]; then
      echo "[FAIL] ${MSG}" >&2
      exit 6
    fi
    echo "[SKIP] ${MSG}"
    SKIPPED+=("${MSG}")
    continue
  fi

  if [[ ! -d "${M1_DIR}" ]]; then
    MSG="${DS}: missing SemLT predictions ${M1_DIR}"
    if [[ "${REQUIRE_ALL4}" == "1" ]]; then
      echo "[FAIL] ${MSG}" >&2
      exit 7
    fi
    echo "[SKIP] ${MSG}"
    SKIPPED+=("${MSG}")
    continue
  fi

  O="${OUT_ROOT}/${DS}"
  echo "[DIAG] ${DS} -> ${O}"

  "${PYTHON}" -u "${PROJECT}/tools/semlt_hypothesis_diagnosis.py" \
    --dataset "${DS}" \
    --host-name "MedCLIPSeg-host" \
    --config-file "${CFG}" \
    --split test \
    --base-dir "${BASE_DIR}" \
    --refined-dir "${M1_DIR}" \
    --output-dir "${O}" \
    --radii "${RADII}" \
    --mechanism-radius "${RADIUS}" \
    --null-repeats "${NULL_REPEATS}" \
    --seed 20260829

  SUMMARY="${O}/summary.json"
  if [[ ! -s "${SUMMARY}" ]]; then
    echo "[FAIL] ${DS}: diagnosis finished without ${SUMMARY}" >&2
    exit 8
  fi

  SUMMARIES+=("${SUMMARY}")
  DONE+=("${DS}")
done

echo
echo "============================================================"
echo "Diagnosis availability"
echo "DONE    = ${DONE[*]:-none}"
echo "SKIPPED = ${#SKIPPED[@]}"
for x in "${SKIPPED[@]}"; do
  echo "  - ${x}"
done
echo "============================================================"

if (( ${#SUMMARIES[@]} == 0 )); then
  echo "[FAIL] No dataset has a complete formal Test to diagnose." >&2
  exit 9
fi

COMBINED="${OUT_ROOT}/combined"
mkdir -p "${COMBINED}"

"${PYTHON}" -u "${PROJECT}/tools/semlt_hypothesis_collect.py" \
  "${SUMMARIES[@]}" \
  --output-dir "${COMBINED}" \
  --radius "${RADIUS}"

{
  echo "# SemLT hypothesis diagnosis availability"
  echo
  echo "- Experiment: \`${EXP_ID}\`"
  echo "- Seed: \`${SEED}\`"
  echo "- Completed datasets: \`${DONE[*]}\`"
  echo "- Requested datasets: \`${DATASETS[*]}\`"
  echo
  if (( ${#SKIPPED[@]} > 0 )); then
    echo "## Skipped"
    for x in "${SKIPPED[@]}"; do
      echo "- ${x}"
    done
  else
    echo "All four datasets were available."
  fi
} > "${COMBINED}/availability.md"

echo
echo "[PASS] hypothesis package complete for ${#SUMMARIES[@]} dataset(s)"
echo "       ${COMBINED}/hypothesis_table.md"
echo "       ${COMBINED}/ltr_cross_dataset_host.png"
echo "       ${COMBINED}/availability.md"

if (( ${#SKIPPED[@]} > 0 )); then
  echo
  echo "[WARN] This is a PARTIAL cross-dataset table."
  echo "       Complete the skipped formal Test(s), then rerun with REQUIRE_ALL4=1."
fi
