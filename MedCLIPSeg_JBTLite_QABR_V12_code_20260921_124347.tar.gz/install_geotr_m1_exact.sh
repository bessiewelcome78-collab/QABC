#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-python}"
[[ -d "${TARGET}" ]] || { echo "[FAIL] target project not found: ${TARGET}"; exit 2; }
[[ -f "${TARGET}/train.py" ]] || { echo "[FAIL] target does not look like MedCLIPSeg: ${TARGET}"; exit 2; }

STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="${TARGET}_code_backups/before_GEOTR_M1_EXACT_${STAMP}"
mkdir -p "${BACKUP}"

FILES=(
  install_geotr_m1_exact.sh
  utils/geotr_m1_transport.py
  utils/geotr_m1_loss.py
  trainers/medclipseg_unimedclip.py
  train.py
  test.py
  configs/BUSI_GEOTR_M1_EXACT_DIAG10.yaml
  tools/check_geotr_m1_exact_config.py
  tools/check_geotr_m1_exact_routing.py
  tools/test_geotr_m1_exact_integration.py
  tools/test_geotr_m1_legacy_equivalence.py
  launch_geotr_m1_exact_preflight.sh
  launch_geotr_m1_exact_diag10.sh
  launch_geotr_m1_exact_formal150.sh
  launch_geotr_m1_exact_test.sh
  GEOTR_M1_EXACT_DESIGN_CN.md
  GEOTR_M1_EXACT_VERSION.txt
  GEOTR_M1_EXACT_MODIFIED_FILES.txt
)

echo "========== 1. 检查、备份并安装 GEOTR-M1 exact =========="
for relative in "${FILES[@]}"; do
  [[ -f "${SOURCE}/${relative}" ]] || { echo "[FAIL] missing source: ${relative}"; exit 2; }
  if [[ -f "${TARGET}/${relative}" ]]; then
    mkdir -p "${BACKUP}/$(dirname "${relative}")"
    cp -a "${TARGET}/${relative}" "${BACKUP}/${relative}"
  fi
  mkdir -p "${TARGET}/$(dirname "${relative}")"
  cp -a "${SOURCE}/${relative}" "${TARGET}/${relative}"
  echo "[OK] ${relative}"
done
chmod +x "${TARGET}"/launch_geotr_m1_exact_*.sh "${TARGET}/install_geotr_m1_exact.sh" 2>/dev/null || true

echo "========== 2. 完整预检 =========="
PYTHON="${PYTHON}" PROJECT="${TARGET}" bash "${TARGET}/launch_geotr_m1_exact_preflight.sh"
echo "[PASS] GEOTR-M1 exact installed"
echo "备份目录：${BACKUP}"

