#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
STUDY_ID="${STUDY_ID:-${EXP_ID:-$(date +%Y%m%d_%H%M%S)}}"
STUDY_ID="${STUDY_ID#OACD_ABL_}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"
ARMS=(A000_JOINT_CONTROL A011_NO_ALIGN A101_NO_CDF A110_NO_REACH FULL)
mkdir -p "$PROJECT/logs"
for ARM in "${ARMS[@]}"; do
  echo "============================================================"
  echo "[$(date '+%F %T')] starting $ARM"
  echo "============================================================"
  env PROJECT="$PROJECT" PYTHON="$PYTHON" GPU="$GPU" SEED="$SEED" \
      STUDY_ID="$STUDY_ID" ARM="$ARM" MIN_FREE_MIB="$MIN_FREE_MIB" \
      bash "$PROJECT/launch_oacd_ablation_one.sh"
  echo "[$(date '+%F %T')] completed $ARM"
done
echo "[PASS] all OACD ablation arms completed sequentially"
