#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
DATASET="${DATASET:-BUSI}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
RUN_ROOT="${RUN_ROOT:?set RUN_ROOT to the completed Boundary-Normal Warp PAPER100 training root}"
case "${DATASET}" in BUSI|BTMRI|ISIC|Kvasir) ;; *) echo 'DATASET must be BUSI|BTMRI|ISIC|Kvasir'; exit 2;; esac
CONFIG="configs/${DATASET}_SEMLT_BOUNDARY_NORMAL_WARP_PAPER100.yaml"
RUN_TAG="SEMLT_BOUNDARY_NORMAL_WARP_PAPER100_${DATASET}"
RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
export TOKENIZERS_PARALLELISM=false
"${PYTHON}" tools/test_semlt_boundary_normal_warp_contract.py
"${PYTHON}" tools/check_semlt_boundary_normal_warp_configs.py
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u test.py \
  --config-file "${CONFIG}" --seed "${SEED}" --split test \
  --num-samples 30 --output-dir "${RUN_ROOT}"
RESULT_ROOT="${RUN_ROOT}/${DATASET}/seg_results/seed${SEED}"
evaluate_one() {
  local result_name="$1" csv_name="$2" nsd_mode="$3"
  "${PYTHON}" -u utils/eval.py \
    --config-file "${CONFIG}" --seed "${SEED}" --split test \
    --output-dir "${RUN_ROOT}" --result-name "${result_name}" \
    --csv-name "${csv_name}" --nsd-mode "${nsd_mode}"
}
evaluate_one "${RUN_NAME}_BaseNative" test_BaseNative_true2d.csv true2d
evaluate_one "${RUN_NAME}_M1Native" test_M1Native_true2d.csv true2d
evaluate_one "${RUN_NAME}_BaseNative" test_BaseNative_paper_legacy.csv paper_legacy
evaluate_one "${RUN_NAME}_M1Native" test_M1Native_paper_legacy.csv paper_legacy
"${PYTHON}" tools/compare_geotr_m1_paired.py \
  --base-csv "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
  --m1-csv "${RESULT_ROOT}/test_M1Native_true2d.csv" \
  --output-prefix "${RESULT_ROOT}/paired_true2d" \
  --protocol-label "${DATASET}_PAPER100_boundary_normal_warp_true2d_seed${SEED}"
"${PYTHON}" tools/compare_geotr_m1_paired.py \
  --base-csv "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
  --m1-csv "${RESULT_ROOT}/test_M1Native_paper_legacy.csv" \
  --output-prefix "${RESULT_ROOT}/paired_paper_legacy" \
  --protocol-label "${DATASET}_PAPER100_boundary_normal_warp_paper_legacy_seed${SEED}"
echo "[PASS] Boundary-Normal Warp PAPER100 Test/evaluation complete"
echo "PAPER_REPORT=${RESULT_ROOT}/paired_paper_legacy.md"
echo "TRUE2D_REPORT=${RESULT_ROOT}/paired_true2d.md"
