#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
cd "${PROJECT}" || exit 1
"${PYTHON}" -m py_compile \
  utils/c2r_region_refiner.py \
  utils/c2r_canonical_roi_refiner.py \
  utils/multi_hypothesis_composition.py \
  utils/multi_hypothesis_composition_loss.py \
  train.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2rv2_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2rv2_integration.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2rv2_shared_trajectory_contract.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_c2rv2_configs.py
# Backward-compatibility: C2R-v1 remains a paper ablation baseline.
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2r_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2r_integration.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_c2r_configs.py
echo "[PASS] GEOTR-C2R-v2 preflight finished"
