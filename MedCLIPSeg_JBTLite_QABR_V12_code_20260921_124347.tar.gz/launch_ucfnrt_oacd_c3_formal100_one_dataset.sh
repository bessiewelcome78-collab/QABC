#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:-BUSI}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MASTER_ROOT="${MASTER_ROOT:-${PROJECT}/runs/UCFNRT_OACD_C3_FORMAL100_${ROOT_ID}_S${SEED}}"

case "${DATASET}" in
  BUSI|BTMRI|ISIC|Kvasir) ;;
  *) echo "[FAIL] DATASET must be BUSI|BTMRI|ISIC|Kvasir" >&2; exit 2 ;;
esac
[[ "${GPU}" =~ ^[0-9]+$ ]] || { echo "[FAIL] GPU must be a physical integer index" >&2; exit 2; }

cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
export TOKENIZERS_PARALLELISM=false
export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True}"
export CUBLAS_WORKSPACE_CONFIG="${CUBLAS_WORKSPACE_CONFIG:-:4096:8}"
export NVIDIA_TF32_OVERRIDE=0
unset PYTORCH_CUDA_ALLOC_CONF 2>/dev/null || true

CONFIG="configs/ucfnrt_oacd_formal100/OACD_C3_LOCKED_FORMAL100.yaml"
RUN_TAG="SEMLT_UCFNRT_OACD_C3_FORMAL100_${DATASET}"
RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"
RUN_ROOT="${MASTER_ROOT}/${DATASET}"
TEST_ROOT="${RUN_ROOT}/formal_test"
STATE_DIR="${RUN_ROOT}/formal_state"
LOG_DIR="${PROJECT}/logs/UCFNRT_OACD_C3_FORMAL100_${ROOT_ID}_S${SEED}"
TRAIN_LOG="${LOG_DIR}/${DATASET}.train.log"
TEST_LOG="${LOG_DIR}/${DATASET}.test.log"
EVAL_LOG="${LOG_DIR}/${DATASET}.eval.log"
TRAIN_STARTED="${STATE_DIR}/TRAIN_STARTED.lock"
TRAIN_SUCCESS="${STATE_DIR}/TRAIN_SUCCESS.lock"
TEST_OPENED="${STATE_DIR}/TEST_OPENED.lock"
TEST_SUCCESS="${STATE_DIR}/TEST_SUCCESS.lock"
EVAL_SUCCESS="${STATE_DIR}/EVAL_SUCCESS.lock"

OVERRIDES=(
  DATASET.NAME "${DATASET}"
  DATASET.TRAIN_PATH "./data/${DATASET}/Train_Folder/"
  DATASET.VAL_PATH "./data/${DATASET}/Val_Folder/"
  DATASET.TEST_PATH "./data/${DATASET}/Test_Folder/"
  DATASET.TEXT_PROMPT_PATH "./data/${DATASET}/Prompts_Folder/"
  M1.RUN_TAG "${RUN_TAG}"
  TRAIN.RUN_TAG "${RUN_TAG}"
)

mkdir -p "${STATE_DIR}" "${LOG_DIR}"

"${PYTHON}" tools/check_ucfnrt_oacd_c3_formal100.py --project "${PROJECT}"
"${PYTHON}" tools/test_ucfnrt_oacd_contract.py
for path in \
  "${PROJECT}/data/${DATASET}/Train_Folder" \
  "${PROJECT}/data/${DATASET}/Val_Folder" \
  "${PROJECT}/data/${DATASET}/Test_Folder" \
  "${PROJECT}/data/${DATASET}/Prompts_Folder"; do
  [[ -d "${path}" ]] || { echo "[FAIL] dataset path missing: ${path}" >&2; exit 3; }
done

command -v nvidia-smi >/dev/null 2>&1 || { echo "[FAIL] nvidia-smi not found" >&2; exit 4; }
GPU_FREE_MIB="$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits \
  | awk -F',' -v want="${GPU}" '$1+0==want {gsub(/ /,"",$2); print $2; exit}')"
[[ -n "${GPU_FREE_MIB}" ]] || { echo "[FAIL] physical GPU ${GPU} not found" >&2; exit 4; }
echo "[GPU PREFLIGHT] dataset=${DATASET} physical_gpu=${GPU} free=${GPU_FREE_MIB}MiB required=${MIN_FREE_MIB}MiB"
if (( GPU_FREE_MIB < MIN_FREE_MIB )); then
  echo "[FAIL] GPU ${GPU} free memory ${GPU_FREE_MIB} MiB < ${MIN_FREE_MIB} MiB" >&2
  echo "[INFO] Keep Batch24/TrainMC10/TestMC30 unchanged and choose a free GPU." >&2
  exit 5
fi

if command -v flock >/dev/null 2>&1; then
  exec 9>"${PROJECT}/.ucfnrt_oacd_c3_formal100_gpu${GPU}.lock"
  flock -n 9 || { echo "[FAIL] GPU ${GPU} is locked by another OACD Formal100 job" >&2; exit 6; }
fi

if [[ -f "${EVAL_SUCCESS}" ]]; then
  echo "[SKIP PASS] ${DATASET} train/test/eval already complete: ${EVAL_SUCCESS}"
  exit 0
fi

cat <<EOF
================================================================================
UC-FNRT OACD C3 FORMAL100 | ONE DATASET
DATASET=${DATASET} GPU=${GPU} SEED=${SEED}
CONFIG=${CONFIG}
RUN_ROOT=${RUN_ROOT}
LOCKED=train100, physical Batch24, TrainMC10, radius8, TestMC30
LOCKED=C3 operator-aligned candidates + ordered CDF + reachable-only matching
LOCKED=from scratch, TF32 off, strict parity settings, physical epoch-100 checkpoint
SPLITS=Train only during optimization; Val sealed; Test opened once after Train success
================================================================================
EOF

if [[ ! -f "${TRAIN_SUCCESS}" ]]; then
  if [[ -f "${TRAIN_STARTED}" ]]; then
    echo "[FAIL] an earlier training attempt is incomplete: ${TRAIN_STARTED}" >&2
    echo "[INFO] Do not silently mix/restart a formal run. Audit or choose a new ROOT_ID." >&2
    exit 10
  fi
  printf 'opened_at=%s\ndataset=%s\nseed=%s\n' \
    "$(date --iso-8601=seconds)" "${DATASET}" "${SEED}" > "${TRAIN_STARTED}"

  CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --output-dir "${RUN_ROOT}" \
    "${OVERRIDES[@]}" \
    2>&1 | tee "${TRAIN_LOG}"

  mapfile -t CKPTS < <(find \
    "${RUN_ROOT}/${DATASET}/trained_models/seed${SEED}" \
    -maxdepth 1 -type f -name "${RUN_NAME}_last_epoch.pth" -print 2>/dev/null)
  if (( ${#CKPTS[@]} != 1 )); then
    echo "[FAIL] expected one physical epoch-100 checkpoint, got ${#CKPTS[@]}" >&2
    printf '  %s\n' "${CKPTS[@]:-}" >&2
    exit 11
  fi
  CKPT="${CKPTS[0]}"
  printf 'completed_at=%s\ndataset=%s\nseed=%s\ncheckpoint=%s\nsha256=%s\n' \
    "$(date --iso-8601=seconds)" "${DATASET}" "${SEED}" "${CKPT}" \
    "$(sha256sum "${CKPT}" | awk '{print $1}')" > "${TRAIN_SUCCESS}"
  echo "[PASS] ${DATASET} Train100 complete; Val/Test remained sealed."
else
  CKPT="$(awk -F= '$1=="checkpoint" {sub(/^checkpoint=/,""); print; exit}' "${TRAIN_SUCCESS}")"
  [[ -f "${CKPT}" ]] || { echo "[FAIL] locked checkpoint missing: ${CKPT}" >&2; exit 12; }
  echo "[RESUME] using completed Train100 checkpoint: ${CKPT}"
fi

if [[ ! -f "${TEST_SUCCESS}" ]]; then
  if [[ -f "${TEST_OPENED}" ]]; then
    echo "[FAIL] Test was already opened but did not complete: ${TEST_OPENED}" >&2
    echo "[INFO] Formal Test will not be opened twice. Audit this run; do not delete the marker." >&2
    exit 20
  fi
  printf 'opened_at=%s\ndataset=%s\nseed=%s\ncheckpoint=%s\ncheckpoint_sha256=%s\n' \
    "$(date --iso-8601=seconds)" "${DATASET}" "${SEED}" "${CKPT}" \
    "$(sha256sum "${CKPT}" | awk '{print $1}')" > "${TEST_OPENED}"

  CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u test.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --split test \
    --num-samples 30 \
    --checkpoint "${CKPT}" \
    --output-dir "${TEST_ROOT}" \
    "${OVERRIDES[@]}" \
    2>&1 | tee "${TEST_LOG}"

  printf 'completed_at=%s\ndataset=%s\nseed=%s\ncheckpoint=%s\n' \
    "$(date --iso-8601=seconds)" "${DATASET}" "${SEED}" "${CKPT}" > "${TEST_SUCCESS}"
  echo "[PASS] ${DATASET} one-shot Test inference complete."
fi

RESULT_ROOT="${TEST_ROOT}/${DATASET}/seg_results/seed${SEED}"
BASE_NAME="${RUN_NAME}_BaseNative"
M1_NAME="${RUN_NAME}_M1Native"

evaluate_one() {
  local result_name="$1" csv_name="$2" nsd_mode="$3"
  "${PYTHON}" -u utils/eval.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --split test \
    --output-dir "${TEST_ROOT}" \
    --result-name "${result_name}" \
    --csv-name "${csv_name}" \
    --nsd-mode "${nsd_mode}" \
    "${OVERRIDES[@]}" \
    2>&1 | tee -a "${EVAL_LOG}"
}

if [[ ! -f "${EVAL_SUCCESS}" ]]; then
  evaluate_one "${BASE_NAME}" test_BaseNative_true2d.csv true2d
  evaluate_one "${M1_NAME}" test_M1Native_true2d.csv true2d
  evaluate_one "${BASE_NAME}" test_BaseNative_paper_legacy.csv paper_legacy
  evaluate_one "${M1_NAME}" test_M1Native_paper_legacy.csv paper_legacy

  "${PYTHON}" tools/compare_geotr_m1_paired.py \
    --base-csv "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
    --m1-csv "${RESULT_ROOT}/test_M1Native_true2d.csv" \
    --output-prefix "${RESULT_ROOT}/paired_true2d" \
    --protocol-label "${DATASET}_UCFNRT_OACD_C3_FORMAL100_true2d_seed${SEED}" \
    2>&1 | tee -a "${EVAL_LOG}"

  "${PYTHON}" tools/compare_geotr_m1_paired.py \
    --base-csv "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
    --m1-csv "${RESULT_ROOT}/test_M1Native_paper_legacy.csv" \
    --output-prefix "${RESULT_ROOT}/paired_paper_legacy" \
    --protocol-label "${DATASET}_UCFNRT_OACD_C3_FORMAL100_paper_legacy_seed${SEED}" \
    2>&1 | tee -a "${EVAL_LOG}"

  printf 'completed_at=%s\ndataset=%s\nresult_root=%s\ntrue2d_report=%s\npaper_report=%s\n' \
    "$(date --iso-8601=seconds)" "${DATASET}" "${RESULT_ROOT}" \
    "${RESULT_ROOT}/paired_true2d.md" "${RESULT_ROOT}/paired_paper_legacy.md" \
    > "${EVAL_SUCCESS}"
fi

cat <<EOF
================================================================================
[PASS] ${DATASET} OACD C3 FORMAL100 TRAIN + ONE-SHOT TEST + EVAL COMPLETE
CHECKPOINT=${CKPT}
TRUE2D_REPORT=${RESULT_ROOT}/paired_true2d.md
PAPER_REPORT=${RESULT_ROOT}/paired_paper_legacy.md
TRAIN_LOG=${TRAIN_LOG}
TEST_LOG=${TEST_LOG}
EVAL_LOG=${EVAL_LOG}
================================================================================
EOF
