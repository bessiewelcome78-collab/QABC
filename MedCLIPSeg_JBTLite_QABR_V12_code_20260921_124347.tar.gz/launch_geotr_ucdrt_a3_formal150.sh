#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"; SEED="${SEED:-42}"
cd "${PROJECT}" || exit 1
export TOKENIZERS_PARALLELISM=false
export PYTHONPATH="${PROJECT}:${PYTHONPATH:-}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs runs
LOG="logs/GEOTR_UCDRT_A3_FORMAL150_seed${SEED}_gpu${GPU}_${STAMP}.log"
"${PYTHON}" tools/test_geotr_ucdrt_contract.py
"${PYTHON}" tools/test_geotr_ucdrt_loss_contract.py
"${PYTHON}" tools/check_geotr_ucdrt_configs.py
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "configs/BUSI_GEOTR_UCDRT_A3_FORMAL150.yaml" \
  --seed "${SEED}" \
  --output-dir "runs/GEOTR_UCDRT_A3_FORMAL150_seed${SEED}_${STAMP}" \
  2>&1 | tee "${LOG}"
"${PYTHON}" tools/diagnose_geotr_ucdrt_log.py "${LOG}" --tail 3 || true
echo "[PASS] GEOTR_UCDRT_A3_FORMAL150 finished: ${LOG}"
