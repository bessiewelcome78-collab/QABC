#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:?DATASET is required}"
SEED="${SEED:-42}"
ROOT_ID="${ROOT_ID:?ROOT_ID is required}"
GPUS="${GPUS:-0 1 2 3 4 5}"
cd "${PROJECT}"; mkdir -p logs
read -r -a gpu_ids <<< "${GPUS}"
[[ ${#gpu_ids[@]} -eq 6 ]] || { echo "[FAIL] GPUS must contain exactly six ids"; exit 2; }
[[ "$(printf '%s\n' "${gpu_ids[@]}" | sort -u | wc -l)" -eq 6 ]] || { echo "[FAIL] GPUS contains duplicates"; exit 2; }
variants=(A1_REWRITE A2_PROB A3_NORMAL1D A4_FREE2D A5_SUPPORT A6_SEMLT)
ROOT_RUN="runs/SEMLT_ABLATION_${ROOT_ID}/seed${SEED}/${DATASET}"
[[ -f "${ROOT_RUN}/common_base/BASE_SUCCESS.lock" ]] || { echo "[FAIL] common Base missing for ${DATASET} seed${SEED}"; exit 2; }
STAMP="$(date +%Y%m%d_%H%M%S)"; pids=(); logs=()
for i in "${!variants[@]}"; do
  v="${variants[$i]}"; g="${gpu_ids[$i]}"; log="logs/SEMLT_ABL_${DATASET}_seed${SEED}_${v}_gpu${g}_${ROOT_ID}_${STAMP}.driver.log"; logs+=("${log}")
  PROJECT="${PROJECT}" PYTHON="${PYTHON}" DATASET="${DATASET}" GPU="${g}" SEED="${SEED}" ROOT_ID="${ROOT_ID}" VARIANT="${v}" \
    bash launch_semlt_ablation_variant_one.sh >"${log}" 2>&1 &
  pids+=("$!"); echo "[STARTED] ${DATASET} seed${SEED} ${v} gpu=${g} pid=$! log=${log}"
done
status=0
for i in "${!pids[@]}"; do if ! wait "${pids[$i]}"; then echo "[FAIL] ${variants[$i]} failed; log=${logs[$i]}"; status=2; fi; done
(( status==0 )) || exit "${status}"
for v in "${variants[@]}"; do [[ -f "${ROOT_RUN}/variants/${v}/FORMAL_VAL_SUCCESS.lock" ]] || { echo "[FAIL] missing success lock for ${v}"; exit 2; }; done
echo "[PASS] ${DATASET} seed${SEED} all six locked variants completed validation"
