#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU_BUSI="${GPU_BUSI:-0}"; GPU_BTMRI="${GPU_BTMRI:-1}"; GPU_ISIC="${GPU_ISIC:-2}"; GPU_KVASIR="${GPU_KVASIR:-3}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
cd "${PROJECT}"
for seed in 42 123 789; do
  echo "[WAVE START] seed=${seed} ROOT_ID=${ROOT_ID}"
  PROJECT="${PROJECT}" PYTHON="${PYTHON}" SEED="${seed}" EXP_ID="${ROOT_ID}_seed${seed}" \
  GPU_BUSI="${GPU_BUSI}" GPU_BTMRI="${GPU_BTMRI}" GPU_ISIC="${GPU_ISIC}" GPU_KVASIR="${GPU_KVASIR}" \
    bash launch_lest59_all4_seed.sh
  echo "[WAVE END] seed=${seed}"
done
echo "[PASS] LeST59 three-seed train+val protocol complete; Test remains sealed"
