#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${PROJECT:-${SCRIPT_DIR}}"
PYTHON="${PYTHON:-python3}"
DATASETS="${DATASETS:-BUSI Kvasir ISIC}"
GPUS="${GPUS:-0 1 2}"
SEEDS="${SEEDS:-42 123 789}"
RUN_POLICY="${RUN_POLICY:-fresh}"
RUN_TEST_AFTER_VAL="${RUN_TEST_AFTER_VAL:-0}"
ROOT_ID="${ROOT_ID:-SEMLT3GPU_V1_$(date +%Y%m%d_%H%M%S)_$$}"
ALLOW_EXISTING_ROOT="${ALLOW_EXISTING_ROOT:-0}"

read -r -a datasets <<< "${DATASETS}"
read -r -a gpu_ids <<< "${GPUS}"
[[ ${#datasets[@]} -eq 3 ]] || { echo "[FAIL] DATASETS must contain exactly three names" >&2; exit 2; }
[[ ${#gpu_ids[@]} -eq 3 ]] || { echo "[FAIL] GPUS must contain exactly three ids" >&2; exit 2; }
[[ "$(printf '%s\n' "${datasets[@]}" | sort -u | wc -l)" -eq 3 ]] || { echo "[FAIL] DATASETS contains duplicates" >&2; exit 2; }
[[ "$(printf '%s\n' "${gpu_ids[@]}" | sort -u | wc -l)" -eq 3 ]] || { echo "[FAIL] GPUS contains duplicates" >&2; exit 2; }
[[ "${ROOT_ID}" =~ ^[A-Za-z0-9_.-]+$ ]] || { echo "[FAIL] invalid ROOT_ID" >&2; exit 2; }
case "${RUN_TEST_AFTER_VAL}" in 0|1) ;; *) echo "[FAIL] RUN_TEST_AFTER_VAL must be 0 or 1" >&2; exit 2;; esac
for ds in "${datasets[@]}"; do case "${ds}" in BUSI|Kvasir|ISIC) ;; *) echo "[FAIL] unsupported dataset: ${ds}" >&2; exit 2;; esac; done
for gpu in "${gpu_ids[@]}"; do [[ "${gpu}" =~ ^[0-9]+$ ]] || { echo "[FAIL] invalid GPU: ${gpu}" >&2; exit 2; }; done

cd "${PROJECT}"
mkdir -p logs runs
run_root="runs/SEMLT_ABLATION_${ROOT_ID}"
if [[ -e "${run_root}" && "${ALLOW_EXISTING_ROOT}" != 1 ]]; then
  echo "[FAIL] run root already exists: ${run_root}" >&2
  echo "       set a new ROOT_ID, or set ALLOW_EXISTING_ROOT=1 for an intentional recovery" >&2
  exit 2
fi
manifest_log="logs/SEMLT3GPU_${ROOT_ID}_launch.txt"
if [[ -e "${manifest_log}" && "${ALLOW_EXISTING_ROOT}" != 1 ]]; then
  echo "[FAIL] launch log already exists: ${manifest_log}" >&2; exit 2
fi
printf 'root_id=%s\ndatasets=%s\ngpus=%s\nseeds=%s\nrun_policy=%s\nrun_test_after_val=%s\n' \
  "${ROOT_ID}" "${DATASETS}" "${GPUS}" "${SEEDS}" "${RUN_POLICY}" "${RUN_TEST_AFTER_VAL}" >> "${manifest_log}"

launch_phase() {
  local phase="$1"
  local script="$2"
  local pids=()
  local phase_logs=()
  local labels=()
  local i ds gpu log
  for i in "${!datasets[@]}"; do
    ds="${datasets[$i]}"
    gpu="${gpu_ids[$i]}"
    log="logs/SEMLT3GPU_${ROOT_ID}_${ds}_gpu${gpu}_${phase}.log"
    PROJECT="${PROJECT}" PYTHON="${PYTHON}" DATASET="${ds}" GPU="${gpu}" ROOT_ID="${ROOT_ID}" \
      SEEDS="${SEEDS}" RUN_POLICY="${RUN_POLICY}" GATE_DATASETS="${DATASETS}" \
      bash "${PROJECT}/${script}" >> "${log}" 2>&1 &
    pids+=("$!")
    phase_logs+=("${log}")
    labels+=("${ds}")
    echo "[STARTED] phase=${phase} dataset=${ds} gpu=${gpu} pid=$! log=${log}"
  done

  local status=0
  for i in "${!pids[@]}"; do
    if ! wait "${pids[$i]}"; then
      echo "[FAIL] phase=${phase} dataset=${labels[$i]} log=${phase_logs[$i]}" >&2
      status=2
    else
      echo "[PASS] phase=${phase} dataset=${labels[$i]} log=${phase_logs[$i]}"
    fi
  done
  (( status == 0 )) || return "${status}"
}

echo "[ROOT_ID] ${ROOT_ID}"
echo "[SCHEDULE] BUSI/Kvasir/ISIC-style dataset workers run in parallel; A0-A6 are sequential inside each worker"
launch_phase trainval launch_semlt_ablation_one_dataset_sequential_v1.sh
if [[ "${RUN_TEST_AFTER_VAL}" == 1 ]]; then
  launch_phase test launch_semlt_ablation_one_dataset_test_sequential_v1.sh
else
  echo "[SEALED] all train/Val jobs completed; Test was not opened (RUN_TEST_AFTER_VAL=0)"
fi
echo "[PASS] three-dataset 3-GPU ablation finished; ROOT_ID=${ROOT_ID}"
