#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:-BUSI}"; MODE="${MODE:-DIAG20}"; GPU="${GPU:-0}"; SEED="${SEED:-42}"
STAMP="${STAMP:-$(date +%Y%m%d_%H%M%S)}"
RUN_ROOT="${RUN_ROOT:-$PROJECT/runs/DS_UCFNRT_STAGEA_${MODE}_${DATASET}_S${SEED}_${STAMP}}"
LOG="$PROJECT/logs/DS_UCFNRT_STAGEA_${MODE}_${DATASET}_S${SEED}_${STAMP}.log"
mkdir -p "$PROJECT/logs"
nohup env PROJECT="$PROJECT" PYTHON="$PYTHON" DATASET="$DATASET" MODE="$MODE" GPU="$GPU" SEED="$SEED" \
  MIN_FREE_MIB="${MIN_FREE_MIB:-43000}" STAMP="$STAMP" RUN_ROOT="$RUN_ROOT" \
  bash "$PROJECT/launch_ds_ucfnrt_stagea_one_dataset.sh" > "$LOG" 2>&1 &
PID=$!
echo "$PID" > "${LOG%.log}.pid"
echo "PID=$PID"
echo "LOG=$LOG"
echo "RUN_ROOT=$RUN_ROOT"
echo "tail -f $LOG"
