#!/usr/bin/env bash
set -Eeuo pipefail

# One predeclared BUSI method ablation: train 100 epochs from scratch, open Test
# once, export BaseNative/M1Native, and perform paired per-case inference.

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
ARM="${ARM:-FULL}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MASTER_ROOT="${MASTER_ROOT:-${PROJECT}/runs/OACD_R3_HCRV_BUSI_ABL100_${ROOT_ID}}"

case "${ARM}" in
  FULL|R8_SEARCH_RANGE|NO_CENSORED_SUPERVISION|NO_RELATIONAL_VOLUME|NO_HIERARCHICAL_DECISION) ;;
  *) echo "Unknown ARM=${ARM}" >&2; exit 2 ;;
esac
if [[ "${ALLOW_ABLATION100:-0}" != "1" ]]; then
  echo "Set ALLOW_ABLATION100=1 after freezing the five-arm BUSI ablation plan." >&2
  exit 9
fi

CONFIG="configs/ucfnrt_oacd_r3/ablations/BUSI_OACD_R3_HCRV_ABL100_${ARM}.yaml"
RUN_TAG="SEMLT_OACD_R3_HCRV_ABL100_${ARM}_BUSI_S${SEED}"
RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"
RUN_ROOT="${MASTER_ROOT}/${ARM}/seed${SEED}"
TEST_ROOT="${RUN_ROOT}/formal_test"
STATE_DIR="${RUN_ROOT}/state"
LOG_DIR="${RUN_ROOT}/logs"

cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
export TOKENIZERS_PARALLELISM=false
export TRANSFORMERS_OFFLINE=1
export HF_HUB_OFFLINE=1
export CUBLAS_WORKSPACE_CONFIG="${CUBLAS_WORKSPACE_CONFIG:-:4096:8}"
export NVIDIA_TF32_OVERRIDE=0

[[ -x "${PYTHON}" ]] || { echo "python is not executable: ${PYTHON}" >&2; exit 2; }
[[ -f "${CONFIG}" ]] || { echo "missing ${CONFIG}" >&2; exit 3; }
for path in Train_Folder Test_Folder Prompts_Folder; do
  [[ -d "data/BUSI/${path}" ]] || { echo "missing data/BUSI/${path}" >&2; exit 3; }
done

mkdir -p "${STATE_DIR}" "${LOG_DIR}"
cp "${CONFIG}" "${STATE_DIR}/CONFIG_SOURCE.yaml"
sha256sum "${CONFIG}" > "${STATE_DIR}/CONFIG_SOURCE.sha256"

OVERRIDES=(
  DATASET.NAME BUSI
  DATASET.TRAIN_PATH ./data/BUSI/Train_Folder/
  DATASET.VAL_PATH ./data/BUSI/Val_Folder/
  DATASET.TEST_PATH ./data/BUSI/Test_Folder/
  DATASET.TEXT_PROMPT_PATH ./data/BUSI/Prompts_Folder/
  M1.RUN_TAG "${RUN_TAG}"
  TRAIN.RUN_TAG "${RUN_TAG}"
)

"${PYTHON}" tools/test_oacd_r3_hcrv_contract.py

TRAIN_SUCCESS="${STATE_DIR}/TRAIN_SUCCESS"
TEST_OPENED="${STATE_DIR}/TEST_OPENED"
TEST_SUCCESS="${STATE_DIR}/TEST_SUCCESS"
if [[ ! -f "${TRAIN_SUCCESS}" ]]; then
  CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
    --config-file "${CONFIG}" --seed "${SEED}" --output-dir "${RUN_ROOT}" \
    "${OVERRIDES[@]}" 2>&1 | tee "${LOG_DIR}/train.log"
  CKPT="${RUN_ROOT}/BUSI/trained_models/seed${SEED}/${RUN_NAME}_last_epoch.pth"
  [[ -f "${CKPT}" ]] || { echo "missing checkpoint: ${CKPT}" >&2; exit 4; }
  printf 'checkpoint=%s\nsha256=%s\n' "${CKPT}" "$(sha256sum "${CKPT}" | awk '{print $1}')" \
    > "${TRAIN_SUCCESS}"
else
  CKPT="$(sed -n 's/^checkpoint=//p' "${TRAIN_SUCCESS}" | head -n 1)"
  [[ -f "${CKPT}" ]] || { echo "recorded checkpoint is missing" >&2; exit 4; }
fi

if [[ ! -f "${TEST_SUCCESS}" ]]; then
  [[ ! -f "${TEST_OPENED}" ]] || {
    echo "Test was opened by an incomplete prior attempt; use a new ROOT_ID" >&2; exit 5;
  }
  printf 'checkpoint=%s\nopened_at=%s\n' "${CKPT}" "$(date --iso-8601=seconds)" > "${TEST_OPENED}"
  CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u test.py \
    --config-file "${CONFIG}" --seed "${SEED}" --split test \
    --num-samples 30 --checkpoint "${CKPT}" --output-dir "${TEST_ROOT}" \
    "${OVERRIDES[@]}" 2>&1 | tee "${LOG_DIR}/test.log"
  date --iso-8601=seconds > "${TEST_SUCCESS}"
fi

RESULT_ROOT="${TEST_ROOT}/BUSI/seg_results/seed${SEED}"
evaluate_one() {
  local result_name="$1" csv_name="$2" nsd_mode="$3"
  "${PYTHON}" -u utils/eval.py \
    --config-file "${CONFIG}" --seed "${SEED}" --split test \
    --output-dir "${TEST_ROOT}" --result-name "${result_name}" \
    --csv-name "${csv_name}" --nsd-mode "${nsd_mode}" \
    "${OVERRIDES[@]}"
}

evaluate_one "${RUN_NAME}_BaseNative" test_BaseNative_true2d.csv true2d
evaluate_one "${RUN_NAME}_M1Native" test_M1Native_true2d.csv true2d
evaluate_one "${RUN_NAME}_BaseNative" test_BaseNative_paper_legacy.csv paper_legacy
evaluate_one "${RUN_NAME}_M1Native" test_M1Native_paper_legacy.csv paper_legacy

for mode in true2d paper_legacy; do
  "${PYTHON}" tools/compare_geotr_m1_paired.py \
    --base-csv "${RESULT_ROOT}/test_BaseNative_${mode}.csv" \
    --m1-csv "${RESULT_ROOT}/test_M1Native_${mode}.csv" \
    --output-prefix "${RESULT_ROOT}/paired_${mode}" \
    --protocol-label "BUSI_OACD_R3_HCRV_ABL100_${ARM}_${mode}_seed${SEED}"
done

date --iso-8601=seconds > "${STATE_DIR}/ARM_COMPLETE"
echo "BUSI ablation complete: arm=${ARM} result=${RESULT_ROOT}"
