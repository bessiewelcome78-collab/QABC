#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:-BUSI}"; GPU="${GPU:-0}"; SEED="${SEED:-42}"; EXP_ID="${EXP_ID:-$(date +%Y%m%d_%H%M%S)}"
RUN_ROOT="${RUN_ROOT:-runs/SEMLT_AUTOZERO_E2E100_${EXP_ID}}"
cd "${PROJECT}"; export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"; export TOKENIZERS_PARALLELISM=false
case "${DATASET}" in BUSI|BTMRI|ISIC|Kvasir) ;; *) echo '[FAIL] DATASET must be BUSI|BTMRI|ISIC|Kvasir'; exit 2;; esac
CONFIG="configs/${DATASET}_SEMLT_AUTOZERO_E2E100.yaml"
DATA_ROOT="${PROJECT}/data/${DATASET}"; TRAIN_PATH="${DATA_ROOT}/Train_Folder/"; VAL_PATH="${DATA_ROOT}/Val_Folder/"; TEST_PATH="${DATA_ROOT}/Test_Folder/"; PROMPT_PATH="${DATA_ROOT}/Prompts_Folder/"
for p in "${CONFIG}" "${TRAIN_PATH}" "${VAL_PATH}" "${TEST_PATH}" "${PROMPT_PATH}"; do [[ -e "${p}" ]] || { echo "[FAIL] missing ${p}"; exit 2; }; done
RUN_TAG="SEMLT_AUTOZERO_E2E100_${DATASET}"; RUN_DIR="${RUN_ROOT}/${DATASET}/seed${SEED}"; mkdir -p "${RUN_DIR}" logs
"${PYTHON}" tools/check_semlt_autozero_configs.py >/dev/null
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py --config-file "${CONFIG}" --seed "${SEED}" --output-dir "${RUN_DIR}" \
 TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" DATASET.NAME "${DATASET}" \
 DATASET.TRAIN_PATH "${TRAIN_PATH}" DATASET.VAL_PATH "${VAL_PATH}" DATASET.TEST_PATH "${TEST_PATH}" DATASET.TEXT_PROMPT_PATH "${PROMPT_PATH}" \
 2>&1 | tee -a "logs/${RUN_TAG}_seed${SEED}_gpu${GPU}_${EXP_ID}.log"
