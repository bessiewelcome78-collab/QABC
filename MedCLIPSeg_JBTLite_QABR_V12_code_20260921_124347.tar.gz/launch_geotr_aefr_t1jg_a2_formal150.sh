#!/usr/bin/env bash
set -Eeuo pipefail
[[ "${AEFR_TRANSITION_FORMAL_APPROVED:-NO}" == "YES" ]] || { echo "[BLOCKED] FORMAL150 requires AEFR_TRANSITION_FORMAL_APPROVED=YES after the matching SG/JG DIAG readiness passes"; exit 2; }
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"; PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"; GPU="${GPU:-2}"; SEED="${SEED:-42}"
cd "${PROJECT}" || exit 1; export TOKENIZERS_PARALLELISM=false
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs runs
LOG="logs/GEOTR_AEFR_T1JG_A2_FORMAL150_seed${SEED}_gpu${GPU}_${STAMP}.log"
PYTHONPATH=. "${PYTHON}" tools/test_geotr_aefr_transition_contract.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_aefr_transition_configs.py
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py --config-file "configs/BUSI_GEOTR_AEFR_T1JG_A2_FORMAL150.yaml" --seed "${SEED}" --output-dir "runs/GEOTR_AEFR_T1JG_A2_FORMAL150_seed${SEED}_${STAMP}" 2>&1 | tee "${LOG}"
"${PYTHON}" tools/diagnose_geotr_aefr_log.py "${LOG}" || true
