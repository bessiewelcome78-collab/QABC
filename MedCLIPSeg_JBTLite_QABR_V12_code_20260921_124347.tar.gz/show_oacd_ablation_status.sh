#!/usr/bin/env bash
set -euo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
STUDY_ID="${STUDY_ID:?STUDY_ID required}"
STUDY_ID="${STUDY_ID#OACD_ABL_}"
SEED="${SEED:-42}"
ARM="${ARM:?ARM required}"
LOG_ROOT="$PROJECT/logs/UCFNRT_OACD_ABL_${STUDY_ID}_S${SEED}"
RUN_ROOT="$PROJECT/runs/UCFNRT_OACD_ABL_${STUDY_ID}_S${SEED}/${ARM}"
echo "LOG_ROOT=$LOG_ROOT"
echo "RUN_ROOT=$RUN_ROOT"
for f in contract train test eval_base_true2d eval_m1_true2d eval_base_legacy eval_m1_legacy; do
  p="$LOG_ROOT/${ARM}.${f}.log"
  [[ -f "$p" ]] && { echo "--- $p"; tail -n 25 "$p"; }
done
[[ -f "$RUN_ROOT/result.json" ]] && { echo '--- result.json'; cat "$RUN_ROOT/result.json"; }
[[ -f "$RUN_ROOT/SUCCESS.lock" ]] && echo '[PASS] SUCCESS.lock present'
