#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
GPU="${GPU:?physical GPU index required}"
VARIANT="${VARIANT:?variant required}"
SEED="${SEED:-42}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"

case "$VARIANT" in
  C0_LEGACY_MATCH)
    OPERATOR_ALIGNED=false; ORDERED_CDF=false; REACHABLE_ONLY=false ;;
  C1_OPERATOR_ALIGNED)
    OPERATOR_ALIGNED=true; ORDERED_CDF=false; REACHABLE_ONLY=false ;;
  C2_ALIGNED_ORDERED)
    OPERATOR_ALIGNED=true; ORDERED_CDF=true; REACHABLE_ONLY=false ;;
  C3_ALIGNED_ORDERED_REACHABLE)
    OPERATOR_ALIGNED=true; ORDERED_CDF=true; REACHABLE_ONLY=true ;;
  *) echo "[FAIL] unknown VARIANT=$VARIANT"; exit 2 ;;
esac

cd "$PROJECT"
export PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}"
export TOKENIZERS_PARALLELISM=false
export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True}"
export CUBLAS_WORKSPACE_CONFIG="${CUBLAS_WORKSPACE_CONFIG:-:4096:8}"
export NVIDIA_TF32_OVERRIDE=0
unset PYTORCH_CUDA_ALLOC_CONF 2>/dev/null || true

CONFIG="configs/ucfnrt_oacd_diag20/BUSI_OACD_LOCKED_DIAG20.yaml"
[[ -f "$CONFIG" ]] || { echo "[FAIL] missing config: $CONFIG"; exit 3; }
FREE="$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | awk -F',' -v g="$GPU" '$1+0==g{gsub(/ /,"",$2);print $2;exit}')"
[[ -n "$FREE" ]] || { echo "[FAIL] GPU$GPU not found"; exit 4; }
if (( FREE < MIN_FREE_MIB )); then
  echo "[FAIL] GPU$GPU free=${FREE}MiB < ${MIN_FREE_MIB}MiB"; exit 5
fi

RUN_ROOT="$PROJECT/runs/UCFNRT_OACD_DIAG20_${ROOT_ID}/seed${SEED}/BUSI/${VARIANT}"
STATE_DIR="$RUN_ROOT/formal_state"
LOG="$PROJECT/logs/UCFNRT_OACD_${ROOT_ID}_${VARIANT}_S${SEED}.log"
SUCCESS="$STATE_DIR/TRAIN_SUCCESS.lock"
mkdir -p "$PROJECT/logs"
if [[ -f "$SUCCESS" ]]; then
  echo "[SKIP PASS] $VARIANT already complete: $SUCCESS"; exit 0
fi
if [[ -d "$RUN_ROOT" && -n "$(find "$RUN_ROOT" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  ARCH="$PROJECT/runs/UCFNRT_OACD_DIAG20_${ROOT_ID}/seed${SEED}/BUSI/failed_attempts/${VARIANT}_$(date +%Y%m%d_%H%M%S)"
  mkdir -p "$(dirname "$ARCH")"
  mv "$RUN_ROOT" "$ARCH"
  echo "[RECOVER] archived incomplete attempt -> $ARCH"
fi
mkdir -p "$STATE_DIR"

echo "================================================================================"
echo "UC-FNRT OPERATOR-ALIGNED CORRESPONDENCE DISTRIBUTION | TRAIN-ONLY DIAG20"
echo "VARIANT=$VARIANT GPU=$GPU SEED=$SEED"
echo "CONFIG=$CONFIG"
echo "RUN_ROOT=$RUN_ROOT"
echo "LOCKED: BUSI | 20 physical epochs | horizon100 | batch24 | TrainMC10 | radius8"
echo "LOCKED: same modules/parameters/optimizer; raw posterior/ray; expectation decoder"
echo "LOCKED: strict Base parity audit | TF32 off | Val/Test SEALED"
echo "SWITCHES: operator_aligned=$OPERATOR_ALIGNED ordered_cdf=$ORDERED_CDF reachable_only=$REACHABLE_ONLY"
echo "C0: archived evidence sign + archived NLL/mean-regression"
echo "C1: only inverse-warp-to-evidence coordinate conversion d -> -d"
echo "C2: C1 + proper ordered log-score/CRPS objective"
echo "C3: C2 + correspondence score only on rays with an observed GT crossing"
echo "================================================================================"

CUDA_VISIBLE_DEVICES="$GPU" "$PYTHON" -u train.py \
  --config-file "$CONFIG" \
  --seed "$SEED" \
  --output-dir "$RUN_ROOT" \
  M1.RUN_TAG "SEMLT_UCFNRT_OACD_${VARIANT}_DIAG20_BUSI" \
  TRAIN.RUN_TAG "SEMLT_UCFNRT_OACD_${VARIANT}_DIAG20_BUSI" \
  M1.SEMLT_UC_OPERATOR_ALIGNED_CANDIDATES "$OPERATOR_ALIGNED" \
  M1.SEMLT_UC_ORDERED_CDF_LOSS "$ORDERED_CDF" \
  M1.SEMLT_UC_REACHABLE_MATCH_ONLY "$REACHABLE_ONLY" \
  2>&1 | tee "$LOG"

mapfile -t CKPTS < <(find "$RUN_ROOT/BUSI/trained_models/seed${SEED}" -maxdepth 1 -type f -name '*_last_epoch.pth' -print 2>/dev/null | sort)
if (( ${#CKPTS[@]} != 1 )); then
  echo "[FAIL] expected exactly one physical last-epoch checkpoint, got ${#CKPTS[@]}"
  printf '  %s\n' "${CKPTS[@]:-}"
  exit 10
fi
printf 'completed_at=%s\nvariant=%s\ncheckpoint=%s\n' \
  "$(date --iso-8601=seconds)" "$VARIANT" "${CKPTS[0]}" > "$SUCCESS"
echo "[PASS] $VARIANT DIAG20 TRAIN SEALED; Val/Test unopened"
