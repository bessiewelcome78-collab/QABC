#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
for f in launch_lest59_one_dataset_trainval.sh launch_lest59_all4_seed.sh launch_lest59_all4_3seeds.sh launch_lest59_all4_test_once.sh launch_geotr_m1_causal56_run.sh; do bash -n "$f"; done
"${PYTHON}" -m py_compile tools/lest59_test_once.py tools/lest59_collect_results.py utils/geotr_m1_loss.py utils/geotr_m1_transport.py tools/audit_geotr_m1_dataset.py
"${PYTHON}" tools/test_geotr_m1_lest58_unified.py
for ds in BUSI BTMRI ISIC Kvasir; do
  "${PYTHON}" tools/test_geotr_m1_causal56_contract.py --config-file "configs/${ds}_LEST59_UNIFIED_ANISO100.yaml"
  for p in "data/${ds}/Train_Folder" "data/${ds}/Val_Folder" "data/${ds}/Test_Folder" "data/${ds}/Prompts_Folder"; do [[ -e "$p" ]] || { echo "[FAIL] missing $p"; exit 2; }; done
done
echo "[PASS] LeST59 all-four preflight: configs, contracts, paths and launch syntax"
