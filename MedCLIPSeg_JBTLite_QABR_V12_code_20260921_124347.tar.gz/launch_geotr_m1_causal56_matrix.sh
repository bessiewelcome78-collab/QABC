#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
DATASET="${DATASET:-BUSI}"
BASE_CHECKPOINT="${BASE_CHECKPOINT:-}"
VARIANTS="${VARIANTS:-core core_edge no_anchor prob_warp no_deform semantic full}"
cd "${PROJECT}"

[[ -n "${BASE_CHECKPOINT}" && -f "${BASE_CHECKPOINT}" ]] || {
  echo "[FAIL] export BASE_CHECKPOINT=/absolute/path/to/common_Base100_last_epoch.pth"; exit 2;
}

for variant in ${VARIANTS}; do
  echo "===================================================================================================="
  echo "[CAUSAL56 MATRIX] variant=${variant}"
  GPU="${GPU}" SEED="${SEED}" DATASET="${DATASET}" VARIANT="${variant}" \
    BASE_CHECKPOINT="${BASE_CHECKPOINT}" PYTHON="${PYTHON}" \
    bash launch_geotr_m1_causal56_run.sh
done

"${PYTHON}" tools/analyze_geotr_m1_ablation_logs.py \
  --logs-dir logs \
  --protocol causal56 \
  --output-prefix "audits/GEOTR_M1_CAUSAL56_${DATASET}_seed${SEED}_summary" || true
echo "[PASS] CAUSAL56 matrix complete"
