# QABR 审稿人补充消融实验（双 GPU 顺序队列）

## 1. 实验范围

默认 `RUN_SET=all` 会在 BUSI 与 Kvasir 上分别运行：

- 10 个论文核心消融（seed 42）；
- 5 个增强诊断/训练敏感性实验（seed 42）；
- Base 与 Full 的 seed 123、789 确认实验（和 seed 42 组成三种子）；
- 复用 seed42 Full checkpoint 的 3 个推理尺度敏感性评估。

GPU_BUSI 内部严格顺序运行 BUSI，GPU_KVASIR 内部严格顺序运行 Kvasir；
两张 GPU 彼此并行。所有训练均采用 Val MC10 选择 best checkpoint，随后只打开
一次 Test MC30。主报告指标是 corrected `true2d NSD@2px`，legacy NSD 仅作为历史
参考输出。

若只想运行论文核心 10 组，把 `RUN_SET=paper_core`；三种子确认仍由
`RUN_CONFIRM=1` 控制。

## 2. 预检

```bash
cd /home/tsz-25/MedCLIPSeg_JBTLite_QABR_V12_20260911 || exit 1

PROJECT="$PWD" \
PYTHON=/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python \
DATA_DIR=/home/tsz-25/MedCLIPSeg-main/data \
bash scripts/jbtlite/qabr_reviewer_ablation_2gpu/preflight.sh
```

## 3. 两张 GPU 后台启动全部实验

下面示例使用 GPU 2 跑 BUSI，GPU 3 跑 Kvasir：

```bash
cd /home/tsz-25/MedCLIPSeg_JBTLite_QABR_V12_20260911 || exit 1

PROJECT="$PWD" \
PYTHON=/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python \
DATA_DIR=/home/tsz-25/MedCLIPSeg-main/data \
GPU_BUSI=2 \
GPU_KVASIR=3 \
RUN_SET=all \
RUN_CONFIRM=1 \
CONFIRM_SEEDS="123 789" \
bash scripts/jbtlite/qabr_reviewer_ablation_2gpu/start_2gpu_background.sh
```

不要同时启动第二个相同 study。每个 run 拒绝覆盖既有 partial checkpoint；若需要
重新开始，请使用新的 `STUDY_ID`。

## 4. 查看状态

```bash
cd /home/tsz-25/MedCLIPSeg_JBTLite_QABR_V12_20260911 || exit 1
export STUDY_ID="$(cat QABR_REVIEW_ABLATION_ACTIVE.txt)"

bash scripts/jbtlite/qabr_reviewer_ablation_2gpu/status.sh
```

持续查看两个队列：

```bash
watch -n 30 'cd /home/tsz-25/MedCLIPSeg_JBTLite_QABR_V12_20260911 && STUDY_ID="$(cat QABR_REVIEW_ABLATION_ACTIVE.txt)" bash scripts/jbtlite/qabr_reviewer_ablation_2gpu/status.sh'
```

## 5. 最终统计

驱动脚本在两个队列都成功结束后会自动统计。也可以手动重建统计表：

```bash
cd /home/tsz-25/MedCLIPSeg_JBTLite_QABR_V12_20260911 || exit 1
export STUDY_ID="$(cat QABR_REVIEW_ABLATION_ACTIVE.txt)"

bash scripts/jbtlite/qabr_reviewer_ablation_2gpu/summarize.sh
```

输出位于：

```text
reviewer_ablation_results/$STUDY_ID/FINAL_RESULTS.csv
reviewer_ablation_results/$STUDY_ID/FINAL_PAPER_ABLATION.csv
reviewer_ablation_results/$STUDY_ID/FINAL_MULTI_SEED.csv
reviewer_ablation_results/$STUDY_ID/FINAL_PAIRED_BOOTSTRAP.csv
```

其中：

- `FINAL_RESULTS.csv`：全部实验，含 Val/Test、true2D/legacy、阳性与空 GT 子集；
- `FINAL_PAPER_ABLATION.csv`：论文核心 seed42 表；
- `FINAL_MULTI_SEED.csv`：Base/Full 三种子 mean±std；
- `FINAL_PAIRED_BOOTSTRAP.csv`：逐病例 Base–Full 配对增益、95% CI、提升率和 harm rate。

## 6. 论文表格建议

正文优先放以下 10 行：Base、Naive Global、w/o Local、Local Only、
Local+Direction、Local+Semantic、w/o Tangent、Direct Residual、w/o Readiness、
Full。Band、Delta、Scale 和显式 query-channel 诊断放补充材料或正文一句话总结。
