# QABR Efficiency 补充实验

本补丁用于验证论文中的“parameter-efficient”表述。它不重新训练模型，而是复用统一审稿实验中 Kvasir seed=42 的 BASE 和 FULL 最佳验证 checkpoint。

最终输出：
- `FINAL_EFFICIENCY.csv`
- `FINAL_EFFICIENCY_VERDICT.txt`
- `FINAL_EFFICIENCY_LATEX_ROWS.txt`

核心检查：
1. FULL 的 QABR 子模块参数必须恰好为 8,882；
2. FULL - BASE 的总参数差必须恰好为 8,882；
3. FULL - BASE 的可训练参数差必须恰好为 8,882；
4. 报告 MC1 与 MC30 batch=1 forward latency；
5. 报告 MC30 CUDA peak allocated memory；
6. 报告 QABR 每个 MC sample 的增量 Conv FLOPs。

默认顺序：`BASE -> FULL`，单 GPU 后台执行。
