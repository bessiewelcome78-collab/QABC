#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-python}"

[[ -d "${TARGET}" && -f "${TARGET}/train.py" ]] || {
  echo "[FAIL] target is not a MedCLIPSeg project: ${TARGET}"; exit 2;
}

# Install the already audited physical M1-only/common-Base baseline first.
PYTHON="${PYTHON}" bash "${SOURCE}/install_geotr_m1_causal56.sh" "${TARGET}"

STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="${TARGET}_code_backups/before_GEOTR_M1_LEST57_${STAMP}"
mkdir -p "${BACKUP}"
FILES=(
  install_geotr_m1_lest57.sh
  GEOTR_M1_LEST57_VERSION.txt
  GEOTR_M1_LEST57_DESIGN_AND_RUN_CN.md
  GEOTR_M1_LEST57_MODIFIED_FILES.txt
  utils/geotr_m1_transport.py
  utils/geotr_m1_loss.py
  configs/BUSI_GEOTR_M1_CAUSAL56_ABLATION100.yaml
  configs/BUSI_GEOTR_M1_CAUSAL56_E2E100.yaml
  launch_geotr_m1_causal56_run.sh
  launch_geotr_m1_lest57_preflight.sh
  launch_geotr_m1_lest57_matrix.sh
  launch_geotr_m1_lest57_e2e100.sh
  launch_geotr_m1_lest57_background.sh
  launch_geotr_m1_lest5701_all_parallel.sh
  tools/audit_geotr_m1_dataset.py
  tools/test_geotr_m1_dataset_audit.py
  tools/test_geotr_m1_lest57_contract.py
  tools/analyze_geotr_m1_ablation_logs.py
)

for relative in "${FILES[@]}"; do
  [[ -f "${SOURCE}/${relative}" ]] || { echo "[FAIL] missing source: ${relative}"; exit 2; }
  if [[ -f "${TARGET}/${relative}" ]]; then
    mkdir -p "${BACKUP}/$(dirname "${relative}")"
    cp -a "${TARGET}/${relative}" "${BACKUP}/${relative}"
  fi
  mkdir -p "${TARGET}/$(dirname "${relative}")"
  cp -a "${SOURCE}/${relative}" "${TARGET}/${relative}"
  cmp -s "${SOURCE}/${relative}" "${TARGET}/${relative}" || {
    echo "[FAIL] installed file differs: ${relative}"; exit 2;
  }
  echo "[OK] ${relative}"
done

chmod +x "${TARGET}"/install_geotr_m1_lest57.sh \
  "${TARGET}"/launch_geotr_m1_lest57_*.sh \
  "${TARGET}"/tools/audit_geotr_m1_dataset.py \
  "${TARGET}"/tools/test_geotr_m1_dataset_audit.py \
  "${TARGET}"/tools/test_geotr_m1_lest57_contract.py 2>/dev/null || true

PYTHON="${PYTHON}" PROJECT="${TARGET}" \
  bash "${TARGET}/launch_geotr_m1_lest57_preflight.sh"
echo "[PASS] GEOTR-M1 LeST57.0.2 installed"
echo "备份目录：${BACKUP}"
