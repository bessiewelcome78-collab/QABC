# JBTL16 Ownership Fix (two-day closeout patch)

This patch addresses two concrete coupling bugs in JBTL15:

1. QABR parameters were included in the `official_base_exact` Adam parameter list.
   JBTL16 keeps the protected host group identical to BASE and places `qabr.*` in a separate Adam parameter group.
2. In FULL, the Surface edge loss was evaluated on QABR's zero-forward shadow logits, so it still backpropagated into QABR.
   JBTL16 adds `RBAL_EDGE_GRAD_SCOPE: host_only` for FULL: Dice/CE trains Host+QABR, while Surface EDGE updates only factual host parameters and explicitly excludes `qabr.*`.

The QABR operator itself is unchanged. This is an ownership fix, not another architecture redesign.

## Apply

```bash
cd /home/tsz-25/MedCLIPSeg_JBTLite_QABR_V12_20260911 || exit 1
cp -a train.py train.py.pre_jbtl16_$(date +%Y%m%d_%H%M%S)
cp -a trainers/qabr.py trainers/qabr.py.pre_jbtl16_$(date +%Y%m%d_%H%M%S)
# copy the patch tree over the project root
cp -a /PATH/TO/JBTL16_OWNERSHIP_FIX_patch_20260911/. .
python -m py_compile train.py trainers/qabr.py
```

## Gate 1: 2-epoch causal ownership audit

```bash
cd /home/tsz-25/MedCLIPSeg_JBTLite_QABR_V12_20260911 || exit 1
PROJECT=$PWD GPU=0 SEED=42 bash scripts/jbtlite/qabr_v16/run_ownership_gate2.sh
```

Do not continue unless BASE==QABR protected hashes and SURFACE==FULL protected hashes.

## Gate 2: BUSI DIAG40

```bash
STUDY_ID="JBTL16_BUSI_DIAG40_S42_$(date +%Y%m%d_%H%M%S)" \
PROJECT=$PWD GPU=0 SEED=42 \
bash scripts/jbtlite/qabr_v16/launch_busi_diag40_samegpu.sh
```

Success criterion: FULL must at least not degrade the better single arm on Val; preferred target is FULL > max(SURFACE,QABR) by >=0.2 Dice or a clear true2d NSD gain without Dice loss.

## Formal seed-42 run

After the gate passes, use the formal launcher. BUSI runs BASE/SURFACE/QABR/FULL sequentially on one GPU; Kvasir/ISIC/BTMRI FULL run in parallel on three other GPUs.

```bash
STUDY_ID="JBTL16_SEED42_FORMAL100_$(date +%Y%m%d_%H%M%S)" \
PROJECT=$PWD PYTHON=/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python \
DATA_DIR=/home/tsz-25/MedCLIPSeg-main/data SEED=42 \
GPU_BUSI=0 GPU_KVASIR=1 GPU_ISIC=2 GPU_BTMRI=3 \
nohup bash scripts/jbtlite/qabr_v16/launch_seed42_busi_ablation_other3_full.sh \
> "logs/${STUDY_ID}.driver.log" 2>&1 &
```
