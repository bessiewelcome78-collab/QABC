#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
cd "${PROJECT}" || exit 1
SEED="${SEED:-42}"
GPU_A0="${GPU_A0:-0}"; GPU_A1="${GPU_A1:-1}"; GPU_A2="${GPU_A2:-2}"; GPU_A3="${GPU_A3:-3}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs
for spec in "A0:${GPU_A0}" "A1:${GPU_A1}" "A2:${GPU_A2}" "A3:${GPU_A3}"; do
  A="${spec%%:*}"; G="${spec##*:}"; a="$(echo "$A" | tr 'A-Z' 'a-z')"
  GPU="$G" SEED="$SEED" bash "launch_geotr_pc2rv3_${a}_formal150.sh" > "logs/GEOTR_PC2RV3_${A}_FORMAL150_driver_${STAMP}.log" 2>&1 &
  eval "P_${A}=$!"
done
FAIL=0
for A in A0 A1 A2 A3; do
  eval "P=\$P_${A}"
  wait "$P" || FAIL=1
done
[[ "$FAIL" == 0 ]] || { echo "[ERROR] one or more GEOTR-PC2R-v3 FORMAL150 runs failed"; exit 1; }
echo "[PASS] GEOTR-PC2R-v3 A0-A3 FORMAL150 finished"
