#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="/home/tsz-25/MedCLIPSeg-pristine"
PYTHON="/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python"

ROOT_ID="${ROOT_ID:-20260831_132730}"
SEED="${SEED:-42}"
GPU="${GPU:-0}"

DATASET="BUSI"
VARIANT="NO_POSTERIOR"

CONFIG="configs/ucfnrt_causal_ablation/BUSI_NO_POSTERIOR_PAPER100.yaml"

ROOT="${PROJECT}/runs/UCFNRT_CAUSAL_ABL_${ROOT_ID}/seed${SEED}"
RUN_DIR="${ROOT}/${DATASET}/${VARIANT}"
STATE="${RUN_DIR}/formal_state"
MANIFEST="${STATE}/TRAIN_MANIFEST.json"

cd "${PROJECT}"

export PYTHONPATH="${PROJECT}:${PROJECT}/utils:${PYTHONPATH:-}"
export TOKENIZERS_PARALLELISM=false
export HF_HOME="${PROJECT}/checkpoints"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_DATASETS_OFFLINE=1
export PYTORCH_ALLOC_CONF=expandable_segments:True
unset PYTORCH_CUDA_ALLOC_CONF 2>/dev/null || true

fail() {
    echo "[FAIL] $*" >&2
    exit 1
}

echo "============================================================"
echo "UC-FNRT SINGLE ABLATION PREVIEW"
echo "ROOT_ID=${ROOT_ID}"
echo "DATASET=${DATASET}"
echo "VARIANT=${VARIANT}"
echo "SEED=${SEED}"
echo "PHYSICAL_GPU=${GPU}"
echo "============================================================"

# ------------------------------------------------------------
# A. Verify sealed training
# ------------------------------------------------------------
[[ -f "${STATE}/TRAIN_SUCCESS.lock" ]] || \
    fail "TRAIN_SUCCESS.lock missing: ${STATE}/TRAIN_SUCCESS.lock"

[[ -f "${MANIFEST}" ]] || \
    fail "TRAIN_MANIFEST.json missing: ${MANIFEST}"

echo "[PASS] training lock found"
echo "[PASS] manifest found"

# ------------------------------------------------------------
# B. Read exact physical-last checkpoint from manifest
# ------------------------------------------------------------
CKPT="$("${PYTHON}" -c '
import json,sys
print(json.load(open(sys.argv[1]))["checkpoint"])
' "${MANIFEST}")"

EXPECT_SHA="$("${PYTHON}" -c '
import json,sys
print(json.load(open(sys.argv[1]))["checkpoint_sha256"])
' "${MANIFEST}")"

if [[ "${CKPT}" != /* ]]; then
    CKPT="${PROJECT}/${CKPT}"
fi

[[ -f "${CKPT}" ]] || fail "checkpoint missing: ${CKPT}"

GOT_SHA="$(sha256sum "${CKPT}" | awk '{print $1}')"

echo "CHECKPOINT=${CKPT}"
echo "EXPECTED_SHA=${EXPECT_SHA}"
echo "CURRENT_SHA=${GOT_SHA}"

[[ "${EXPECT_SHA}" == "${GOT_SHA}" ]] || \
    fail "checkpoint SHA changed after training"

echo "[PASS] physical epoch-100 checkpoint verified"

# Dynamically derive run name from actual checkpoint filename
RUN_NAME="$(basename "${CKPT}")"
RUN_NAME="${RUN_NAME%_last_epoch.pth}"

echo "RUN_NAME=${RUN_NAME}"

# ------------------------------------------------------------
# C. Separate preview output
# ------------------------------------------------------------
STAMP="$(date +%Y%m%d_%H%M%S)"

OUT="${RUN_DIR}/preview_test_${STAMP}"
DETAIL_LOG="${PROJECT}/logs/UCFNRT_ABL_${ROOT_ID}_BUSI_NO_POSTERIOR_S${SEED}_PREVIEW_${STAMP}.detail.log"

mkdir -p "${OUT}"
mkdir -p "${PROJECT}/logs"

echo "${OUT}" > "${STATE}/LAST_PREVIEW_TEST_DIR.txt"

echo "PREVIEW_OUT=${OUT}"
echo "DETAIL_LOG=${DETAIL_LOG}"

# ------------------------------------------------------------
# D. Test MC30
# ------------------------------------------------------------
echo
echo "============================================================"
echo "[1/6] TEST MC30"
echo "============================================================"

CUDA_VISIBLE_DEVICES="${GPU}" \
"${PYTHON}" -u test.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --split test \
    --prompt_design original \
    --num-samples 30 \
    --checkpoint "${CKPT}" \
    --output-dir "${OUT}" \
    2>&1 | tee "${DETAIL_LOG}"

echo "[PASS] test.py complete"

# ------------------------------------------------------------
# E. Discover actual generated prediction directories
# ------------------------------------------------------------
RR="${OUT}/${DATASET}/seg_results/seed${SEED}"

[[ -d "${RR}" ]] || fail "result root missing: ${RR}"

BASE_DIR="$(find "${RR}" -maxdepth 1 -type d \
    -name '*_BaseNative_Prompt-original' | head -n 1 || true)"

M1_DIR="$(find "${RR}" -maxdepth 1 -type d \
    -name '*_M1Native_Prompt-original' | head -n 1 || true)"

[[ -n "${BASE_DIR}" ]] || \
    fail "BaseNative prediction directory not found under ${RR}"

[[ -n "${M1_DIR}" ]] || \
    fail "M1Native prediction directory not found under ${RR}"

BASE="$(basename "${BASE_DIR}")"
BASE="${BASE%_Prompt-original}"

M1="$(basename "${M1_DIR}")"
M1="${M1%_Prompt-original}"

echo
echo "BASE_RESULT=${BASE}"
echo "M1_RESULT=${M1}"

eval_one() {
    local NAME="$1"
    local CSV="$2"
    local MODE="$3"

    "${PYTHON}" -u utils/eval.py \
        --config-file "${CONFIG}" \
        --seed "${SEED}" \
        --split test \
        --prompt_design original \
        --output-dir "${OUT}" \
        --result-name "${NAME}" \
        --csv-name "${CSV}" \
        --nsd-mode "${MODE}" \
        2>&1 | tee -a "${DETAIL_LOG}"
}

# ------------------------------------------------------------
# F. corrected true2d
# ------------------------------------------------------------
echo
echo "============================================================"
echo "[2/6] Base true2d"
echo "============================================================"

eval_one \
    "${BASE}" \
    "test_BaseNative_true2d.csv" \
    "true2d"

echo
echo "============================================================"
echo "[3/6] NO_POSTERIOR true2d"
echo "============================================================"

eval_one \
    "${M1}" \
    "test_M1Native_true2d.csv" \
    "true2d"

# ------------------------------------------------------------
# G. paper legacy
# ------------------------------------------------------------
echo
echo "============================================================"
echo "[4/6] Base paper_legacy"
echo "============================================================"

eval_one \
    "${BASE}" \
    "test_BaseNative_paper_legacy.csv" \
    "paper_legacy"

echo
echo "============================================================"
echo "[5/6] NO_POSTERIOR paper_legacy"
echo "============================================================"

eval_one \
    "${M1}" \
    "test_M1Native_paper_legacy.csv" \
    "paper_legacy"

# ------------------------------------------------------------
# H. paired statistics
# ------------------------------------------------------------
echo
echo "============================================================"
echo "[6/6] Paired statistics"
echo "============================================================"

"${PYTHON}" -u tools/compare_geotr_m1_paired.py \
    --base-csv "${RR}/test_BaseNative_true2d.csv" \
    --m1-csv "${RR}/test_M1Native_true2d.csv" \
    --output-prefix "${RR}/paired_true2d" \
    --protocol-label "BUSI_NO_POSTERIOR_UCFNRT_ABL_true2d_seed${SEED}" \
    2>&1 | tee -a "${DETAIL_LOG}"

"${PYTHON}" -u tools/compare_geotr_m1_paired.py \
    --base-csv "${RR}/test_BaseNative_paper_legacy.csv" \
    --m1-csv "${RR}/test_M1Native_paper_legacy.csv" \
    --output-prefix "${RR}/paired_paper_legacy" \
    --protocol-label "BUSI_NO_POSTERIOR_UCFNRT_ABL_paper_legacy_seed${SEED}" \
    2>&1 | tee -a "${DETAIL_LOG}"

# ------------------------------------------------------------
# I. Print direct summary
# ------------------------------------------------------------
echo
echo "============================================================"
echo "DIRECT NUMERICAL SUMMARY"
echo "============================================================"

"${PYTHON}" - \
    "${RR}/test_BaseNative_true2d.csv" \
    "${RR}/test_M1Native_true2d.csv" \
    "${RR}/test_BaseNative_paper_legacy.csv" \
    "${RR}/test_M1Native_paper_legacy.csv" <<'PY'
import sys
import pandas as pd

bt = pd.read_csv(sys.argv[1])
mt = pd.read_csv(sys.argv[2])
bl = pd.read_csv(sys.argv[3])
ml = pd.read_csv(sys.argv[4])

def mean(df, col):
    return float(df[col].mean())

b_dsc = mean(bt, "DSC")
m_dsc = mean(mt, "DSC")

b_nsd_t = mean(bt, "NSD")
m_nsd_t = mean(mt, "NSD")

b_nsd_l = mean(bl, "NSD")
m_nsd_l = mean(ml, "NSD")

print()
print("BUSI / NO_POSTERIOR / seed42")
print("----------------------------------------------")
print(f"Base DSC             = {100*b_dsc:.4f}%")
print(f"NO_POSTERIOR DSC     = {100*m_dsc:.4f}%")
print(f"Delta DSC            = {100*(m_dsc-b_dsc):+.4f} pp")
print()
print(f"Base NSD true2d      = {100*b_nsd_t:.4f}%")
print(f"NO_POST NSD true2d   = {100*m_nsd_t:.4f}%")
print(f"Delta NSD true2d     = {100*(m_nsd_t-b_nsd_t):+.4f} pp")
print()
print(f"Base NSD legacy      = {100*b_nsd_l:.4f}%")
print(f"NO_POST NSD legacy   = {100*m_nsd_l:.4f}%")
print(f"Delta NSD legacy     = {100*(m_nsd_l-b_nsd_l):+.4f} pp")
print("----------------------------------------------")
PY

touch "${OUT}/PREVIEW_SUCCESS.lock"

echo
echo "============================================================"
echo "[PASS] PREVIEW TEST + EVALUATION COMPLETE"
echo "OUT=${OUT}"
echo "RESULT_ROOT=${RR}"
echo "TRUE2D_REPORT=${RR}/paired_true2d.md"
echo "LEGACY_REPORT=${RR}/paired_paper_legacy.md"
echo "DETAIL_LOG=${DETAIL_LOG}"
echo "============================================================"
