#!/usr/bin/env bash
# Validation-only diagnosis for choosing radius / future flow cap WITHOUT Test tuning.
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
SEED="${SEED:-42}"
EXP_ID="${EXP_ID:?EXP_ID is required}"
GPUS="${GPUS:-0,1,2,3}"
RADII="${RADII:-1,2,3,5,8,12}"
RADIUS="${RADIUS:-5}"
NULL_REPEATS="${NULL_REPEATS:-0}"
IFS=',' read -r -a G <<< "${GPUS}"
[[ ${#G[@]} -eq 4 ]] || { echo '[FAIL] GPUS must contain four ids'; exit 2; }
RUN_ROOT="${PROJECT}/runs/SEMLT_E2E100_MAIN_${EXP_ID}"
OUT_ROOT="${RUN_ROOT}/hypothesis_validation/seed${SEED}"
mkdir -p "${OUT_ROOT}" "${PROJECT}/logs"
D=(BUSI BTMRI ISIC Kvasir); P=()
for i in 0 1 2 3; do
  DS="${D[$i]}"; MAN="${RUN_ROOT}/${DS}/seed${SEED}/SEMLT_E2E100_manifest.json"; GPU="${G[$i]}"
  [[ -s "$MAN" ]] || { echo "[FAIL] missing $MAN"; exit 3; }
  (
    readarray -t M < <("${PYTHON}" - "$MAN" <<'PY'
import json,sys
from pathlib import Path
m=json.loads(Path(sys.argv[1]).read_text()); print(m['config']); print(m['checkpoint']); print(m['run_dir']); print(m['run_tag'])
PY
    )
    CFG="${M[0]}"; CKPT="${M[1]}"; RUNDIR="${M[2]}"; TAG="${M[3]}"
    INF="${OUT_ROOT}/${DS}/inference"; mkdir -p "$INF"
    CUDA_VISIBLE_DEVICES="$GPU" PYTHONPATH="$PROJECT${PYTHONPATH:+:$PYTHONPATH}" \
      "${PYTHON}" -u test.py --config-file "$CFG" --seed "$SEED" --split val --num-samples 1 \
      --checkpoint "$CKPT" --output-dir "$INF" TRAIN.RUN_TAG "$TAG" M1.RUN_TAG "$TAG"
    RUN="MedCLIPSeg_unimedclip_ViT-B-16_${TAG}"
    ROOT="${INF}/${DS}/seg_results/seed${SEED}"
    "${PYTHON}" -u tools/semlt_hypothesis_diagnosis.py --dataset "$DS" --host-name MedCLIPSeg-host \
      --config-file "$CFG" --split val --base-dir "${ROOT}/${RUN}_BaseNative_Val" \
      --refined-dir "${ROOT}/${RUN}_M1Native_Val" --output-dir "${OUT_ROOT}/${DS}/diagnosis" \
      --radii "$RADII" --mechanism-radius "$RADIUS" --null-repeats "$NULL_REPEATS" --seed 20260829
  ) > "${PROJECT}/logs/SEMLT_HYPOTHESIS_VAL_${DS}_seed${SEED}_${EXP_ID}.log" 2>&1 &
  P+=("$!")
done
status=0; for p in "${P[@]}"; do wait "$p" || status=1; done
[[ $status -eq 0 ]] || { echo '[FAIL] at least one validation diagnosis failed'; exit 4; }
S=(); for DS in "${D[@]}"; do S+=("${OUT_ROOT}/${DS}/diagnosis/summary.json"); done
"${PYTHON}" tools/semlt_hypothesis_collect.py "${S[@]}" --output-dir "${OUT_ROOT}/combined" --radius "$RADIUS"
echo "[PASS] validation hypothesis diagnosis complete: ${OUT_ROOT}/combined/hypothesis_table.md"
