#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"

PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"

ARM="${ARM:?ARM is required}"

GPU="${GPU:-1}"
SEED="${SEED:-42}"

STUDY_ID="${STUDY_ID:-ISIC_OACD_ABL100_S42_LOWMEM4_20260903}"

MIN_FREE_MIB="${MIN_FREE_MIB:-29000}"
POLL_SECONDS="${POLL_SECONDS:-60}"

CONFIG="${PROJECT}/configs/ucfnrt_oacd_isic_minabl100/${ARM}.yaml"

ARM_ROOT="${PROJECT}/runs/${STUDY_ID}/${ARM}"

TEST_ROOT="${ARM_ROOT}/formal_test"

LOG_ROOT="${PROJECT}/logs/${STUDY_ID}"

TRAIN_LOG="${LOG_ROOT}/${ARM}.train.log"

TEST_LOG="${LOG_ROOT}/${ARM}.test_eval.log"

mkdir -p \
    "${ARM_ROOT}" \
    "${TEST_ROOT}" \
    "${LOG_ROOT}"

cd "${PROJECT}"

export PYTHONPATH="${PROJECT}:${PROJECT}/utils${PYTHONPATH:+:${PYTHONPATH}}"

export HF_HOME="${PROJECT}/checkpoints"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_DATASETS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false

export MPLBACKEND=Agg

export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True,max_split_size_mb:128}"

# ------------------------------------------------------------------
# FULL is intentionally forbidden in this launcher.
# ------------------------------------------------------------------

case "${ARM}" in

    A000_JOINT_CONTROL|A011_NO_ALIGN|A101_NO_CDF|A110_NO_REACH)
        ;;

    FULL)
        echo "[FAIL] FULL is intentionally excluded from this ISIC ablation."
        exit 2
        ;;

    *)
        echo "[FAIL] invalid ARM=${ARM}"
        exit 3
        ;;

esac

[[ -f "${CONFIG}" ]] || {
    echo "[FAIL] missing config:"
    echo "${CONFIG}"
    exit 4
}

# ------------------------------------------------------------------
# GPU wait
# ------------------------------------------------------------------

wait_gpu()
{
    while true
    do

        FREE="$(
            nvidia-smi \
              -i "${GPU}" \
              --query-gpu=memory.free \
              --format=csv,noheader,nounits \
            | head -1 \
            | tr -d '[:space:]'
        )"

        UTIL="$(
            nvidia-smi \
              -i "${GPU}" \
              --query-gpu=utilization.gpu \
              --format=csv,noheader,nounits \
            | head -1 \
            | tr -d '[:space:]'
        )"

        echo \
"[GPU WAIT] physical_gpu=${GPU} free=${FREE:-NA}MiB util=${UTIL:-NA}% required>=${MIN_FREE_MIB}MiB"

        if [[ "${FREE:-}" =~ ^[0-9]+$ ]] && \
           (( FREE >= MIN_FREE_MIB )); then

            echo \
"[GPU READY] physical_gpu=${GPU} free=${FREE}MiB"

            break
        fi

        sleep "${POLL_SECONDS}"
    done
}

echo "===================================================================================================="
echo "ISIC OACD CONTROLLED ABLATION"
echo "===================================================================================================="
echo "ARM        = ${ARM}"
echo "CONFIG     = ${CONFIG}"
echo "GPU        = ${GPU}"
echo "SEED       = ${SEED}"
echo "STUDY_ID   = ${STUDY_ID}"
echo "ARM_ROOT   = ${ARM_ROOT}"
echo
echo "Scientific contract:"
echo "  epochs       = 100"
echo "  batch        = 24"
echo "  grad accum   = 1"
echo "  optimizer    = Adam"
echo "  lr           = 3e-4"
echo "  Train MC     = 10"
echo "  Test MC      = 30"
echo "  radius       = 8"
echo "  val select   = OFF"
echo "  checkpoint   = physical last epoch"
echo "  LOWMEM4      = shared implementation"
echo "===================================================================================================="

# Runtime contract immediately before training.
"${PYTHON}" tools/preflight_oacd_runtime.py \
    --project "${PROJECT}" \
    --config "${CONFIG}" \
    --seed "${SEED}"

wait_gpu

echo
echo "===================================================================================================="
echo "[STAGE 1/4] TRAIN 100 PHYSICAL EPOCHS FROM SCRATCH"
echo "===================================================================================================="

CUDA_VISIBLE_DEVICES="${GPU}" \
"${PYTHON}" -u train.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --data_percentage 100 \
    --output-dir "${ARM_ROOT}" \
    > "${TRAIN_LOG}" 2>&1

echo "[PASS] TRAIN RETURNED: ${ARM}"

# ------------------------------------------------------------------
# Lock exact physical epoch-100 checkpoint.
# ------------------------------------------------------------------

CKPT_DIR="${ARM_ROOT}/ISIC/trained_models/seed${SEED}"

mapfile -t CKPTS < <(
    find "${CKPT_DIR}" \
      -maxdepth 1 \
      -type f \
      -name '*_last_epoch.pth' \
      -print 2>/dev/null
)

if (( ${#CKPTS[@]} != 1 )); then

    echo "[FAIL] expected exactly one physical last_epoch checkpoint"
    echo "CKPT_DIR=${CKPT_DIR}"

    printf '%s\n' "${CKPTS[@]:-}"

    exit 10
fi

CKPT="${CKPTS[0]}"

RUN_NAME="$(basename "${CKPT}" _last_epoch.pth)"

echo
echo "===================================================================================================="
echo "[LOCKED CHECKPOINT]"
echo "===================================================================================================="
echo "${CKPT}"

sha256sum "${CKPT}"

{
    echo "ARM=${ARM}"
    echo "DATASET=ISIC"
    echo "SEED=${SEED}"
    echo "CHECKPOINT=${CKPT}"
    echo "CHECKPOINT_SHA256=$(sha256sum "${CKPT}" | awk '{print $1}')"
    echo "TRAIN_COMPLETED_AT=$(date -Is)"
} > "${ARM_ROOT}/TRAIN_SUCCESS.lock"

# Test only after physical last epoch is locked.
wait_gpu

echo
echo "===================================================================================================="
echo "[STAGE 2/4] ONE-SHOT TEST | MC=30"
echo "===================================================================================================="

CUDA_VISIBLE_DEVICES="${GPU}" \
"${PYTHON}" -u test.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --split test \
    --prompt_design original \
    --num-samples 30 \
    --checkpoint "${CKPT}" \
    --output-dir "${TEST_ROOT}" \
    > "${TEST_LOG}" 2>&1

echo "[PASS] MC30 TEST RETURNED"

RESULT_ROOT="${TEST_ROOT}/ISIC/seg_results/seed${SEED}"

echo
echo "===================================================================================================="
echo "[STAGE 3/4] TRUE2D + PAPER-LEGACY EVALUATION"
echo "===================================================================================================="

evaluate_one()
{
    local SUFFIX="$1"
    local MODE="$2"
    local CSV="$3"

    "${PYTHON}" -u utils/eval.py \
        --config-file "${CONFIG}" \
        --seed "${SEED}" \
        --split test \
        --output-dir "${TEST_ROOT}" \
        --result-name "${RUN_NAME}_${SUFFIX}" \
        --csv-name "${CSV}" \
        --nsd-mode "${MODE}" \
        >> "${TEST_LOG}" 2>&1
}

evaluate_one \
    BaseNative \
    true2d \
    test_BaseNative_true2d.csv

evaluate_one \
    M1Native \
    true2d \
    test_M1Native_true2d.csv

evaluate_one \
    BaseNative \
    paper_legacy \
    test_BaseNative_paper_legacy.csv

evaluate_one \
    M1Native \
    paper_legacy \
    test_M1Native_paper_legacy.csv

# ------------------------------------------------------------------
# Result integrity
# ------------------------------------------------------------------

for F in \
    "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
    "${RESULT_ROOT}/test_M1Native_true2d.csv" \
    "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
    "${RESULT_ROOT}/test_M1Native_paper_legacy.csv"
do
    if [[ ! -s "${F}" ]]; then
        echo "[FAIL] missing evaluation CSV:"
        echo "${F}"
        exit 20
    fi
done

# ISIC formal test must contain exactly 379 cases.
"${PYTHON}" - <<PY
import pandas as pd
from pathlib import Path

root = Path("${RESULT_ROOT}")

files = [
    root / "test_BaseNative_true2d.csv",
    root / "test_M1Native_true2d.csv",
    root / "test_BaseNative_paper_legacy.csv",
    root / "test_M1Native_paper_legacy.csv",
]

for p in files:
    df = pd.read_csv(p)
    if len(df) != 379:
        raise RuntimeError(
            f"{p.name}: cases={len(df)} != expected 379"
        )
    print(f"[PASS] {p.name}: cases=379")
PY

echo
echo "===================================================================================================="
echo "[STAGE 4/4] PAIRED BASE-vs-OACD STATISTICS"
echo "===================================================================================================="

# Prefer the generic paired comparator if available.
if [[ -f "${PROJECT}/tools/compare_geotr_m1_paired.py" ]]; then

    "${PYTHON}" tools/compare_geotr_m1_paired.py \
        --base-csv "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
        --m1-csv "${RESULT_ROOT}/test_M1Native_true2d.csv" \
        --output-prefix "${RESULT_ROOT}/paired_true2d" \
        --protocol-label "ISIC_OACD_${ARM}_true2d_seed${SEED}" \
        >> "${TEST_LOG}" 2>&1

    "${PYTHON}" tools/compare_geotr_m1_paired.py \
        --base-csv "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
        --m1-csv "${RESULT_ROOT}/test_M1Native_paper_legacy.csv" \
        --output-prefix "${RESULT_ROOT}/paired_paper_legacy" \
        --protocol-label "ISIC_OACD_${ARM}_paper_legacy_seed${SEED}" \
        >> "${TEST_LOG}" 2>&1

fi

echo
echo "===================================================================================================="
echo "[FINAL METRICS] ${ARM}"
echo "===================================================================================================="

grep -E \
'Average DSC|Average NSD|Cases evaluated' \
"${TEST_LOG}" \
| tail -20 || true

{
    echo "ARM=${ARM}"
    echo "DATASET=ISIC"
    echo "SEED=${SEED}"
    echo "CHECKPOINT=${CKPT}"
    echo "CHECKPOINT_SHA256=$(sha256sum "${CKPT}" | awk '{print $1}')"
    echo "TEST_MC=30"
    echo "CASES=379"
    echo "COMPLETED_AT=$(date -Is)"
} > "${ARM_ROOT}/SUCCESS.lock"

echo
echo "===================================================================================================="
echo "[PASS] ${ARM}"
echo "TRAIN -> LAST_EPOCH -> MC30 TEST -> TRUE2D/LEGACY EVAL COMPLETE"
echo "SUCCESS=${ARM_ROOT}/SUCCESS.lock"
echo "===================================================================================================="
