#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
DATASET="${DATASET:-BUSI}"
VARIANT="${VARIANT:-full}"
PHASE="${PHASE:-val}"
MODE="${MODE:-fresh}"
CONFIG="${CONFIG:-configs/BUSI_GEOTR_M1_FORMAL54_PAPER100.yaml}"
DATA_ROOT="${DATA_ROOT:-./data/${DATASET}}"
TRAIN_PATH="${TRAIN_PATH:-${DATA_ROOT}/Train_Folder/}"
VAL_PATH="${VAL_PATH:-${DATA_ROOT}/Val_Folder/}"
TEST_PATH="${TEST_PATH:-${DATA_ROOT}/Test_Folder/}"
TEXT_PROMPT_PATH="${TEXT_PROMPT_PATH:-${DATA_ROOT}/Prompts_Folder/}"
AUDIT_SPLITS="${AUDIT_SPLITS:-1}"
ALLOW_ABLATION_TEST="${ALLOW_ABLATION_TEST:-0}"
RUN_DIR="${RUN_DIR:-}"
cd "${PROJECT}"
export TOKENIZERS_PARALLELISM=false
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"

if [[ -z "${PYTHON}" ]]; then
  echo "[FAIL] PYTHON must be resolved by the foreground/background launcher"
  exit 2
fi
command -v "${PYTHON}" >/dev/null 2>&1 || {
  echo "[FAIL] PYTHON is not executable: ${PYTHON}"; exit 2;
}
"${PYTHON}" -c 'import torch' >/dev/null 2>&1 || {
  echo "[FAIL] PYTHON cannot import torch: ${PYTHON}"; exit 2;
}

case "${PHASE}" in
  val|test) ;;
  *) echo "[FAIL] PHASE must be val or test"; exit 2 ;;
esac
case "${MODE}" in
  fresh|resume) ;;
  *) echo "[FAIL] MODE must be fresh or resume"; exit 2 ;;
esac
case "${VARIANT}" in
  full|semantic|core|core_edge|no_text|no_semantic|image_only|no_anchor|prob_warp|no_deform|edge_deform) ;;
  *) echo "[FAIL] unknown VARIANT=${VARIANT}"; exit 2 ;;
esac
if [[ "${PHASE}" == "test" && "${VARIANT}" != "full" && "${ALLOW_ABLATION_TEST}" != "1" ]]; then
  echo "[FAIL] Formal Test is reserved for the frozen full model. Run ablations with PHASE=val."
  exit 2
fi
for path in "${CONFIG}" "${TRAIN_PATH}" "${VAL_PATH}" "${TEST_PATH}" "${TEXT_PROMPT_PATH}"; do
  [[ -e "${path}" ]] || { echo "[FAIL] required path not found: ${path}"; exit 2; }
done

"${PYTHON}" tools/check_geotr_m1_formal54_protocol.py \
  --config-file "${CONFIG}" --protocol paper100
PYTHON="${PYTHON}" PROJECT="${PROJECT}" bash launch_geotr_m1_restore53_preflight.sh
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -c \
  'import torch; assert torch.cuda.is_available(), "FORMAL55 training requires CUDA"'

# Several supplied runs were launched concurrently on GPU 5.  That does not
# create an independent ablation and can change timing/numerics or exhaust
# memory.  A kernel-held lock is released automatically on exit, including a
# crash, so stale lock files are harmless.
if command -v flock >/dev/null 2>&1; then
  exec 9>"${PROJECT}/.geotr_m1_gpu${GPU}.lock"
  flock -n 9 || {
    echo "[FAIL] GPU ${GPU} already has an active FORMAL55 launcher in ${PROJECT}"; exit 2;
  }
else
  echo "[WARN] flock is unavailable; do not launch two jobs on GPU ${GPU}"
fi

mkdir -p audits logs runs
if [[ "${AUDIT_SPLITS}" == "1" ]]; then
  "${PYTHON}" tools/audit_geotr_m1_dataset.py \
    --dataset "${DATASET}" --train "${TRAIN_PATH}" --val "${VAL_PATH}" --test "${TEST_PATH}" \
    --output "audits/${DATASET}_split_audit.json"
fi

OVERRIDES=(
  DATASET.NAME "${DATASET}"
  DATASET.TRAIN_PATH "${TRAIN_PATH}"
  DATASET.VAL_PATH "${VAL_PATH}"
  DATASET.TEST_PATH "${TEST_PATH}"
  DATASET.TEXT_PROMPT_PATH "${TEXT_PROMPT_PATH}"
)
case "${VARIANT}" in
  no_text)
    OVERRIDES+=(M1.GEOTR_M1_USE_TEXT_CONDITIONING false)
    ;;
  semantic)
    OVERRIDES+=(M1.GEOTR_M1_USE_TEXT_CONDITIONING false)
    ;;
  no_semantic)
    OVERRIDES+=(M1.GEOTR_M1_USE_SEMANTIC_CONDITIONING false)
    ;;
  image_only)
    OVERRIDES+=(M1.GEOTR_M1_USE_TEXT_CONDITIONING false M1.GEOTR_M1_USE_SEMANTIC_CONDITIONING false)
    ;;
  core)
    OVERRIDES+=(M1.GEOTR_M1_USE_TEXT_CONDITIONING false M1.GEOTR_M1_USE_SEMANTIC_CONDITIONING false)
    ;;
  core_edge)
    OVERRIDES+=(M1.GEOTR_M1_USE_TEXT_CONDITIONING false M1.GEOTR_M1_USE_SEMANTIC_CONDITIONING false M1.GEOTR_M1_USE_ANCHOR_CUES true M1.GEOTR_M1_TRANSPORT_SPACE logit M1.GEOTR_M1_DEFORM_MODE edge_aware)
    ;;
  no_anchor)
    OVERRIDES+=(M1.GEOTR_M1_USE_ANCHOR_CUES false)
    ;;
  prob_warp)
    OVERRIDES+=(M1.GEOTR_M1_TRANSPORT_SPACE probability)
    ;;
  no_deform)
    OVERRIDES+=(M1.GEOTR_M1_DEFORM_MODE none M1.GEOTOPO_SMOOTHNESS_WEIGHT 0.0 M1.GEOTR_M1_FOLDING_WEIGHT 0.0)
    ;;
  edge_deform)
    OVERRIDES+=(M1.GEOTR_M1_DEFORM_MODE edge_aware)
    ;;
esac
case "${VARIANT}" in
  no_text) echo "[INFO] no_text is the backward-compatible alias of the nested semantic variant" ;;
  image_only) echo "[INFO] image_only is the backward-compatible alias of the nested core variant" ;;
esac

DATASET_TOKEN="$(printf '%s' "${DATASET}" | tr '[:lower:]-' '[:upper:]_')"
VARIANT_TOKEN="$(printf '%s' "${VARIANT}" | tr '[:lower:]-' '[:upper:]_')"
RUN_TAG="${RUN_TAG:-GEOTR_M1_FORMAL55_${DATASET_TOKEN}_${VARIANT_TOKEN}_PAPER100}"
STAMP="$(date +%Y%m%d_%H%M%S)"
if [[ -z "${RUN_DIR}" && "${MODE}" == "fresh" ]]; then
  RUN_DIR="runs/${RUN_TAG}_seed${SEED}_${STAMP}"
fi
if [[ "${MODE}" == "fresh" ]]; then
  [[ ! -e "${RUN_DIR}" ]] || { echo "[FAIL] RUN_DIR already exists: ${RUN_DIR}"; exit 2; }
  mkdir -p "${RUN_DIR}"
else
  [[ -n "${RUN_DIR}" && -d "${RUN_DIR}" ]] || {
    echo "[FAIL] MODE=resume requires an existing explicit RUN_DIR"; exit 2;
  }
fi
TRAIN_LOG="logs/${RUN_TAG}_seed${SEED}_gpu${GPU}_${STAMP}.log"
RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"
CHECKPOINT_DIR="${RUN_DIR}/${DATASET}/trained_models/seed${SEED}"

echo "[FORMAL55] dataset=${DATASET} variant=${VARIANT} phase=${PHASE} seed=${SEED}"
echo "[FORMAL55] mode=${MODE} python=${PYTHON}"
echo "[FORMAL55] run_dir=${RUN_DIR}"
TRAIN_ARGS=()
if [[ "${MODE}" == "resume" ]]; then
  LATEST="${CHECKPOINT_DIR}/${RUN_NAME}_latest.pth"
  [[ -f "${LATEST}" ]] || {
    echo "[FAIL] resume checkpoint missing: ${LATEST}"; exit 2;
  }
  [[ ! -e "${RUN_DIR}/FORMAL_VAL_SUCCESS.lock" && ! -e "${RUN_DIR}/FORMAL_TEST_SUCCESS.lock" ]] || {
    echo "[FAIL] run is already complete: ${RUN_DIR}"; exit 2;
  }
  TRAIN_ARGS+=(--resume)
fi
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "${CONFIG}" --seed "${SEED}" --output-dir "${RUN_DIR}" \
  "${TRAIN_ARGS[@]}" \
  TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" \
  "${OVERRIDES[@]}" 2>&1 | tee -a "${TRAIN_LOG}"

CHECKPOINT="${CHECKPOINT_DIR}/${RUN_NAME}_last_epoch.pth"
[[ -f "${CHECKPOINT}" ]] || { echo "[FAIL] epoch-100 checkpoint missing: ${CHECKPOINT}"; exit 2; }

if [[ "${PHASE}" == "test" ]]; then
  LOCK="${RUN_DIR}/FORMAL_TEST_OPENED.lock"
  [[ ! -e "${LOCK}" ]] || { echo "[FAIL] Test was already opened: ${LOCK}"; exit 2; }
  {
    echo "opened_at=$(date --iso-8601=seconds)"
    echo "dataset=${DATASET}"
    echo "variant=${VARIANT}"
    echo "seed=${SEED}"
    echo "checkpoint=${CHECKPOINT}"
  } > "${LOCK}"
  SPLIT="test"
else
  SPLIT="val"
fi

OUT="${RUN_DIR}/formal_${SPLIT}"
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u test.py \
  --config-file "${CONFIG}" --seed "${SEED}" --split "${SPLIT}" --num-samples 1 \
  --checkpoint "${CHECKPOINT}" --output-dir "${OUT}" \
  TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" "${OVERRIDES[@]}"

RESULT_ROOT="${OUT}/${DATASET}/seg_results/seed${SEED}"
BASE_RESULT="${RUN_NAME}_BaseNative"
M1_RESULT="${RUN_NAME}_M1Native"
evaluate_one() {
  local result_name="$1"
  local csv_name="$2"
  local nsd_mode="$3"
  "${PYTHON}" -u utils/eval.py \
    --config-file "${CONFIG}" --seed "${SEED}" --split "${SPLIT}" --output-dir "${OUT}" \
    --result-name "${result_name}" --csv-name "${csv_name}" --nsd-mode "${nsd_mode}" \
    TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" "${OVERRIDES[@]}"
}
evaluate_one "${BASE_RESULT}" "${SPLIT}_BaseNative_true2d.csv" true2d
evaluate_one "${M1_RESULT}" "${SPLIT}_M1Native_true2d.csv" true2d
evaluate_one "${BASE_RESULT}" "${SPLIT}_BaseNative_paper_legacy.csv" paper_legacy
evaluate_one "${M1_RESULT}" "${SPLIT}_M1Native_paper_legacy.csv" paper_legacy

"${PYTHON}" tools/compare_geotr_m1_paired.py \
  --base-csv "${RESULT_ROOT}/${SPLIT}_BaseNative_true2d.csv" \
  --m1-csv "${RESULT_ROOT}/${SPLIT}_M1Native_true2d.csv" \
  --output-prefix "${RESULT_ROOT}/paired_true2d" \
  --protocol-label "${DATASET}_${SPLIT}_corrected_true_2d_nsd"

PAPER_ARGS=()
if [[ "${DATASET}" == "BUSI" && "${SPLIT}" == "test" && "${VARIANT}" == "full" ]]; then
  PAPER_ARGS+=(--benchmark-json benchmarks/medclipseg_cvpr2026_busi_full.json)
fi
"${PYTHON}" tools/compare_geotr_m1_paired.py \
  --base-csv "${RESULT_ROOT}/${SPLIT}_BaseNative_paper_legacy.csv" \
  --m1-csv "${RESULT_ROOT}/${SPLIT}_M1Native_paper_legacy.csv" \
  --output-prefix "${RESULT_ROOT}/paired_paper_legacy" \
  --protocol-label "${DATASET}_${SPLIT}_reference_paper_singleton_depth_nsd" \
  "${PAPER_ARGS[@]}"

SUCCESS="${RUN_DIR}/FORMAL_${SPLIT^^}_SUCCESS.lock"
{
  echo "completed_at=$(date --iso-8601=seconds)"
  echo "dataset=${DATASET}"
  echo "variant=${VARIANT}"
  echo "seed=${SEED}"
  echo "checkpoint=${CHECKPOINT}"
  echo "report=${RESULT_ROOT}/paired_true2d.json"
} > "${SUCCESS}"
echo "[PASS] FORMAL55 ${DATASET}/${VARIANT}/${SPLIT} complete"
echo "       RUN_DIR=${RUN_DIR}"
echo "       REPORT=${RESULT_ROOT}/paired_true2d.md"
