#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
DATASET="${DATASET:-BUSI}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
EXP_ID="${EXP_ID:-PAPER100_$(date +%Y%m%d_%H%M%S)}"
RUN_ROOT="${RUN_ROOT:-runs/SEMLT_LST_V2_PAPER100_${EXP_ID}}"
case "${DATASET}" in BUSI|BTMRI|ISIC|Kvasir) ;; *) echo 'DATASET must be BUSI|BTMRI|ISIC|Kvasir'; exit 2;; esac
CONFIG="configs/${DATASET}_SEMLT_LST_V2_PAPER100.yaml"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
export TOKENIZERS_PARALLELISM=false
mkdir -p "${RUN_ROOT}" logs
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "${CONFIG}" --seed "${SEED}" --output-dir "${RUN_ROOT}"
