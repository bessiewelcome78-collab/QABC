#!/usr/bin/env bash
set -Eeuo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-python}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="${PROJECT}/code_backups/SEMLT_SDF_OPERATOR_MATCHED_WARP_before_${STAMP}"
MANIFEST="${SRC}/SEMLT_SDF_OPERATOR_MATCHED_WARP_MODIFIED_FILES.txt"

[[ -d "${PROJECT}" ]] || { echo "[FAIL] PROJECT does not exist: ${PROJECT}" >&2; exit 2; }
[[ -f "${MANIFEST}" ]] || { echo "[FAIL] missing manifest: ${MANIFEST}" >&2; exit 2; }
mkdir -p "${BACKUP}"

while IFS= read -r rel; do
  [[ -z "${rel}" ]] && continue
  src="${SRC}/${rel}"; dst="${PROJECT}/${rel}"
  [[ -e "${src}" ]] || { echo "[FAIL] overlay missing ${rel}" >&2; exit 3; }
  if [[ -e "${dst}" ]]; then
    mkdir -p "${BACKUP}/$(dirname "${rel}")"
    cp -a "${dst}" "${BACKUP}/${rel}"
  fi
  mkdir -p "$(dirname "${dst}")"
  cp -a "${src}" "${dst}"
done < "${MANIFEST}"
cp -a "${SRC}/install_semlt_sdf_operator_matched_warp.sh" "${PROJECT}/install_semlt_sdf_operator_matched_warp.sh"
cp -a "${SRC}/SEMLT_SDF_OPERATOR_MATCHED_WARP_MODIFIED_FILES.txt" "${PROJECT}/SEMLT_SDF_OPERATOR_MATCHED_WARP_MODIFIED_FILES.txt"
chmod +x \
  "${PROJECT}/install_semlt_sdf_operator_matched_warp.sh" \
  "${PROJECT}/launch_semlt_sdf_operator_matched_warp.sh" \
  "${PROJECT}/launch_semlt_sdf_operator_matched_warp_nohup.sh" \
  "${PROJECT}/launch_semlt_sdf_operator_matched_warp_paper100_one_dataset_test_eval.sh" \
  "${PROJECT}/tools/test_semlt_sdf_operator_matched_warp_contract.py" \
  "${PROJECT}/tools/check_semlt_sdf_operator_matched_warp_configs.py"

cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
"${PYTHON}" -c 'import scipy; from scipy.ndimage import distance_transform_edt; print("[PASS] scipy EDT", scipy.__version__)'
"${PYTHON}" -m py_compile \
  utils/semlt_sdf_geometry.py \
  utils/semlt_autozero_transport.py \
  utils/semlt_autozero_loss.py \
  trainers/medclipseg_unimedclip.py \
  train.py
bash -n \
  launch_semlt_sdf_operator_matched_warp.sh \
  launch_semlt_sdf_operator_matched_warp_nohup.sh \
  launch_semlt_sdf_operator_matched_warp_paper100_one_dataset_test_eval.sh
"${PYTHON}" tools/test_semlt_sdf_operator_matched_warp_contract.py
"${PYTHON}" tools/check_semlt_sdf_operator_matched_warp_configs.py
# Frozen-route regression tests.
"${PYTHON}" tools/test_semlt_boundary_normal_warp_contract.py
"${PYTHON}" tools/check_semlt_boundary_normal_warp_configs.py
"${PYTHON}" tools/test_semlt_lst_v31_rootfix_contract.py
"${PYTHON}" tools/test_semlt_lst_eligible_gate_contract.py
"${PYTHON}" tools/test_semlt_action_value_policy_contract.py

echo "[PASS] SemLT SDF Operator-Matched Warp installed"
echo "[BACKUP] ${BACKUP}"
echo "[NEXT] GPU=<idle> SEED=42 DATASET=BUSI MODE=DIAG20 PYTHON=${PYTHON} bash launch_semlt_sdf_operator_matched_warp_nohup.sh"
