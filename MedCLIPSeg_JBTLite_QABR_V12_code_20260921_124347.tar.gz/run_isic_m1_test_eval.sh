#!/usr/bin/env bash
set -Eeuo pipefail

export CUDA_VISIBLE_DEVICES=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True
export TOKENIZERS_PARALLELISM=false

M1_CFG=configs/reproplus/GEOTR_M1_FINAL_PAPER100.yaml
DATA_DIR=./data
RUN_ROOT=runs/GEOTR_M1_FINAL_PAPER100/ISIC/seed42
M1_TRAIN=$RUN_ROOT/m1_train
M1_TEST=$RUN_ROOT/m1_test
M1_TAG=GEOTR_M1_FINAL_ISIC_S42
M1_NAME=MedCLIPSeg_unimedclip_ViT-B-16_${M1_TAG}

COMMON_OVERRIDES=(
  DATASET.NAME ISIC
  DATASET.TRAIN_PATH "$DATA_DIR/ISIC/Train_Folder/"
  DATASET.VAL_PATH "$DATA_DIR/ISIC/Val_Folder/"
  DATASET.TEST_PATH "$DATA_DIR/ISIC/Test_Folder/"
  DATASET.TEXT_PROMPT_PATH "$DATA_DIR/ISIC/Prompts_Folder/"
)

M1_CKPT="$M1_TRAIN/ISIC/trained_models/seed42/${M1_NAME}_last_epoch.pth"
[[ -f "$M1_CKPT" ]] || { echo "Missing M1 checkpoint: $M1_CKPT" >&2; exit 4; }

echo "[1/3] Running test.py to export predictions"
python -u test.py --config-file "$M1_CFG" --seed 42 --split test \
  --prompt_design original --num-samples 30 --checkpoint "$M1_CKPT" \
  --export-mode joint --inference-batch-size 32 --output-dir "$M1_TEST" \
  "${COMMON_OVERRIDES[@]}" M1.RUN_TAG "$M1_TAG" TRAIN.RUN_TAG "$M1_TAG"

echo "[2/3] Running eval.py for both protocols"
RESULT_ROOT="$M1_TEST/ISIC/seg_results/seed42"
for MODE in paper_legacy true2d; do
  python -u utils/eval.py --config-file "$M1_CFG" --seed 42 --split test \
    --prompt_design original --output-dir "$M1_TEST" \
    --result-name "${M1_NAME}_BaseNative" --csv-name "test_BaseNative_${MODE}.csv" --nsd-mode "$MODE" \
    "${COMMON_OVERRIDES[@]}" M1.RUN_TAG "$M1_TAG" TRAIN.RUN_TAG "$M1_TAG"

  python -u utils/eval.py --config-file "$M1_CFG" --seed 42 --split test \
    --prompt_design original --output-dir "$M1_TEST" \
    --result-name "${M1_NAME}_M1Native" --csv-name "test_M1Native_${MODE}.csv" --nsd-mode "$MODE" \
    "${COMMON_OVERRIDES[@]}" M1.RUN_TAG "$M1_TAG" TRAIN.RUN_TAG "$M1_TAG"

  EXTRA=()
  [[ "$MODE" == paper_legacy ]] && EXTRA=(--benchmark-json "benchmarks/paper100_ISIC.json")
  python tools/compare_geotr_m1_paired.py \
    --base-csv "$RESULT_ROOT/test_BaseNative_${MODE}.csv" \
    --m1-csv "$RESULT_ROOT/test_M1Native_${MODE}.csv" \
    --output-prefix "$RESULT_ROOT/paired_${MODE}" \
    --protocol-label "ISIC_${M1_TAG}_${MODE}" "${EXTRA[@]}"
done

echo "DONE. Final results:"
echo "  $RESULT_ROOT/paired_true2d.json"
echo "  $RESULT_ROOT/paired_paper_legacy.json"
