JBT-Lite v3 FORMAL100 Python hotfix

Fixes direct invocation of run_formal100_one_locked.sh when the caller is in Conda base and does not export PYTHON.
The script now defaults to:
/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python
and performs a MONAI preflight before starting a formal run.

Overlay:
tar -xzf JBTLite_v3_FORMAL100_python_hotfix_20260910.tar.gz -C /home/tsz-25/MedCLIPSeg_JBTLite_20260910
