#!/usr/bin/env bash
set -Eeuo pipefail

# Sequential R2.2-JPS launcher. Override DATASETS, SEEDS and GPU as needed.
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASETS="${DATASETS:-BUSI BTMRI ISIC Kvasir}"
SEEDS="${SEEDS:-42 123 789}"
GPU="${GPU:-0}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MASTER_ROOT="${MASTER_ROOT:-${PROJECT}/runs/OACD_R22_JPS_${ROOT_ID}}"

for seed in ${SEEDS}; do
  for dataset in ${DATASETS}; do
    PROJECT="${PROJECT}" PYTHON="${PYTHON}" MASTER_ROOT="${MASTER_ROOT}" ROOT_ID="${ROOT_ID}" \
      DATASET="${dataset}" SEED="${seed}" GPU="${GPU}" \
      bash "${PROJECT}/launch_oacd_r22_joint_proper_paper100_one_dataset.sh"
  done
done

echo "all requested runs complete: ${MASTER_ROOT}"
