#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${PROJECT:-${SCRIPT_DIR}}"
PYTHON="${PYTHON:-python3}"
DATASET="${DATASET:?DATASET is required}"
GPU="${GPU:?GPU is required}"
ROOT_ID="${ROOT_ID:?ROOT_ID is required}"
SEEDS="${SEEDS:-42 123 789}"
GATE_DATASETS="${GATE_DATASETS:-BUSI Kvasir ISIC}"
VARIANTS=(A1_REWRITE A2_PROB A3_NORMAL1D A4_FREE2D A5_SUPPORT A6_SEMLT)

case "${DATASET}" in BUSI|Kvasir|ISIC) ;; *) echo "[FAIL] unsupported DATASET=${DATASET}" >&2; exit 2;; esac
[[ "${GPU}" =~ ^[0-9]+$ ]] || { echo "[FAIL] GPU must be a non-negative integer" >&2; exit 2; }
[[ "${ROOT_ID}" =~ ^[A-Za-z0-9_.-]+$ ]] || { echo "[FAIL] invalid ROOT_ID" >&2; exit 2; }
command -v "${PYTHON}" >/dev/null 2>&1 || { echo "[FAIL] PYTHON not found: ${PYTHON}" >&2; exit 2; }
[[ -f "${PROJECT}/tools/semlt_ablation_test_once.py" ]] || { echo "[FAIL] missing test finalizer" >&2; exit 2; }
read -r -a seed_ids <<< "${SEEDS}"
read -r -a gate_datasets <<< "${GATE_DATASETS}"
[[ ${#seed_ids[@]} -gt 0 && ${#gate_datasets[@]} -eq 3 ]] || { echo "[FAIL] need nonempty SEEDS and exactly three GATE_DATASETS" >&2; exit 2; }

cd "${PROJECT}"
for seed in "${seed_ids[@]}"; do
  for ds in "${gate_datasets[@]}"; do
    for variant in "${VARIANTS[@]}"; do
      gate_root="runs/SEMLT_ABLATION_${ROOT_ID}/seed${seed}/${ds}/variants/${variant}"
      [[ -f "${gate_root}/FORMAL_VAL_SUCCESS.lock" && -f "${gate_root}/ABLATION_manifest.json" ]] || {
        echo "[FAIL] Test remains sealed; validation/manifest missing: ${ds} seed${seed} ${variant}" >&2
        exit 2
      }
    done
  done
done

for seed in "${seed_ids[@]}"; do
  for variant in "${VARIANTS[@]}"; do
    run_dir="runs/SEMLT_ABLATION_${ROOT_ID}/seed${seed}/${DATASET}/variants/${variant}"
    manifest="${run_dir}/ABLATION_manifest.json"
    if [[ -f "${run_dir}/FORMAL_TEST_SUCCESS.lock" ]]; then
      echo "[SKIP] Test already complete: ${DATASET} seed${seed} ${variant}"
      continue
    fi
    [[ ! -f "${run_dir}/FORMAL_TEST_OPENED.lock" ]] || {
      echo "[FAIL] Test was previously opened but did not finish: ${run_dir}" >&2
      exit 2
    }
    echo "[TEST START] dataset=${DATASET} seed=${seed} variant=${variant} gpu=${GPU}"
    CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u tools/semlt_ablation_test_once.py \
      --manifest "${manifest}" --gpu "${GPU}" --python "${PYTHON}"
  done
done
echo "[PASS] ${DATASET}: all locked Tests completed sequentially on GPU ${GPU}"
