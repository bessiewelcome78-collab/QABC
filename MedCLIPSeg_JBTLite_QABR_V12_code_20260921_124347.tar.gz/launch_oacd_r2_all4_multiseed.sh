#!/usr/bin/env bash
set -Eeuo pipefail

# Sequential reference launcher. Override DATASETS, SEEDS, ARM, GPU as needed.
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
DATASETS="${DATASETS:-BUSI BTMRI ISIC Kvasir}"
SEEDS="${SEEDS:-42 123 789}"
ARM="${ARM:-FULL}"
GPU="${GPU:-0}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MASTER_ROOT="${MASTER_ROOT:-${PROJECT}/runs/OACD_R2_${ROOT_ID}}"

for seed in ${SEEDS}; do
  for dataset in ${DATASETS}; do
    PROJECT="${PROJECT}" MASTER_ROOT="${MASTER_ROOT}" ROOT_ID="${ROOT_ID}" \
      DATASET="${dataset}" SEED="${seed}" ARM="${ARM}" GPU="${GPU}" \
      bash "${PROJECT}/launch_oacd_r2_one_dataset.sh"
  done
done

echo "all requested runs complete: ${MASTER_ROOT}"
