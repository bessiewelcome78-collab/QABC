#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
cd "${PROJECT}"
PYTHON="${PYTHON}" PROJECT="${PROJECT}" bash launch_semlt_m1_preflight.sh
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p logs runs
LOG="logs/SEMLT_M1_DIAG10_seed${SEED}_gpu${GPU}_${STAMP}.log"
RUN_DIR="runs/SEMLT_M1_DIAG10_seed${SEED}_${STAMP}"
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file configs/BUSI_SEMLT_M1_DIAG10.yaml \
  --seed "${SEED}" --output-dir "${RUN_DIR}" 2>&1 | tee "${LOG}"
echo "[PASS] SEMLT_M1_DIAG10 finished"
echo "       LOG=${LOG}"
echo "       RUN_DIR=${RUN_DIR}"

