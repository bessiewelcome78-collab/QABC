#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
cd "${PROJECT}" || exit 1
"${PYTHON}" -m py_compile \
  utils/c2r_region_refiner.py \
  utils/c2r_canonical_roi_refiner.py \
  utils/pc2r_posterior_refiner.py \
  utils/multi_hypothesis_composition.py \
  utils/multi_hypothesis_composition_loss.py \
  trainers/medclipseg_unimedclip.py \
  train.py \
  test.py \
  tools/test_pc2r_legacy_version_router_contract.py \
  tools/test_geotr_pc2rv32_contract.py \
  tools/test_geotr_pc2rv32_integration.py \
  tools/test_geotr_pc2rv32_shared_trajectory_contract.py \
  tools/check_geotr_pc2rv32_configs.py \
  tools/check_geotr_pc2rv32_d0_configs.py \
  tools/diagnose_geotr_pc2rv32_log.py
PYTHONPATH=. "${PYTHON}" tools/test_pc2r_legacy_version_router_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv32_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv32_integration.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv32_shared_trajectory_contract.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_pc2rv32_configs.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_pc2rv32_d0_configs.py
# Backward compatibility: v3.1 remains the exact causal control.
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv31_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv31_integration.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv31_shared_trajectory_contract.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_pc2rv31_configs.py
# Earlier paper ablations must remain valid.
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv3_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv3_integration.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2rv2_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2rv2_integration.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2r_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_c2r_integration.py
echo "[PASS] GEOTR-PC2R-v3.2 preflight finished"
