#!/usr/bin/env bash
set -Eeuo pipefail

# By default FULL is not repeated: use the already completed BUSI formal run as
# the full-model row.  Set ARMS="FULL ..." for a completely standalone suite.

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MASTER_ROOT="${MASTER_ROOT:-${PROJECT}/runs/OACD_R3_HCRV_BUSI_ABL100_${ROOT_ID}}"
ARMS="${ARMS:-R8_SEARCH_RANGE NO_CENSORED_SUPERVISION NO_RELATIONAL_VOLUME NO_HIERARCHICAL_DECISION}"

if [[ "${ALLOW_ABLATION100:-0}" != "1" ]]; then
  echo "Set ALLOW_ABLATION100=1 after freezing the BUSI ablation plan." >&2
  exit 9
fi

cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
"${PYTHON}" tools/check_oacd_r3_static.py
"${PYTHON}" tools/test_oacd_r3_hcrv_contract.py
"${PYTHON}" -c "import train; print('[PASS] train.py complete import')"

mkdir -p "${MASTER_ROOT}"
{
  echo "root_id=${ROOT_ID}"
  echo "master_root=${MASTER_ROOT}"
  echo "dataset=BUSI"
  echo "seed=${SEED}"
  echo "arms=${ARMS}"
  echo "started_at=$(date --iso-8601=seconds)"
  find configs/ucfnrt_oacd_r3/ablations -maxdepth 1 -name '*.yaml' -print0 \
    | sort -z | xargs -0 sha256sum
} > "${MASTER_ROOT}/ABLATION100_MANIFEST.txt"

for arm in ${ARMS}; do
  PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPU="${GPU}" SEED="${SEED}" \
    ARM="${arm}" ROOT_ID="${ROOT_ID}" MASTER_ROOT="${MASTER_ROOT}" \
    ALLOW_ABLATION100=1 \
    bash "${PROJECT}/launch_oacd_r3_hcrv_busi_ablation100_one_arm.sh"
done

date --iso-8601=seconds > "${MASTER_ROOT}/ABLATIONS_COMPLETE"
echo "BUSI ablation queue complete: ${MASTER_ROOT}"
