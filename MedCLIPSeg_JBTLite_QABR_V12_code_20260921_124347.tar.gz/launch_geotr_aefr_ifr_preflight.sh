#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
cd "${PROJECT}" || exit 1
export PYTHONPATH="${PROJECT}:${PYTHONPATH:-}"
export TOKENIZERS_PARALLELISM=false

echo "=============================================================================================================="
echo "GEOTR-AEFR IFR PREFLIGHT | intervention-aligned residual refinement"
echo "PROJECT=${PROJECT}"
echo "PYTHON=${PYTHON}"
echo "=============================================================================================================="

"${PYTHON}" -m py_compile \
  utils/aefr_action_refiner.py \
  utils/multi_hypothesis_composition.py \
  utils/multi_hypothesis_composition_loss.py \
  train.py \
  tools/test_geotr_aefr_ifr_contract.py \
  tools/test_geotr_aefr_ifr_loss_contract.py \
  tools/test_geotr_aefr_ifr_integration.py \
  tools/check_geotr_aefr_ifr_configs.py \
  tools/diagnose_geotr_aefr_log.py

"${PYTHON}" tools/test_geotr_aefr_ifr_contract.py
"${PYTHON}" tools/test_geotr_aefr_ifr_loss_contract.py
"${PYTHON}" tools/test_geotr_aefr_ifr_integration.py
"${PYTHON}" tools/check_geotr_aefr_ifr_configs.py

# Mandatory historical-regression controls: IFR was added as an independent stage.
"${PYTHON}" tools/test_geotr_aefr_sro_contract.py
"${PYTHON}" tools/test_geotr_aefr_sro_loss_contract.py
"${PYTHON}" tools/test_geotr_aefr_sro_integration.py
"${PYTHON}" tools/test_geotr_aefr_typed_state_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_aefr_transition_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_aefr_transition_a2_trajectory_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv32_contract.py
PYTHONPATH=. "${PYTHON}" tools/test_geotr_pc2rv32_integration.py

echo "[PASS] GEOTR-AEFR IFR preflight finished"
echo "       hard-error WHERE / editness / direction / exact operator contracts are live"
echo "       historical SRO/typed/transition/PC2R controls remain reproducible"
