#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="/home/tsz-25/MedCLIPSeg-pristine"

PYTHON="/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python"

GPU="${GPU:-1}"
SEED="${SEED:-42}"
MIN_FREE_MIB="${MIN_FREE_MIB:-29000}"
POLL_SECONDS="${POLL_SECONDS:-60}"

RUN_ROOT="${RUN_ROOT:-/home/tsz-25/MedCLIPSeg-pristine/runs/UCFNRT_OACD_C3_FORMAL100_OACD_C3_F100_20260901_162536_S42}"

DATASET="Kvasir"

CONFIG="configs/ucfnrt_oacd_formal100/OACD_C3_LOCKED_FORMAL100.yaml"

RUN_TAG="SEMLT_UCFNRT_OACD_C3_FORMAL100_Kvasir"

RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"

DATA_ROOT="${PROJECT}/data/Kvasir"

TRAIN_PATH="${DATA_ROOT}/Train_Folder/"
VAL_PATH="${DATA_ROOT}/Val_Folder/"
TEST_PATH="${DATA_ROOT}/Test_Folder/"
PROMPT_PATH="${DATA_ROOT}/Prompts_Folder/"

# IMPORTANT:
# Same directory structure as the already completed BUSI formal run.
DATASET_OUT="${RUN_ROOT}/Kvasir"

FORMAL_STATE="${DATASET_OUT}/formal_state"

TRAIN_LOG="${RUN_ROOT}/Kvasir.train.log"
TEST_LOG="${RUN_ROOT}/Kvasir.test.log"
EVAL_LOG="${RUN_ROOT}/Kvasir.eval.log"

CKPT_DIR="${DATASET_OUT}/Kvasir/trained_models/seed${SEED}"

LAST="${CKPT_DIR}/${RUN_NAME}_last_epoch.pth"
LATEST="${CKPT_DIR}/${RUN_NAME}_latest.pth"

TEST_OUT="${DATASET_OUT}/formal_test"

RESULT_ROOT="${TEST_OUT}/Kvasir/seg_results/seed${SEED}"

cd "${PROJECT}"

export PYTHONPATH="${PROJECT}:${PROJECT}/utils${PYTHONPATH:+:${PYTHONPATH}}"

export HF_HOME="${PROJECT}/checkpoints"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_DATASETS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false

export MPLBACKEND=Agg

export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True,max_split_size_mb:128}"

mkdir -p \
    "${DATASET_OUT}" \
    "${FORMAL_STATE}" \
    "${TEST_OUT}"

# ------------------------------------------------------------
# Required input audit
# ------------------------------------------------------------

for P in \
    "${CONFIG}" \
    "${TRAIN_PATH}" \
    "${VAL_PATH}" \
    "${TEST_PATH}" \
    "${PROMPT_PATH}"
do
    if [[ ! -e "${P}" ]]; then
        echo "[FAIL] missing: ${P}"
        exit 10
    fi
done

# Do not silently overwrite a completed formal Kvasir run.
if [[ -f "${LAST}" ]]; then
    echo "[FAIL] physical Kvasir last_epoch already exists:"
    echo "${LAST}"
    echo
    echo "If this is an old/invalid run, inspect it before replacing it."
    exit 11
fi

# ------------------------------------------------------------
# GPU wait
# ------------------------------------------------------------

wait_gpu()
{
    while true
    do
        FREE="$(
            nvidia-smi \
              -i "${GPU}" \
              --query-gpu=memory.free \
              --format=csv,noheader,nounits \
            | head -1 \
            | tr -d '[:space:]'
        )"

        UTIL="$(
            nvidia-smi \
              -i "${GPU}" \
              --query-gpu=utilization.gpu \
              --format=csv,noheader,nounits \
            | head -1 \
            | tr -d '[:space:]'
        )"

        echo \
"[GPU WAIT] physical_gpu=${GPU} free=${FREE:-NA}MiB util=${UTIL:-NA}% required>=${MIN_FREE_MIB}MiB"

        if [[ "${FREE:-}" =~ ^[0-9]+$ ]] && \
           (( FREE >= MIN_FREE_MIB )); then

            echo \
"[GPU READY] physical_gpu=${GPU} free=${FREE}MiB"

            break
        fi

        sleep "${POLL_SECONDS}"
    done
}


echo "===================================================================================================="
echo "OACD C3 FULL FORMAL100 -- KVASIR"
echo "===================================================================================================="
echo "DATASET          = Kvasir"
echo "GPU              = ${GPU}"
echo "SEED             = ${SEED}"
echo "CONFIG           = ${CONFIG}"
echo "RUN_TAG          = ${RUN_TAG}"
echo "RUN_ROOT         = ${RUN_ROOT}"
echo "DATASET_OUT      = ${DATASET_OUT}"
echo
echo "TRAIN            = 100 physical epochs"
echo "BATCH            = 24"
echo "TRAIN MC         = 10"
echo "TEST MC          = 30"
echo "CHECKPOINT       = physical last_epoch"
echo "VAL SELECTION    = OFF"
echo
echo "FULL:"
echo "  Operator Align = ON"
echo "  Ordered CDF    = ON"
echo "  Reachable      = ON"
echo "===================================================================================================="


# ============================================================
# STAGE 0: config audit
# ============================================================

"${PYTHON}" - <<'PY'
from utils.main_utils import load_cfg_from_cfg_file

p = "configs/ucfnrt_oacd_formal100/OACD_C3_LOCKED_FORMAL100.yaml"

cfg = load_cfg_from_cfg_file(p)

assert cfg.M1.SEMLT_UC_FNRT is True
assert cfg.M1.SEMLT_UC_FNRT_ABLATION == "full"

assert cfg.M1.SEMLT_UC_OPERATOR_ALIGNED_CANDIDATES is True
assert cfg.M1.SEMLT_UC_ORDERED_CDF_LOSS is True
assert cfg.M1.SEMLT_UC_REACHABLE_MATCH_ONLY is True

assert int(cfg.TRAIN.NUM_EPOCHS) == 100
assert int(cfg.TRAIN.BATCH_SIZE) == 24
assert int(cfg.TRAIN.GRAD_ACCUMULATION_STEPS) == 1

assert abs(float(cfg.TRAIN.LEARNING_RATE) - 3e-4) < 1e-12

assert int(cfg.M1.GEOTR_TRAIN_POSTERIOR_SAMPLES) == 10
assert int(cfg.M1.M1_TRAIN_NUM_SAMPLES) == 1

assert int(cfg.TEST.NUM_SAMPLES) == 30

assert bool(cfg.TRAIN.USE_VALIDATION_SELECTION) is False

print("[PASS] OACD-C3 FULL locked protocol")
print("[PASS] Align=True CDF=True Reach=True")
print("[PASS] E100 B24 Adam3e-4 TrainMC10 TestMC30")
PY


# ============================================================
# STAGE 1: TRAIN
# ============================================================

wait_gpu

date -Is > "${FORMAL_STATE}/TRAIN_STARTED.lock"

echo
echo "===================================================================================================="
echo "[STAGE 1/4] TRAIN Kvasir FULL -- 100 EPOCHS"
echo "===================================================================================================="

CUDA_VISIBLE_DEVICES="${GPU}" \
"${PYTHON}" -u train.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --data_percentage 100 \
    --output-dir "${DATASET_OUT}" \
    DATASET.NAME Kvasir \
    DATASET.TRAIN_PATH "${TRAIN_PATH}" \
    DATASET.VAL_PATH "${VAL_PATH}" \
    DATASET.TEST_PATH "${TEST_PATH}" \
    DATASET.TEXT_PROMPT_PATH "${PROMPT_PATH}" \
    M1.RUN_TAG "${RUN_TAG}" \
    TRAIN.RUN_TAG "${RUN_TAG}" \
    > "${TRAIN_LOG}" 2>&1


if [[ ! -s "${LAST}" ]]; then
    echo "[FAIL] training returned but physical last_epoch does not exist"
    echo "Expected:"
    echo "${LAST}"
    exit 20
fi


{
    echo "dataset=Kvasir"
    echo "seed=${SEED}"
    echo "checkpoint=${LAST}"
    echo "sha256=$(sha256sum "${LAST}" | awk '{print $1}')"
    echo "completed_at=$(date -Is)"
} > "${FORMAL_STATE}/TRAIN_SUCCESS.lock"


echo "[PASS] Kvasir training complete"
echo "[LOCKED] ${LAST}"
sha256sum "${LAST}"


# ============================================================
# STAGE 2: TEST MC30
# ============================================================

wait_gpu

date -Is > "${FORMAL_STATE}/TEST_OPENED.lock"

echo
echo "===================================================================================================="
echo "[STAGE 2/4] TEST Kvasir FULL -- MC30"
echo "===================================================================================================="

CUDA_VISIBLE_DEVICES="${GPU}" \
"${PYTHON}" -u test.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --split test \
    --prompt_design original \
    --num-samples 30 \
    --checkpoint "${LAST}" \
    --output-dir "${TEST_OUT}" \
    DATASET.NAME Kvasir \
    DATASET.TRAIN_PATH "${TRAIN_PATH}" \
    DATASET.VAL_PATH "${VAL_PATH}" \
    DATASET.TEST_PATH "${TEST_PATH}" \
    DATASET.TEXT_PROMPT_PATH "${PROMPT_PATH}" \
    M1.RUN_TAG "${RUN_TAG}" \
    TRAIN.RUN_TAG "${RUN_TAG}" \
    > "${TEST_LOG}" 2>&1


echo "[PASS] MC30 inference complete"


# ============================================================
# STAGE 3: EVALUATION
# ============================================================

echo
echo "===================================================================================================="
echo "[STAGE 3/4] EVALUATION"
echo "===================================================================================================="

: > "${EVAL_LOG}"

eval_one()
{
    SUFFIX="$1"
    MODE="$2"
    CSV="$3"

    "${PYTHON}" -u utils/eval.py \
        --config-file "${CONFIG}" \
        --seed "${SEED}" \
        --split test \
        --output-dir "${TEST_OUT}" \
        --result-name "${RUN_NAME}_${SUFFIX}" \
        --csv-name "${CSV}" \
        --nsd-mode "${MODE}" \
        DATASET.NAME Kvasir \
        DATASET.TRAIN_PATH "${TRAIN_PATH}" \
        DATASET.VAL_PATH "${VAL_PATH}" \
        DATASET.TEST_PATH "${TEST_PATH}" \
        DATASET.TEXT_PROMPT_PATH "${PROMPT_PATH}" \
        M1.RUN_TAG "${RUN_TAG}" \
        TRAIN.RUN_TAG "${RUN_TAG}" \
        >> "${EVAL_LOG}" 2>&1
}


eval_one \
    BaseNative \
    true2d \
    test_BaseNative_true2d.csv

eval_one \
    M1Native \
    true2d \
    test_M1Native_true2d.csv

eval_one \
    BaseNative \
    paper_legacy \
    test_BaseNative_paper_legacy.csv

eval_one \
    M1Native \
    paper_legacy \
    test_M1Native_paper_legacy.csv


for F in \
    "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
    "${RESULT_ROOT}/test_M1Native_true2d.csv" \
    "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
    "${RESULT_ROOT}/test_M1Native_paper_legacy.csv"
do
    if [[ ! -s "${F}" ]]; then
        echo "[FAIL] evaluation CSV missing:"
        echo "${F}"
        exit 30
    fi
done


# ============================================================
# STAGE 4: paired statistics
# ============================================================

echo
echo "===================================================================================================="
echo "[STAGE 4/4] PAIRED BASE vs OACD"
echo "===================================================================================================="

if [[ -f tools/compare_geotr_m1_paired.py ]]; then

    "${PYTHON}" tools/compare_geotr_m1_paired.py \
        --base-csv "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
        --m1-csv "${RESULT_ROOT}/test_M1Native_true2d.csv" \
        --output-prefix "${RESULT_ROOT}/paired_true2d" \
        --protocol-label "Kvasir_OACD_C3_FULL_true2d_seed${SEED}" \
        >> "${EVAL_LOG}" 2>&1

    "${PYTHON}" tools/compare_geotr_m1_paired.py \
        --base-csv "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
        --m1-csv "${RESULT_ROOT}/test_M1Native_paper_legacy.csv" \
        --output-prefix "${RESULT_ROOT}/paired_paper_legacy" \
        --protocol-label "Kvasir_OACD_C3_FULL_paper_legacy_seed${SEED}" \
        >> "${EVAL_LOG}" 2>&1
fi


{
    echo "dataset=Kvasir"
    echo "seed=${SEED}"
    echo "checkpoint=${LAST}"
    echo "sha256=$(sha256sum "${LAST}" | awk '{print $1}')"
    echo "test_mc=30"
    echo "completed_at=$(date -Is)"
} > "${FORMAL_STATE}/TEST_SUCCESS.lock"


echo
echo "===================================================================================================="
echo "FINAL RESULTS"
echo "===================================================================================================="

grep -E \
'Average DSC|Average NSD|Cases evaluated' \
"${EVAL_LOG}" || true

echo
echo "[PASS] KVASIR OACD-C3 FULL FORMAL100 COMPLETE"
echo
echo "TRAIN_LOG = ${TRAIN_LOG}"
echo "TEST_LOG  = ${TEST_LOG}"
echo "EVAL_LOG  = ${EVAL_LOG}"
echo "CKPT      = ${LAST}"
echo "RESULTS   = ${RESULT_ROOT}"
echo "===================================================================================================="

