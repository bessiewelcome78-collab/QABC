#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:?DATASET is required}"
GPU="${GPU:?GPU is required}"
SEED="${SEED:-42}"
ROOT_ID="${ROOT_ID:?ROOT_ID is required}"
VARIANT="${VARIANT:?VARIANT is required}"
MODE="${MODE:-fresh}"
CONFIG="${SEMLT_ABLATION_VARIANT_CONFIG:-configs/SEMLT_ABLATION_FROZEN100.yaml}"
SPEC="${SPEC:-configs/SEMLT_ABLATION_LOCKED_VARIANTS.json}"
DATA_ROOT="${DATA_ROOT:-${PROJECT}/data/${DATASET}}"
TRAIN_PATH="${TRAIN_PATH:-${DATA_ROOT}/Train_Folder/}"
VAL_PATH="${VAL_PATH:-${DATA_ROOT}/Val_Folder/}"
TEST_PATH="${TEST_PATH:-${DATA_ROOT}/Test_Folder/}"
TEXT_PROMPT_PATH="${TEXT_PROMPT_PATH:-${DATA_ROOT}/Prompts_Folder/}"
case "${DATASET}" in BUSI|Kvasir) DATA_AUDIT_POLICY="${DATA_AUDIT_POLICY:-strict}" ;; BTMRI|ISIC) DATA_AUDIT_POLICY="${DATA_AUDIT_POLICY:-benchmark}" ;; *) echo "[FAIL] unsupported DATASET=${DATASET}"; exit 2;; esac
case "${MODE}" in fresh|resume|retry_failed) ;; *) echo "[FAIL] MODE must be fresh, resume or retry_failed"; exit 2;; esac
cd "${PROJECT}"; export TOKENIZERS_PARALLELISM=false; export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"; mkdir -p logs audits runs
# Fail closed on the actual runtime config.  A generic CONFIG exported by an
# older shell is intentionally ignored; only SEMLT_ABLATION_VARIANT_CONFIG can
# replace the locked causal-ablation file.
CONFIG_SHA_RUNTIME="$(sha256sum "${CONFIG}" | awk '{print $1}')"
"${PYTHON}" - "${CONFIG}" "${CONFIG_SHA_RUNTIME}" <<'PYCFG'
import sys, yaml
path, sha = sys.argv[1:]
cfg=yaml.safe_load(open(path, encoding="utf-8"))
m1=cfg.get("M1", {})
train=cfg.get("TRAIN", {})
checks = {
    "M1.ENABLED": m1.get("ENABLED") is True,
    "M1.PROTOCOL=geotr_m1": str(m1.get("PROTOCOL", "")).lower() == "geotr_m1",
    "M1.GEOTR_M1_CAUSAL_ABLATION=true": m1.get("GEOTR_M1_CAUSAL_ABLATION") is True,
    "M1.GEOTR_M1_MAIN_E2E100=false/absent": not bool(m1.get("GEOTR_M1_MAIN_E2E100", False)),
    "M1.V469_FREEZE_BASE=true": m1.get("V469_FREEZE_BASE") is True,
    "M1.GEOTR_M1_DETACH_CONDITIONERS=true": m1.get("GEOTR_M1_DETACH_CONDITIONERS") is True,
    "TRAIN.NUM_EPOCHS=100": int(train.get("NUM_EPOCHS", 0)) == 100,
    "TRAIN.USE_VALIDATION_SELECTION=false": train.get("USE_VALIDATION_SELECTION") is False,
}
bad=[k for k,v in checks.items() if not v]
if bad:
    raise SystemExit("[FAIL] locked SemLT variant config contract: " + ", ".join(bad))
print(f"[SEMLT ABL CONFIG] variant={path} sha256={sha} causal={m1.get('GEOTR_M1_CAUSAL_ABLATION')} freeze_base={m1.get('V469_FREEZE_BASE')} epochs={train.get('NUM_EPOCHS')}")
PYCFG
"${PYTHON}" tools/semlt_ablation_spec.py --spec "${SPEC}" --variant "${VARIANT}" >/dev/null
for p in "${CONFIG}" "${SPEC}" "${TRAIN_PATH}" "${VAL_PATH}" "${TEST_PATH}" "${TEXT_PROMPT_PATH}"; do [[ -e "${p}" ]] || { echo "[FAIL] missing ${p}"; exit 2; }; done
DATASET_TOKEN="$(printf '%s' "${DATASET}" | tr '[:lower:]-' '[:upper:]_')"
ROOT_RUN="runs/SEMLT_ABLATION_${ROOT_ID}/seed${SEED}/${DATASET}"
BASE_MANIFEST="${ROOT_RUN}/BASE_manifest.json"
BASE_SUCCESS="${ROOT_RUN}/common_base/BASE_SUCCESS.lock"
[[ -f "${BASE_MANIFEST}" && -f "${BASE_SUCCESS}" ]] || { echo "[FAIL] common Base is not locked: ${ROOT_RUN}"; exit 2; }
BASE_CHECKPOINT="$("${PYTHON}" -c 'import json,sys; print(json.load(open(sys.argv[1]))["base_checkpoint"])' "${BASE_MANIFEST}")"
BASE_EXPECTED_SHA="$("${PYTHON}" -c 'import json,sys; print(json.load(open(sys.argv[1]))["base_checkpoint_sha256"])' "${BASE_MANIFEST}")"
[[ -f "${BASE_CHECKPOINT}" ]] || { echo "[FAIL] Base checkpoint missing: ${BASE_CHECKPOINT}"; exit 2; }
[[ "$(sha256sum "${BASE_CHECKPOINT}" | awk '{print $1}')" == "${BASE_EXPECTED_SHA}" ]] || { echo "[FAIL] Base checkpoint bytes changed"; exit 2; }
RUN_TAG="SEMLT_ABL_${DATASET_TOKEN}_${VARIANT}_FROZEN100"
RUN_DIR="${ROOT_RUN}/variants/${VARIANT}"
RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"
CHECKPOINT_DIR="${RUN_DIR}/${DATASET}/trained_models/seed${SEED}"
CHECKPOINT="${CHECKPOINT_DIR}/${RUN_NAME}_last_epoch.pth"
VAL_REGISTRY="${ROOT_RUN}/val_common_base_registry.json"
MANIFEST="${RUN_DIR}/ABLATION_manifest.json"
SUCCESS="${RUN_DIR}/FORMAL_VAL_SUCCESS.lock"
if [[ "${MODE}" == fresh ]]; then
  [[ ! -e "${RUN_DIR}" ]] || { echo "[FAIL] variant run already exists: ${RUN_DIR}"; exit 2; }
  mkdir -p "${RUN_DIR}"
elif [[ "${MODE}" == retry_failed ]]; then
  [[ ! -f "${SUCCESS}" ]] || { echo "[FAIL] completed run cannot be retried: ${RUN_DIR}"; exit 2; }
  [[ ! -f "${RUN_DIR}/FORMAL_TEST_OPENED.lock" ]] || { echo "[FAIL] Test-opened run cannot be retried: ${RUN_DIR}"; exit 2; }
  if [[ -e "${RUN_DIR}" ]]; then
    FAILED_ROOT="${ROOT_RUN}/failed_attempts"
    mkdir -p "${FAILED_ROOT}"
    FAILED_ARCHIVE="${FAILED_ROOT}/${VARIANT}_$(date +%Y%m%d_%H%M%S)"
    mv "${RUN_DIR}" "${FAILED_ARCHIVE}"
    echo "[RECOVER] archived incomplete ${VARIANT} attempt -> ${FAILED_ARCHIVE}"
  fi
  mkdir -p "${RUN_DIR}"
else
  [[ -d "${RUN_DIR}" && -f "${CHECKPOINT_DIR}/${RUN_NAME}_latest.pth" ]] || { echo "[FAIL] resume checkpoint missing for ${RUN_DIR}"; exit 2; }
  [[ ! -f "${SUCCESS}" ]] || { echo "[FAIL] run already complete: ${RUN_DIR}"; exit 2; }
fi
ALLOW_SHARED_GPU="${ALLOW_SHARED_GPU:-0}"
if [[ "${ALLOW_SHARED_GPU}" != 1 && -x "$(command -v flock || true)" ]]; then
  exec 9>"${PROJECT}/.semlt_ablation_gpu${GPU}.lock"; flock -n 9 || { echo "[FAIL] GPU ${GPU} already in use by SemLT ablation"; exit 2; }
fi
OVERRIDES=(
  DATASET.NAME "${DATASET}" DATASET.TRAIN_PATH "${TRAIN_PATH}" DATASET.VAL_PATH "${VAL_PATH}" DATASET.TEST_PATH "${TEST_PATH}" DATASET.TEXT_PROMPT_PATH "${TEXT_PROMPT_PATH}"
)
while IFS=$'\t' read -r key value; do OVERRIDES+=("${key}" "${value}"); done < <("${PYTHON}" tools/semlt_ablation_spec.py --spec "${SPEC}" --variant "${VARIANT}" --emit-overrides)
STAMP="$(date +%Y%m%d_%H%M%S)"; LOG="logs/${RUN_TAG}_seed${SEED}_gpu${GPU}_${STAMP}.log"
TRAIN_ARGS=(); [[ "${MODE}" == resume ]] && TRAIN_ARGS+=(--resume)
echo "[SEMLT ABL] dataset=${DATASET} seed=${SEED} variant=${VARIANT} mode=${MODE} base_sha=${BASE_EXPECTED_SHA} config=${CONFIG} config_sha=${CONFIG_SHA_RUNTIME}"
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py --config-file "${CONFIG}" --seed "${SEED}" --output-dir "${RUN_DIR}" --init-checkpoint "${BASE_CHECKPOINT}" "${TRAIN_ARGS[@]}" \
  TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" "${OVERRIDES[@]}" 2>&1 | tee -a "${LOG}"
[[ -f "${CHECKPOINT}" ]] || { echo "[FAIL] epoch-100 checkpoint missing: ${CHECKPOINT}"; exit 2; }
OUT="${RUN_DIR}/formal_val"
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u test.py --config-file "${CONFIG}" --seed "${SEED}" --split val --num-samples 1 --checkpoint "${CHECKPOINT}" --output-dir "${OUT}" \
  TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" "${OVERRIDES[@]}"
RESULT_ROOT="${OUT}/${DATASET}/seg_results/seed${SEED}"
for mode in true2d paper_legacy; do
  "${PYTHON}" -u utils/eval.py --config-file "${CONFIG}" --seed "${SEED}" --split val --output-dir "${OUT}" --result-name "${RUN_NAME}_BaseNative" --csv-name "val_BaseNative_${mode}.csv" --nsd-mode "${mode}" TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" "${OVERRIDES[@]}"
  "${PYTHON}" -u utils/eval.py --config-file "${CONFIG}" --seed "${SEED}" --split val --output-dir "${OUT}" --result-name "${RUN_NAME}_M1Native" --csv-name "val_M1Native_${mode}.csv" --nsd-mode "${mode}" TRAIN.RUN_TAG "${RUN_TAG}" M1.RUN_TAG "${RUN_TAG}" "${OVERRIDES[@]}"
  "${PYTHON}" tools/compare_geotr_m1_paired.py --base-csv "${RESULT_ROOT}/val_BaseNative_${mode}.csv" --m1-csv "${RESULT_ROOT}/val_M1Native_${mode}.csv" --output-prefix "${RESULT_ROOT}/paired_${mode}" --protocol-label "${DATASET}_val_${mode}_SemLT_locked_ablation"
done
"${PYTHON}" tools/verify_geotr_m1_common_base.py --checkpoint "${BASE_CHECKPOINT}" --base-csv "${RESULT_ROOT}/val_BaseNative_true2d.csv" --registry "${VAL_REGISTRY}"
SPEC_SHA="$(sha256sum "${SPEC}" | awk '{print $1}')"; CONFIG_SHA="$(sha256sum "${CONFIG}" | awk '{print $1}')"; TRANSPORT_SHA="$(sha256sum utils/geotr_m1_transport.py | awk '{print $1}')"; LOSS_SHA="$(sha256sum utils/geotr_m1_loss.py | awk '{print $1}')"
"${PYTHON}" - "${MANIFEST}" "${DATASET}" "${SEED}" "${ROOT_ID}" "${VARIANT}" "${RUN_TAG}" "${RUN_DIR}" "${CHECKPOINT}" "${BASE_CHECKPOINT}" "${BASE_EXPECTED_SHA}" "${CONFIG}" "${CONFIG_SHA}" "${SPEC}" "${SPEC_SHA}" "${TRANSPORT_SHA}" "${LOSS_SHA}" "${TRAIN_PATH}" "${VAL_PATH}" "${TEST_PATH}" "${TEXT_PROMPT_PATH}" "${VAL_REGISTRY}" <<'PY'
import json,sys
from pathlib import Path
(out,ds,seed,root_id,var,tag,run_dir,ckpt,base,base_sha,cfg,cfg_sha,spec,spec_sha,tr_sha,loss_sha,tr,va,te,pr,registry)=sys.argv[1:]
p={"schema_version":1,"protocol":"SemLT_locked_causal_ablation_v1","dataset":ds,"seed":int(seed),"root_id":root_id,"variant":var,"run_tag":tag,
"run_dir":str(Path(run_dir).resolve()),"checkpoint":str(Path(ckpt).resolve()),"base_checkpoint":str(Path(base).resolve()),"base_checkpoint_sha256":base_sha,
"config":cfg,"config_sha256":cfg_sha,"spec":spec,"spec_sha256":spec_sha,"transport_sha256":tr_sha,"loss_sha256":loss_sha,
"train_path":str(Path(tr).resolve()),"val_path":str(Path(va).resolve()),"test_path":str(Path(te).resolve()),"prompt_path":str(Path(pr).resolve()),
"val_common_base_registry":str(Path(registry).resolve()),"method_locked_before_test":True,"primary_nsd_protocol":"true2d","test_opened":False}
Path(out).write_text(json.dumps(p,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
PY
printf 'completed_at=%s\nvariant=%s\ncheckpoint=%s\nreport=%s\n' "$(date --iso-8601=seconds)" "${VARIANT}" "${CHECKPOINT}" "${RESULT_ROOT}/paired_true2d.json" > "${SUCCESS}"
echo "[PASS] ${DATASET}/seed${SEED}/${VARIANT} locked validation complete"
echo "REPORT=${RESULT_ROOT}/paired_true2d.md"
