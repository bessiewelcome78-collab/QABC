#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
TASK="${TASK:-matrix}"
STAMP="$(date +%Y%m%d_%H%M%S)"
cd "${PROJECT}"
mkdir -p logs

case "${TASK}" in
  matrix) SCRIPT=launch_geotr_m1_lest57_matrix.sh ;;
  e2e) SCRIPT=launch_geotr_m1_lest57_e2e100.sh ;;
  *) echo "[FAIL] TASK must be matrix or e2e"; exit 2 ;;
esac
LOG="logs/GEOTR_M1_LEST57_${TASK}_seed${SEED}_gpu${GPU}_${STAMP}.nohup.log"
nohup env PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPU="${GPU}" SEED="${SEED}" \
  DATASET="${DATASET:-BUSI}" PHASE="${PHASE:-val}" \
  BASE_CHECKPOINT="${BASE_CHECKPOINT:-}" VARIANTS="${VARIANTS:-}" \
  RUN_TAG="${RUN_TAG:-}" bash "${SCRIPT}" > "${LOG}" 2>&1 < /dev/null &
PID=$!
echo "[STARTED] pid=${PID}"
echo "          log=${LOG}"
echo "          status: ps -p ${PID} -o pid,etime,stat,cmd"
echo "          follow: tail -f ${LOG}"
