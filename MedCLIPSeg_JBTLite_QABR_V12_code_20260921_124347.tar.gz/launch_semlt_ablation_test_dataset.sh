#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"; PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:?DATASET required}"; SEED="${SEED:-42}"; ROOT_ID="${ROOT_ID:?ROOT_ID required}"; GPUS="${GPUS:-0 1 2 3 4 5}"
cd "${PROJECT}"; read -r -a gs <<< "${GPUS}"; [[ ${#gs[@]} -eq 6 ]] || { echo '[FAIL] need six GPUs'; exit 2; }; [[ "$(printf '%s\n' "${gs[@]}"|sort -u|wc -l)" -eq 6 ]] || { echo '[FAIL] duplicate GPUs'; exit 2; }
vs=(A1_REWRITE A2_PROB A3_NORMAL1D A4_FREE2D A5_SUPPORT A6_SEMLT); root="runs/SEMLT_ABLATION_${ROOT_ID}/seed${SEED}/${DATASET}"; pids=(); logs=(); stamp="$(date +%Y%m%d_%H%M%S)"
for v in "${vs[@]}"; do mf="${root}/variants/${v}/ABLATION_manifest.json"; [[ -f "${mf}" && -f "${root}/variants/${v}/FORMAL_VAL_SUCCESS.lock" ]] || { echo "[FAIL] validation lock/manifest missing: ${v}"; exit 2; }; done
for i in "${!vs[@]}"; do v="${vs[$i]}"; g="${gs[$i]}"; mf="${root}/variants/${v}/ABLATION_manifest.json"; log="logs/SEMLT_ABL_TEST_${DATASET}_seed${SEED}_${v}_gpu${g}_${ROOT_ID}_${stamp}.log"; logs+=("${log}"); CUDA_VISIBLE_DEVICES="${g}" "${PYTHON}" tools/semlt_ablation_test_once.py --manifest "${mf}" --gpu "${g}" --python "${PYTHON}" >"${log}" 2>&1 & pids+=("$!"); echo "[TEST STARTED] ${DATASET} seed${SEED} ${v} gpu=${g} pid=$!"; done
status=0; for i in "${!pids[@]}"; do if ! wait "${pids[$i]}"; then echo "[FAIL] test ${vs[$i]} log=${logs[$i]}"; status=2; fi; done; ((status==0)) || exit "${status}"
echo "[PASS] ${DATASET} seed${SEED} all six one-shot tests complete"
