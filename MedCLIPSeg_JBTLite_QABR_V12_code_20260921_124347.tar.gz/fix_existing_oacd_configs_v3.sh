#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
cd "$PROJECT"
"$PYTHON" - <<'PY'
from pathlib import Path
import yaml
base=Path('configs/ucfnrt_oacd_busi_minabl100')
for p in sorted(base.glob('*.yaml')):
    d=yaml.safe_load(p.read_text())
    m=d.setdefault('M1', {})
    m['GEOTOPO_REFINEMENT_ENABLED']=True
    m['GEOTOPO_MODE']='geometry'
    p.write_text(yaml.safe_dump(d, sort_keys=False, allow_unicode=True))
    print('[FIXED]', p)
PY
"$PYTHON" tools/check_oacd_ablation_contract.py "$PROJECT"
echo '[PASS] existing OACD configs repaired to v3 routing contract'
