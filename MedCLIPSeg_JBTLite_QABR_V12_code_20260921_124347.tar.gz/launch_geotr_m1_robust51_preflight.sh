#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}:${PYTHONPATH:-}"

echo "=============================================================================================================="
echo "GEOTR-M1 ROBUST51 PREFLIGHT | boundary-aware diffeomorphic transport, M2/M3 physically absent"
echo "PROJECT=${PROJECT}"
echo "PYTHON=${PYTHON}"
echo "=============================================================================================================="

"${PYTHON}" -m py_compile \
  utils/metrics_2d.py utils/geotr_m1_transport.py utils/geotr_m1_loss.py \
  trainers/medclipseg_unimedclip.py train.py test.py \
  tools/check_geotr_m1_robust51_config.py \
  tools/test_geotr_m1_robust51_contract.py
"${PYTHON}" tools/test_metrics_2d.py
"${PYTHON}" tools/check_geotr_m1_robust51_config.py
"${PYTHON}" tools/test_geotr_m1_legacy_equivalence.py
"${PYTHON}" tools/test_geotr_m1_robust51_contract.py

echo "[PASS] GEOTR-M1 Robust51 preflight finished"
echo "       M1: Base logits -> semantic-conditioned stationary velocity -> one integrated warp"
echo "       Loss: BCE/Dice + contour/SDF + non-inferiority + locality/Jacobian control"
echo "       Selection: qualification precedes best-M1 saving; Test remains unopened"
echo "       M2/M3: physically absent"
