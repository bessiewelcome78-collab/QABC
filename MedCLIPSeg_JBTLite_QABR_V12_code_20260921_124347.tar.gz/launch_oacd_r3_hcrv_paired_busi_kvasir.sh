#!/usr/bin/env bash
set -Eeuo pipefail

# Paired R2.1(R=8) -> R3-HCRV(R=16) Train-only test on BUSI and Kvasir.
# The same seed and protected Base/PVL trajectory are required in both arms.
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
DATASETS="${DATASETS:-BUSI Kvasir}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
REPORT_DIR="${PROJECT}/reports/OACD_R3_HCRV_${ROOT_ID}"
mkdir -p "${REPORT_DIR}"

[[ -x "${PYTHON}" ]] || { echo "python is not executable: ${PYTHON}" >&2; exit 2; }
[[ -f "${PROJECT}/datasets/dataloader.py" ]] || {
  echo "missing ${PROJECT}/datasets/dataloader.py" >&2
  echo "run: PROJECT=${PROJECT} PYTHON=${PYTHON} bash ${PROJECT}/repair_oacd_r3_runtime.sh" >&2
  exit 3
}
[[ -s "${PROJECT}/open_clip_lib/bpe_simple_vocab_16e6.txt.gz" ]] || {
  echo "missing ${PROJECT}/open_clip_lib/bpe_simple_vocab_16e6.txt.gz" >&2
  echo "run: PROJECT=${PROJECT} PYTHON=${PYTHON} bash ${PROJECT}/repair_oacd_r3_runtime.sh" >&2
  exit 3
}

all_pass=1
for dataset in ${DATASETS}; do
  PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPU="${GPU}" \
    DATASET="${dataset}" SEED="${SEED}" ROOT_ID="${ROOT_ID}" \
    bash "${PROJECT}/launch_oacd_r21_cal_diag20.sh"

  PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPU="${GPU}" \
    DATASET="${dataset}" SEED="${SEED}" ROOT_ID="${ROOT_ID}" \
    bash "${PROJECT}/launch_oacd_r3_hcrv_diag20.sh"

  baseline_log="${PROJECT}/logs/OACD_R21_CAL_${ROOT_ID}/${dataset}_S${SEED}.train.log"
  r3_log="${PROJECT}/logs/OACD_R3_HCRV_${ROOT_ID}/${dataset}_S${SEED}.train.log"
  report="${REPORT_DIR}/${dataset}_S${SEED}.comparison.txt"
  json="${REPORT_DIR}/${dataset}_S${SEED}.comparison.json"

  set +e
  "${PYTHON}" tools/compare_oacd_r3_hcrv_diag20.py \
    --baseline-log "${baseline_log}" --r3-log "${r3_log}" \
    --dataset "${dataset}" --seed "${SEED}" --json "${json}" \
    2>&1 | tee "${report}"
  rc=${PIPESTATUS[0]}
  set -e
  if [[ ${rc} -ne 0 ]]; then
    all_pass=0
  fi
done

printf 'OACD_R3_HCRV_TWO_DATASET_GATES_PASS=%d\n' "${all_pass}" | tee "${REPORT_DIR}/decision.txt"
if [[ ${all_pass} -ne 1 ]]; then
  echo "Do not start Formal100; inspect ${REPORT_DIR}" >&2
  exit 10
fi
echo "Both datasets passed. Formal100 may be scheduled with a new ROOT_ID."
