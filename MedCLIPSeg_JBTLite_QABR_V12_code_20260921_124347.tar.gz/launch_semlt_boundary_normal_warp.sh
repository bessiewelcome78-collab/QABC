#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
DATASET="${DATASET:-BUSI}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
MODE="${MODE:-DIAG20}"
case "${DATASET}" in BUSI|BTMRI|ISIC|Kvasir) ;; *) echo 'DATASET must be BUSI|BTMRI|ISIC|Kvasir'; exit 2;; esac
case "${MODE}" in DIAG20|PAPER100) ;; *) echo 'MODE must be DIAG20|PAPER100'; exit 2;; esac
CONFIG="configs/${DATASET}_SEMLT_BOUNDARY_NORMAL_WARP_${MODE}.yaml"
EXP_ID="${EXP_ID:-BNWARP_${MODE}_${DATASET}_S${SEED}_$(date +%Y%m%d_%H%M%S)}"
RUN_ROOT="${RUN_ROOT:-runs/${EXP_ID}}"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
export TOKENIZERS_PARALLELISM=false
unset PYTORCH_CUDA_ALLOC_CONF 2>/dev/null || true
export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True}"
mkdir -p "${RUN_ROOT}" logs

"${PYTHON}" -m py_compile \
  utils/semlt_autozero_transport.py \
  utils/semlt_autozero_loss.py \
  trainers/medclipseg_unimedclip.py \
  train.py
"${PYTHON}" tools/test_semlt_boundary_normal_warp_contract.py
"${PYTHON}" tools/check_semlt_boundary_normal_warp_configs.py
# Backward-compatibility regression: archived v3.1 behavior must stay intact.
"${PYTHON}" tools/test_semlt_lst_v31_rootfix_contract.py

MIN_FREE_GPU_MIB="${MIN_FREE_GPU_MIB:-43000}"
if command -v nvidia-smi >/dev/null 2>&1; then
  GPU_FREE_MIB="$(nvidia-smi --id="${GPU}" --query-gpu=memory.free --format=csv,noheader,nounits | head -n 1 | tr -d '[:space:]')"
  echo "[GPU PREFLIGHT] gpu=${GPU} free=${GPU_FREE_MIB}MiB required=${MIN_FREE_GPU_MIB}MiB"
  if [[ ! "${GPU_FREE_MIB}" =~ ^[0-9]+$ ]] || (( GPU_FREE_MIB < MIN_FREE_GPU_MIB )); then
    echo "[FAIL] selected GPU is not sufficiently idle for physical batch=24"; exit 3
  fi
fi

echo "[SemLT Boundary-Normal Warp] MODE=${MODE} DATASET=${DATASET} SEED=${SEED}"
echo "[OPERATOR] detached Base logits -> Base foreground normal -> d=r*tanh(head) -> true grid_sample logit warp"
echo "[TRAIN TARGET] current Base boundary -> nearest GT boundary -> normal projection -> inverse-warp signed displacement"
echo "[KEEP] d=0 is structural exact identity; no Gate/Type/Action-Value selector"
echo "[LOSS] equal-group mean: normalized displacement + final BCE/Dice + TV/fold geometry regularity"
echo "[FAIRNESS] from scratch; batch=24 Adam lr=3e-4; DIAG20 shares PAPER100 first-20 cosine schedule; Val/Test unopened"
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "${CONFIG}" \
  --seed "${SEED}" \
  --output-dir "${RUN_ROOT}"
echo "[PASS] completed ${MODE}: ${RUN_ROOT}"
