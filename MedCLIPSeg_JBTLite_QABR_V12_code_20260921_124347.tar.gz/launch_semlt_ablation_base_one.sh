#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:?DATASET is required}"
GPU="${GPU:?GPU is required}"
SEED="${SEED:-42}"
ROOT_ID="${ROOT_ID:?ROOT_ID is required}"
CONFIG="${SEMLT_ABLATION_BASE_CONFIG:-configs/SEMLT_ABLATION_COMMON_BASE100.yaml}"
DATA_ROOT="${DATA_ROOT:-${PROJECT}/data/${DATASET}}"
TRAIN_PATH="${TRAIN_PATH:-${DATA_ROOT}/Train_Folder/}"
VAL_PATH="${VAL_PATH:-${DATA_ROOT}/Val_Folder/}"
TEST_PATH="${TEST_PATH:-${DATA_ROOT}/Test_Folder/}"
TEXT_PROMPT_PATH="${TEXT_PROMPT_PATH:-${DATA_ROOT}/Prompts_Folder/}"
case "${DATASET}" in BUSI|Kvasir) DATA_AUDIT_POLICY="${DATA_AUDIT_POLICY:-strict}" ;; BTMRI|ISIC) DATA_AUDIT_POLICY="${DATA_AUDIT_POLICY:-benchmark}" ;; *) echo "[FAIL] unsupported DATASET=${DATASET}"; exit 2;; esac
cd "${PROJECT}"; mkdir -p logs audits runs
# Locked ablation must not inherit a generic CONFIG variable from an unrelated
# historical experiment.  Only SEMLT_ABLATION_BASE_CONFIG may override this file.
"${PYTHON}" - "${CONFIG}" <<'PYCFG'
import sys, yaml
cfg=yaml.safe_load(open(sys.argv[1], encoding="utf-8"))
m1=cfg.get("M1", {})
train=cfg.get("TRAIN", {})
assert m1.get("ENABLED") is False, "Common Base config must have M1.ENABLED=false"
assert int(train.get("NUM_EPOCHS", 0)) == 100
assert int(train.get("SCHEDULER_TOTAL_EPOCHS", 0)) == 100
assert bool(train.get("USE_VALIDATION_SELECTION", True)) is False
print(f"[SEMLT ABL CONFIG] base={sys.argv[1]} M1.ENABLED={m1.get('ENABLED')} epochs={train.get('NUM_EPOCHS')}")
PYCFG
DATASET_TOKEN="$(printf '%s' "${DATASET}" | tr '[:lower:]-' '[:upper:]_')"
ROOT_RUN="runs/SEMLT_ABLATION_${ROOT_ID}/seed${SEED}/${DATASET}"
BASE_DIR="${ROOT_RUN}/common_base"
BASE_TAG="SEMLT_ABL_${DATASET_TOKEN}_COMMON_BASE100"
RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${BASE_TAG}"
CHECKPOINT="${BASE_DIR}/${DATASET}/trained_models/seed${SEED}/${RUN_NAME}_last_epoch.pth"
SUCCESS="${BASE_DIR}/BASE_SUCCESS.lock"
MANIFEST="${ROOT_RUN}/BASE_manifest.json"
if [[ -f "${SUCCESS}" && -f "${CHECKPOINT}" && -f "${MANIFEST}" ]]; then
  echo "[REUSE] locked common Base exists: ${CHECKPOINT}"; exit 0
fi
if [[ -e "${BASE_DIR}" && -n "$(find "${BASE_DIR}" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  echo "[FAIL] incomplete/nonempty Base directory exists without success lock: ${BASE_DIR}"; exit 2
fi
mkdir -p "${ROOT_RUN}"
PROJECT="${PROJECT}" PYTHON="${PYTHON}" GPU="${GPU}" SEED="${SEED}" DATASET="${DATASET}" \
  DATA_AUDIT_POLICY="${DATA_AUDIT_POLICY}" CONFIG="${CONFIG}" RUN_TAG="${BASE_TAG}" RUN_DIR="${BASE_DIR}" \
  DATA_ROOT="${DATA_ROOT}" TRAIN_PATH="${TRAIN_PATH}" VAL_PATH="${VAL_PATH}" TEST_PATH="${TEST_PATH}" TEXT_PROMPT_PATH="${TEXT_PROMPT_PATH}" \
  bash launch_geotr_m1_causal56_base100.sh
[[ -f "${CHECKPOINT}" ]] || { echo "[FAIL] common Base checkpoint missing: ${CHECKPOINT}"; exit 2; }
BASE_SHA="$(sha256sum "${CHECKPOINT}" | awk '{print $1}')"
CONFIG_SHA="$(sha256sum "${CONFIG}" | awk '{print $1}')"
TRAIN_SHA="$(sha256sum train.py | awk '{print $1}')"
"${PYTHON}" - "${MANIFEST}" "${DATASET}" "${SEED}" "${ROOT_ID}" "${DATA_AUDIT_POLICY}" "${CONFIG}" "${CONFIG_SHA}" "${CHECKPOINT}" "${BASE_SHA}" "${TRAIN_SHA}" "${TRAIN_PATH}" "${VAL_PATH}" "${TEST_PATH}" "${TEXT_PROMPT_PATH}" <<'PY'
import json,sys
from pathlib import Path
(out,ds,seed,root_id,audit,cfg,cfgsha,ckpt,cksha,trainsha,tr,va,te,pr)=sys.argv[1:]
p={"schema_version":1,"protocol":"SemLT_locked_causal_ablation_v1","dataset":ds,"seed":int(seed),"root_id":root_id,"audit_policy":audit,
"base_config":cfg,"base_config_sha256":cfgsha,"base_checkpoint":str(Path(ckpt).resolve()),"base_checkpoint_sha256":cksha,"train_py_sha256":trainsha,
"train_path":str(Path(tr).resolve()),"val_path":str(Path(va).resolve()),"test_path":str(Path(te).resolve()),"prompt_path":str(Path(pr).resolve())}
Path(out).write_text(json.dumps(p,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
PY
printf 'completed_at=%s\ncheckpoint=%s\nsha256=%s\n' "$(date --iso-8601=seconds)" "${CHECKPOINT}" "${BASE_SHA}" > "${SUCCESS}"
echo "[PASS] locked common Base complete: ${DATASET} seed${SEED}"
echo "BASE_CHECKPOINT=${CHECKPOINT}"
