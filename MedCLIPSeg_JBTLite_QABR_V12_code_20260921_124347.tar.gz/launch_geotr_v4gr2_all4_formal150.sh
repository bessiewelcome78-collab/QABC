#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
cd "${PROJECT}" || exit 1
SEED="${SEED:-42}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs
pids=()
GPU_A0="${GPU_A0:-0}"
GPU="${GPU_A0}" SEED="${SEED}" bash launch_geotr_v4gr2_a0_formal150.sh > "logs/GEOTR_V4GR2_A0_FORMAL150_driver_${STAMP}.log" 2>&1 & pids+=("$!")
GPU_A1="${GPU_A1:-1}"
GPU="${GPU_A1}" SEED="${SEED}" bash launch_geotr_v4gr2_a1_formal150.sh > "logs/GEOTR_V4GR2_A1_FORMAL150_driver_${STAMP}.log" 2>&1 & pids+=("$!")
GPU_A2="${GPU_A2:-2}"
GPU="${GPU_A2}" SEED="${SEED}" bash launch_geotr_v4gr2_a2_formal150.sh > "logs/GEOTR_V4GR2_A2_FORMAL150_driver_${STAMP}.log" 2>&1 & pids+=("$!")
GPU_A3="${GPU_A3:-3}"
GPU="${GPU_A3}" SEED="${SEED}" bash launch_geotr_v4gr2_a3_formal150.sh > "logs/GEOTR_V4GR2_A3_FORMAL150_driver_${STAMP}.log" 2>&1 & pids+=("$!")
for p in "${pids[@]}"; do wait "$p"; done
echo "[PASS] GEOTR V4G-R2 all4 FORMAL150 finished"
