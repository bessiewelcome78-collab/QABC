| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BUSI | 90.88 | 77.16 | 30.6 | 52.8 | 65.5 | 66.7 | 48.3 |
