| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Kvasir | 92.45 | 68.51 | 34.4 | 52.6 | 60.9 | 80.0 | 49.8 |
