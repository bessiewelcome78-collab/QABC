| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| ISIC | 95.59 | 65.59 | 63.9 | 88.8 | 95.1 | 95.0 | 76.4 |
