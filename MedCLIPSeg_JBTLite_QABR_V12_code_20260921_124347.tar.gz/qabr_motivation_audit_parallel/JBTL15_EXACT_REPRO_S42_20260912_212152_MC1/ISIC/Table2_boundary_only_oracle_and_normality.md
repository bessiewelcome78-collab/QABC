| Dataset | QABR-band Oracle ΔDSC (pp) | QABR-band Oracle ΔNSD (pp) | GT-band r=5 ΔDSC (pp) | GT-band r=5 ΔNSD (pp) | Normal alignment | |cos|≥0.7 (%) | Actual QABR ΔNSD (pp) |
|---|---:|---:|---:|---:|---:|---:|---:|
| ISIC | +3.68 | +28.59 | +4.04 | +29.66 | 0.924 | 82.2 | +0.48 |
