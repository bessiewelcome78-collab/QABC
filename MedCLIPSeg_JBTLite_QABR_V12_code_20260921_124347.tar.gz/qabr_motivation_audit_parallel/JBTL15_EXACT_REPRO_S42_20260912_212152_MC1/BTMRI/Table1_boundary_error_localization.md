| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BTMRI | 69.51 | 66.37 | 35.4 | 50.1 | 57.7 | 70.0 | 65.9 |
