| Dataset | QABR-band Oracle ΔDSC (pp) | QABR-band Oracle ΔNSD (pp) | GT-band r=5 ΔDSC (pp) | GT-band r=5 ΔNSD (pp) | Normal alignment | |cos|≥0.7 (%) | Actual QABR ΔNSD (pp) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BUSI | +7.46 | +22.72 | +7.24 | +23.53 | 0.930 | 82.6 | +0.27 |
| Kvasir | +4.86 | +22.04 | +5.00 | +23.40 | 0.923 | 82.8 | +2.01 |
| ISIC | +3.68 | +28.59 | +4.04 | +29.66 | 0.924 | 82.2 | +0.48 |
| BTMRI | +16.63 | +19.66 | +16.22 | +19.25 | 0.876 | 75.6 | +0.57 |
