| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BTMRI | 70.32 | 60.38 | 37.0 | 60.0 | 70.7 | 70.5 | 52.0 |
