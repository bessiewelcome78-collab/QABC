| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Kvasir | 90.06 | 64.61 | 31.1 | 48.0 | 57.0 | 74.0 | 42.9 |
