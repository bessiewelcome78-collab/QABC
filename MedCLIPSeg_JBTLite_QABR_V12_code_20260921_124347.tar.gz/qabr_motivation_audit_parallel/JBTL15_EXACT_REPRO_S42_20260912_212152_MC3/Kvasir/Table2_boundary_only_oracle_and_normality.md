| Dataset | QABR-band Oracle ΔDSC (pp) | QABR-band Oracle ΔNSD (pp) | GT-band r=5 ΔDSC (pp) | GT-band r=5 ΔNSD (pp) | Normal alignment | |cos|≥0.7 (%) | Actual QABR ΔNSD (pp) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Kvasir | +5.12 | +22.39 | +5.98 | +24.63 | 0.912 | 80.5 | +1.68 |
