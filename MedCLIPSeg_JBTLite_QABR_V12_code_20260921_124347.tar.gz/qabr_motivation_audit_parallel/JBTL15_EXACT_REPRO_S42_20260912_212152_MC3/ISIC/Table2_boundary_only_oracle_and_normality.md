| Dataset | QABR-band Oracle ΔDSC (pp) | QABR-band Oracle ΔNSD (pp) | GT-band r=5 ΔDSC (pp) | GT-band r=5 ΔNSD (pp) | Normal alignment | |cos|≥0.7 (%) | Actual QABR ΔNSD (pp) |
|---|---:|---:|---:|---:|---:|---:|---:|
| ISIC | +4.76 | +32.98 | +5.50 | +36.33 | 0.924 | 83.3 | +0.51 |
