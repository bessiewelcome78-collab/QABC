| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| ISIC | 93.78 | 55.86 | 53.5 | 82.2 | 91.2 | 90.0 | 68.2 |
