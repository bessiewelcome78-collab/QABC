| Dataset | QABR-band Oracle ΔDSC (pp) | QABR-band Oracle ΔNSD (pp) | GT-band r=5 ΔDSC (pp) | GT-band r=5 ΔNSD (pp) | Normal alignment | |cos|≥0.7 (%) | Actual QABR ΔNSD (pp) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BUSI | +7.45 | +25.22 | +9.30 | +30.32 | 0.924 | 82.4 | +0.42 |
| Kvasir | +5.12 | +22.39 | +5.98 | +24.63 | 0.912 | 80.5 | +1.68 |
| ISIC | +4.76 | +32.98 | +5.50 | +36.33 | 0.924 | 83.3 | +0.51 |
| BTMRI | +18.04 | +25.87 | +28.11 | +35.74 | 0.852 | 71.7 | +0.46 |
