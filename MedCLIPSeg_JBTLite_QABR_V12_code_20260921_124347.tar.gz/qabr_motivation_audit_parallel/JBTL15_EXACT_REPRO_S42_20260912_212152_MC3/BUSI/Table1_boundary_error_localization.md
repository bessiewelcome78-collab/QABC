| Dataset | Base DSC (%) | Base NSD (%) | Err≤2px (%) | Err≤5px (%) | Err≤8px (%) | Boundary-dominant cases (%) | QABR-band error coverage (%) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BUSI | 87.80 | 63.62 | 30.1 | 51.4 | 63.1 | 72.3 | 41.3 |
