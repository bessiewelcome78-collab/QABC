| Dataset | QABR-band Oracle ΔDSC (pp) | QABR-band Oracle ΔNSD (pp) | GT-band r=5 ΔDSC (pp) | GT-band r=5 ΔNSD (pp) | Normal alignment | |cos|≥0.7 (%) | Actual QABR ΔNSD (pp) |
|---|---:|---:|---:|---:|---:|---:|---:|
| BUSI | +7.45 | +25.22 | +9.30 | +30.32 | 0.924 | 82.4 | +0.42 |
