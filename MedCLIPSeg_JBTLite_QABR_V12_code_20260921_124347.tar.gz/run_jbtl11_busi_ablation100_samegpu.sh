#!/usr/bin/env bash
set -euo pipefail
PROJECT="${PROJECT:-$PWD}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATA_DIR="${DATA_DIR:-/home/tsz-25/MedCLIPSeg-main/data}"
GPU="${GPU:-0}"; SEED="${SEED:-42}"
STUDY_ID="${STUDY_ID:-JBTL11_BUSI_FACTORIAL100_S${SEED}_$(date +%Y%m%d_%H%M%S)}"
mkdir -p "$PROJECT/logs"
echo "$STUDY_ID" | tee "$PROJECT/JBTL11_ACTIVE_BUSI_FORMAL100.txt"
export QABR_V11_START_STEP="${QABR_V11_START_STEP:-520}"
export QABR_V11_RAMP_STEPS="${QABR_V11_RAMP_STEPS:-130}"
export QABR_V11_UNCERTAINTY_FLOOR="${QABR_V11_UNCERTAINTY_FLOOR:-0.30}"
export QABR_V11_GATE_POWER="${QABR_V11_GATE_POWER:-1.5}"
export QABR_V11_CORR_CLIP="${QABR_V11_CORR_CLIP:-1.25}"
export QABR_V11_CORR_SCALE="${QABR_V11_CORR_SCALE:-0.90}"
export QABR_V11_CENTER_RESIDUAL="${QABR_V11_CENTER_RESIDUAL:-1}"
exec env PROJECT="$PROJECT" PYTHON="$PYTHON" DATA_DIR="$DATA_DIR" GPU="$GPU" SEED="$SEED" STUDY_ID="$STUDY_ID" \
  bash "$PROJECT/scripts/jbtlite/qabr_v11/launch_busi_factorial_valonly100_sequential.sh"
