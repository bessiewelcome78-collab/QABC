#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
DATASET="${DATASET:-BUSI}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
MODE="${MODE:-DIAG20}"
case "${DATASET}" in BUSI|BTMRI|ISIC|Kvasir) ;; *) echo 'DATASET must be BUSI|BTMRI|ISIC|Kvasir'; exit 2;; esac
case "${MODE}" in DIAG20|PAPER100) ;; *) echo 'MODE must be DIAG20|PAPER100'; exit 2;; esac
CONFIG="configs/${DATASET}_SEMLT_POSTERIOR_STABLE_OPERATOR_WARP_${MODE}.yaml"
EXP_ID="${EXP_ID:-PSOMW_${MODE}_${DATASET}_S${SEED}_$(date +%Y%m%d_%H%M%S)}"
RUN_ROOT="${RUN_ROOT:-runs/${EXP_ID}}"
cd "${PROJECT}"
export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"
export TOKENIZERS_PARALLELISM=false
unset PYTORCH_CUDA_ALLOC_CONF 2>/dev/null || true
export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True}"
mkdir -p "${RUN_ROOT}" logs

"${PYTHON}" -c 'import scipy; from scipy.ndimage import distance_transform_edt; print("[PASS] scipy EDT", scipy.__version__)'
"${PYTHON}" -m py_compile \
  utils/semlt_sdf_geometry.py \
  utils/semlt_autozero_transport.py \
  utils/semlt_autozero_loss.py \
  trainers/medclipseg_unimedclip.py \
  train.py
"${PYTHON}" tools/test_semlt_posterior_stable_operator_warp_contract.py
"${PYTHON}" tools/check_semlt_posterior_stable_operator_warp_configs.py
# Archived routes remain reproducible.
"${PYTHON}" tools/test_semlt_sdf_operator_matched_warp_contract.py
"${PYTHON}" tools/test_semlt_boundary_normal_warp_contract.py
"${PYTHON}" tools/test_semlt_lst_v31_rootfix_contract.py
if [[ -f tools/test_semlt_lst_eligible_gate_rootfix_contract.py ]]; then
  "${PYTHON}" tools/test_semlt_lst_eligible_gate_rootfix_contract.py
fi
if [[ -f tools/test_semlt_action_value_policy_contract.py ]]; then
  "${PYTHON}" tools/test_semlt_action_value_policy_contract.py
fi

MIN_FREE_GPU_MIB="${MIN_FREE_GPU_MIB:-43000}"
if command -v nvidia-smi >/dev/null 2>&1; then
  GPU_FREE_MIB="$(nvidia-smi --id="${GPU}" --query-gpu=memory.free --format=csv,noheader,nounits | head -n 1 | tr -d '[:space:]')"
  echo "[GPU PREFLIGHT] gpu=${GPU} free=${GPU_FREE_MIB}MiB required=${MIN_FREE_GPU_MIB}MiB"
  if [[ ! "${GPU_FREE_MIB}" =~ ^[0-9]+$ ]] || (( GPU_FREE_MIB < MIN_FREE_GPU_MIB )); then
    echo "[FAIL] selected GPU is not sufficiently idle for physical batch=24"; exit 3
  fi
fi

echo "[SemLT Posterior-Stable Operator Warp] MODE=${MODE} DATASET=${DATASET} SEED=${SEED}"
echo "[POSTERIOR] official Base remains one stochastic forward; M1 receives detached MC10 probability mean, matching ValMC10 mean-then-refine"
echo "[CONTOUR] half-pixel positive-inside SDF -> one-sided contour owner -> SDF normal"
echo "[TARGET] same-normal GT SDF zero crossing; all valid owners supervised"
echo "[FIELD] owner displacement -> nearest-owner extension -> fixed cosine narrow-band taper; support is prediction-independent"
echo "[OPERATOR] detached Base logits -> continuous velocity field -> physical grid_sample; d=0 is exact identity"
echo "[LOSS] equal-group mean: displacement + fixed-band weighted BCE/global Dice + target-error tangent/Jacobian regularity"
echo "[DIAGNOSTICS] loss-gradient norms/cosines + direction balance/MCC + OracleSign/OracleMagnitude/FullOracle"
echo "[FAIRNESS] MHCS_RNG_ISOLATION=true; from scratch; batch=24 Adam lr=3e-4; Val/Test unopened"
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "${CONFIG}" \
  --seed "${SEED}" \
  --output-dir "${RUN_ROOT}"
echo "[PASS] completed ${MODE}: ${RUN_ROOT}"
