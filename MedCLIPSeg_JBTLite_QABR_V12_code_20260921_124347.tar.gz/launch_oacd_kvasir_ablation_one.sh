#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"

ARM="${ARM:?ARM is required}"
GPU="${GPU:-5}"
SEED="${SEED:-42}"

STUDY_ID="${STUDY_ID:-KVASIR_OACD_ABL100_S42_LOWMEM4_20260902}"

MIN_FREE_MIB="${MIN_FREE_MIB:-29000}"
POLL_SECONDS="${POLL_SECONDS:-60}"

CONFIG="${PROJECT}/configs/ucfnrt_oacd_kvasir_minabl100/${ARM}.yaml"

ARM_ROOT="${PROJECT}/runs/${STUDY_ID}/${ARM}"
TEST_ROOT="${ARM_ROOT}/formal_test"

LOG_ROOT="${PROJECT}/logs/${STUDY_ID}"
TRAIN_LOG="${LOG_ROOT}/${ARM}.train.log"
TEST_LOG="${LOG_ROOT}/${ARM}.test_eval.log"

mkdir -p \
    "${ARM_ROOT}" \
    "${TEST_ROOT}" \
    "${LOG_ROOT}"

cd "${PROJECT}"

export PYTHONPATH="${PROJECT}${PYTHONPATH:+:${PYTHONPATH}}"

export HF_HOME="${PROJECT}/checkpoints"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_DATASETS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false

export PYTORCH_ALLOC_CONF="${PYTORCH_ALLOC_CONF:-expandable_segments:True,max_split_size_mb:128}"

wait_gpu()
{
    while true
    do
        FREE="$(
            nvidia-smi \
              --id="${GPU}" \
              --query-gpu=memory.free \
              --format=csv,noheader,nounits \
            | head -1 \
            | tr -d '[:space:]'
        )"

        UTIL="$(
            nvidia-smi \
              --id="${GPU}" \
              --query-gpu=utilization.gpu \
              --format=csv,noheader,nounits \
            | head -1 \
            | tr -d '[:space:]'
        )"

        echo "[GPU WAIT] physical_gpu=${GPU} free=${FREE:-NA}MiB util=${UTIL:-NA}% required>=${MIN_FREE_MIB}MiB"

        if [[ "${FREE:-}" =~ ^[0-9]+$ ]] && (( FREE >= MIN_FREE_MIB )); then
            echo "[GPU READY] physical_gpu=${GPU} free=${FREE}MiB"
            break
        fi

        sleep "${POLL_SECONDS}"
    done
}

case "${ARM}" in
    A000_JOINT_CONTROL|A011_NO_ALIGN|A101_NO_CDF|A110_NO_REACH|FULL)
        ;;
    *)
        echo "[FAIL] invalid ARM=${ARM}"
        exit 2
        ;;
esac

[[ -f "${CONFIG}" ]] || {
    echo "[FAIL] missing config: ${CONFIG}"
    exit 3
}

echo "===================================================================================================="
echo "KVASIR OACD CONTROLLED ABLATION"
echo "===================================================================================================="
echo "ARM        = ${ARM}"
echo "CONFIG     = ${CONFIG}"
echo "GPU        = ${GPU}"
echo "SEED       = ${SEED}"
echo "ARM_ROOT   = ${ARM_ROOT}"
echo "TEST_ROOT  = ${TEST_ROOT}"
echo "===================================================================================================="

# Runtime contract immediately before touching training.
"${PYTHON}" tools/preflight_oacd_runtime.py \
    --project "${PROJECT}" \
    --config "${CONFIG}" \
    --seed "${SEED}"

wait_gpu

echo
echo "===================================================================================================="
echo "[STAGE 1] TRAIN 100 EPOCHS FROM SCRATCH"
echo "===================================================================================================="

CUDA_VISIBLE_DEVICES="${GPU}" \
"${PYTHON}" -u train.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --data_percentage 100 \
    --output-dir "${ARM_ROOT}" \
    > "${TRAIN_LOG}" 2>&1

echo "[PASS] training completed: ${ARM}"

CKPT_DIR="${ARM_ROOT}/Kvasir/trained_models/seed${SEED}"

mapfile -t CKPTS < <(
    find "${CKPT_DIR}" \
      -maxdepth 1 \
      -type f \
      -name '*_last_epoch.pth' \
      -print
)

if (( ${#CKPTS[@]} != 1 )); then
    echo "[FAIL] expected exactly one physical last-epoch checkpoint"
    echo "CKPT_DIR=${CKPT_DIR}"
    printf '%s\n' "${CKPTS[@]:-}"
    exit 10
fi

CKPT="${CKPTS[0]}"
RUN_NAME="$(basename "${CKPT}" _last_epoch.pth)"

echo
echo "[LOCKED CHECKPOINT]"
echo "CKPT=${CKPT}"
sha256sum "${CKPT}"

# Test must not begin before the physical final checkpoint exists.
wait_gpu

echo
echo "===================================================================================================="
echo "[STAGE 2] ONE-SHOT TEST | MC=30"
echo "===================================================================================================="

CUDA_VISIBLE_DEVICES="${GPU}" \
"${PYTHON}" -u test.py \
    --config-file "${CONFIG}" \
    --seed "${SEED}" \
    --split test \
    --prompt_design original \
    --num-samples 30 \
    --checkpoint "${CKPT}" \
    --output-dir "${TEST_ROOT}" \
    > "${TEST_LOG}" 2>&1

RESULT_ROOT="${TEST_ROOT}/Kvasir/seg_results/seed${SEED}"

echo
echo "===================================================================================================="
echo "[STAGE 3] TRUE-2D + PAPER-LEGACY EVALUATION"
echo "===================================================================================================="

evaluate_one()
{
    local SUFFIX="$1"
    local MODE="$2"
    local CSV="$3"

    "${PYTHON}" -u utils/eval.py \
        --config-file "${CONFIG}" \
        --seed "${SEED}" \
        --split test \
        --output-dir "${TEST_ROOT}" \
        --result-name "${RUN_NAME}_${SUFFIX}" \
        --csv-name "${CSV}" \
        --nsd-mode "${MODE}" \
        >> "${TEST_LOG}" 2>&1
}

evaluate_one \
    BaseNative \
    true2d \
    test_BaseNative_true2d.csv

evaluate_one \
    M1Native \
    true2d \
    test_M1Native_true2d.csv

evaluate_one \
    BaseNative \
    paper_legacy \
    test_BaseNative_paper_legacy.csv

evaluate_one \
    M1Native \
    paper_legacy \
    test_M1Native_paper_legacy.csv

for F in \
    "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
    "${RESULT_ROOT}/test_M1Native_true2d.csv" \
    "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
    "${RESULT_ROOT}/test_M1Native_paper_legacy.csv"
do
    [[ -f "$F" ]] || {
        echo "[FAIL] missing evaluation CSV: $F"
        exit 20
    }
done

echo
echo "===================================================================================================="
echo "[STAGE 4] PAIRED BASE-vs-OACD STATISTICS"
echo "===================================================================================================="

if [[ -f "${PROJECT}/tools/compare_geotr_m1_paired.py" ]]; then

    "${PYTHON}" tools/compare_geotr_m1_paired.py \
        --base-csv "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
        --m1-csv "${RESULT_ROOT}/test_M1Native_true2d.csv" \
        --output-prefix "${RESULT_ROOT}/paired_true2d" \
        --protocol-label "KVASIR_OACD_${ARM}_true2d_seed${SEED}" \
        >> "${TEST_LOG}" 2>&1

    "${PYTHON}" tools/compare_geotr_m1_paired.py \
        --base-csv "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
        --m1-csv "${RESULT_ROOT}/test_M1Native_paper_legacy.csv" \
        --output-prefix "${RESULT_ROOT}/paired_paper_legacy" \
        --protocol-label "KVASIR_OACD_${ARM}_paper_legacy_seed${SEED}" \
        >> "${TEST_LOG}" 2>&1
fi

# -------------------------
# Human-readable final tail.
# -------------------------
echo
echo "===================================================================================================="
echo "[FINAL METRICS] ${ARM}"
echo "===================================================================================================="

grep -E \
'Average DSC|Average NSD|Cases evaluated' \
"${TEST_LOG}" \
| tail -20 || true

{
    echo "ARM=${ARM}"
    echo "DATASET=Kvasir"
    echo "SEED=${SEED}"
    echo "CHECKPOINT=${CKPT}"
    echo "CHECKPOINT_SHA256=$(sha256sum "${CKPT}" | awk '{print $1}')"
    echo "COMPLETED_AT=$(date -Is)"
} > "${ARM_ROOT}/SUCCESS.lock"

echo
echo "[PASS] ${ARM} TRAIN -> LAST EPOCH -> MC30 TEST -> EVAL COMPLETE"
echo "SUCCESS=${ARM_ROOT}/SUCCESS.lock"
