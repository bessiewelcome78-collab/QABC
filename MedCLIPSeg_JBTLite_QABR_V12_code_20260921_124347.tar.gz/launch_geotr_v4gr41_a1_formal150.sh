#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"; cd "${PROJECT}" || exit 1
GPU="${GPU:-0}"; SEED="${SEED:-42}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
export TOKENIZERS_PARALLELISM=false
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs runs
LOG="logs/GEOTR_V4GR41_A1_FORMAL150_seed${SEED}_gpu${GPU}_${STAMP}.log"
PYTHONPATH=. "${PYTHON}" tools/test_geotr_v4gr41_contract.py
PYTHONPATH=. "${PYTHON}" tools/check_geotr_v4gr41_configs.py
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file configs/BUSI_GEOTR_V4GR41_A1_FORMAL150.yaml \
  --seed "${SEED}" \
  --output-dir "runs/GEOTR_V4GR41_A1_FORMAL150_seed${SEED}_${STAMP}" \
  2>&1 | tee "${LOG}"
echo "[PASS] GEOTR V4G-R4.1 A1 FORMAL150 finished: ${LOG}"
