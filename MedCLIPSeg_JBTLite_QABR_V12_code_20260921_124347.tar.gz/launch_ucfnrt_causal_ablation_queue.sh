#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"; PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
GPU="${GPU:?GPU required}"; SEED="${SEED:-42}"; ROOT_ID="${ROOT_ID:?ROOT_ID required}"
DATASETS="${DATASETS:?space-separated DATASETS required}"; VARIANTS="${VARIANTS:-NO_POSTERIOR NO_RAY DIRECT_SIGNED SEG_ONLY}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"; POLL_SECONDS="${POLL_SECONDS:-60}"
cd "$PROJECT"; mkdir -p logs
if command -v flock >/dev/null 2>&1; then exec 8>"${PROJECT}/.ucfnrt_causal_ablation_queue_gpu${GPU}.lock"; flock -n 8 || { echo "[FAIL] queue lock busy GPU$GPU"; exit 2; }; fi
wait_gpu(){
  while true; do
    local free; free="$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | awk -F',' -v g="$GPU" '$1+0==g{gsub(/ /,"",$2);print $2;exit}')"
    [[ -n "$free" ]] || { echo "[FAIL] GPU$GPU missing"; exit 3; }
    if (( free >= MIN_FREE_MIB )); then echo "[READY] GPU$GPU free=${free}MiB"; return; fi
    echo "[WAIT] GPU$GPU free=${free}MiB < ${MIN_FREE_MIB}MiB; sleeping ${POLL_SECONDS}s"
    sleep "$POLL_SECONDS"
  done
}
for ds in $DATASETS; do
  for var in $VARIANTS; do
    wait_gpu
    echo "[QUEUE RUN] GPU$GPU $ds $var"
    PROJECT="$PROJECT" PYTHON="$PYTHON" DATASET="$ds" VARIANT="$var" GPU="$GPU" SEED="$SEED" ROOT_ID="$ROOT_ID" MIN_FREE_MIB="$MIN_FREE_MIB" QUEUE_LOCK_HELD=1 bash launch_ucfnrt_causal_ablation_train_one.sh
  done
done
Q="${PROJECT}/runs/UCFNRT_CAUSAL_ABL_${ROOT_ID}/seed${SEED}/QUEUE_GPU${GPU}_TRAIN_SUCCESS.lock"; mkdir -p "$(dirname "$Q")"; date --iso-8601=seconds > "$Q"
echo "[PASS] GPU$GPU training queue complete"
