#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
cd "${PROJECT}" || exit 1
GPU="${GPU:-0}"
SEED="${SEED:-42}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
export TOKENIZERS_PARALLELISM=false
STAMP="$(date +%Y%m%d_%H%M%S)"
mkdir -p logs runs
LOG="logs/GEOTR_V4GR3_A3_DIAG10_seed${SEED}_gpu${GPU}_${STAMP}.log"
"${PYTHON}" tools/test_geotr_v4gr3_contract.py
"${PYTHON}" tools/check_geotr_v4gr3_configs.py
CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u train.py \
  --config-file "configs/BUSI_GEOTR_V4GR3_A3_DIAG10.yaml" \
  --seed "${SEED}" \
  --output-dir "runs/GEOTR_V4GR3_A3_DIAG10_seed${SEED}_${STAMP}" \
  2>&1 | tee "${LOG}"
"${PYTHON}" tools/diagnose_geotr_v4gr3_log.py "${LOG}" || true
echo "[PASS] GEOTR V4G-R3 A3 DIAG10 finished: ${LOG}"
