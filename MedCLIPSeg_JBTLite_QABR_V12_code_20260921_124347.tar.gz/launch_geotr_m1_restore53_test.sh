#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
PYTHON="${PYTHON:-python}"
GPU="${GPU:-0}"
SEED="${SEED:-42}"
RUN_TAG="${RUN_TAG:-GEOTR_M1_RESTORE53_FORMAL150}"
CHECKPOINT="${CHECKPOINT:-}"
TEST_OUTPUT_DIR="${TEST_OUTPUT_DIR:-}"
CONFIG_FILE="${CONFIG_FILE:-configs/BUSI_GEOTR_M1_RESTORE53.yaml}"
FORMAL_PROTOCOL="${FORMAL_PROTOCOL:-restore150}"
[[ -n "${CHECKPOINT}" ]] || { echo "[FAIL] set CHECKPOINT to the pre-declared formal checkpoint"; exit 2; }
[[ -f "${CHECKPOINT}" ]] || { echo "[FAIL] checkpoint not found: ${CHECKPOINT}"; exit 2; }
[[ -f "${CONFIG_FILE}" ]] || { echo "[FAIL] test config not found: ${CONFIG_FILE}"; exit 2; }
cd "${PROJECT}"
export TOKENIZERS_PARALLELISM=false

PYTHON="${PYTHON}" PROJECT="${PROJECT}" bash launch_geotr_m1_restore53_preflight.sh
"${PYTHON}" tools/check_geotr_m1_formal54_protocol.py \
  --config-file "${CONFIG_FILE}" --protocol "${FORMAL_PROTOCOL}"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT="${TEST_OUTPUT_DIR:-test_results/${RUN_TAG}_seed${SEED}_${STAMP}}"
mkdir -p "${OUT}"

echo "[TEST] protocol=${FORMAL_PROTOCOL} config=${CONFIG_FILE} checkpoint=${CHECKPOINT}"

CUDA_VISIBLE_DEVICES="${GPU}" "${PYTHON}" -u test.py \
  --config-file "${CONFIG_FILE}" \
  --seed "${SEED}" --split test --num-samples 1 \
  --checkpoint "${CHECKPOINT}" --output-dir "${OUT}" \
  M1.RUN_TAG "${RUN_TAG}" TRAIN.RUN_TAG "${RUN_TAG}"

RUN_NAME="MedCLIPSeg_unimedclip_ViT-B-16_${RUN_TAG}"
RESULT_ROOT="${OUT}/BUSI/seg_results/seed${SEED}"
BASE_RESULT="${RUN_NAME}_BaseNative"
M1_RESULT="${RUN_NAME}_M1Native"

evaluate_one() {
  local result_name="$1"
  local csv_name="$2"
  local nsd_mode="$3"
  "${PYTHON}" -u utils/eval.py \
    --config-file "${CONFIG_FILE}" \
    --seed "${SEED}" --split test --output-dir "${OUT}" \
    --result-name "${result_name}" --csv-name "${csv_name}" \
    --nsd-mode "${nsd_mode}" \
    M1.RUN_TAG "${RUN_TAG}" TRAIN.RUN_TAG "${RUN_TAG}"
}

evaluate_one "${BASE_RESULT}" test_BaseNative_true2d.csv true2d
evaluate_one "${M1_RESULT}" test_M1Native_true2d.csv true2d
evaluate_one "${BASE_RESULT}" test_BaseNative_paper_legacy.csv paper_legacy
evaluate_one "${M1_RESULT}" test_M1Native_paper_legacy.csv paper_legacy

"${PYTHON}" -u tools/compare_geotr_m1_paired.py \
  --base-csv "${RESULT_ROOT}/test_BaseNative_true2d.csv" \
  --m1-csv "${RESULT_ROOT}/test_M1Native_true2d.csv" \
  --output-prefix "${RESULT_ROOT}/paired_true2d" \
  --protocol-label "corrected_true_2d_nsd"

"${PYTHON}" -u tools/compare_geotr_m1_paired.py \
  --base-csv "${RESULT_ROOT}/test_BaseNative_paper_legacy.csv" \
  --m1-csv "${RESULT_ROOT}/test_M1Native_paper_legacy.csv" \
  --output-prefix "${RESULT_ROOT}/paired_paper_legacy" \
  --protocol-label "reference_paper_singleton_depth_nsd" \
  --benchmark-json benchmarks/medclipseg_cvpr2026_busi_full.json

echo "[PASS] GEOTR-M1 one-shot Test and paired evaluation finished"
echo "       OUT=${OUT}"
echo "       STRICT_REPORT=${RESULT_ROOT}/paired_true2d.md"
echo "       PAPER_REPORT=${RESULT_ROOT}/paired_paper_legacy.md"
