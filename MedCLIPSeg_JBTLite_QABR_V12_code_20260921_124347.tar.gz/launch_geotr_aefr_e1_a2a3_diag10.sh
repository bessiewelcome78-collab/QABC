#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"; cd "${PROJECT}" || exit 1
SEED="${SEED:-42}"; GPU_A2="${GPU_A2:-2}"; GPU_A3="${GPU_A3:-3}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs
GPU="${GPU_A2}" SEED="${SEED}" bash launch_geotr_aefr_e1_a2_diag10.sh > "logs/GEOTR_AEFR_E1_A2_driver_${STAMP}.log" 2>&1 & P2=$!
GPU="${GPU_A3}" SEED="${SEED}" bash launch_geotr_aefr_e1_a3_diag10.sh > "logs/GEOTR_AEFR_E1_A3_driver_${STAMP}.log" 2>&1 & P3=$!
FAIL=0; wait "$P2" || FAIL=1; wait "$P3" || FAIL=1
[[ "$FAIL" == 0 ]] || { echo "[ERROR] GEOTR-AEFR E1 A2/A3 failed"; exit 1; }
echo "[PASS] GEOTR-AEFR E1 A2+A3 DIAG10 finished"
