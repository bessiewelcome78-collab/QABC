#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
cd "${PROJECT}" || exit 1
SEED="${SEED:-42}"; GPU_A2="${GPU_A2:-2}"; GPU_A3="${GPU_A3:-3}"
STAMP="$(date +%Y%m%d_%H%M%S)"; mkdir -p logs
GPU="${GPU_A2}" SEED="${SEED}" bash launch_geotr_v4gr4_a2_diag10.sh > "logs/GEOTR_V4GR4_A2_DIAG10_driver_${STAMP}.log" 2>&1 & P2=$!
GPU="${GPU_A3}" SEED="${SEED}" bash launch_geotr_v4gr4_a3_diag10.sh > "logs/GEOTR_V4GR4_A3_DIAG10_driver_${STAMP}.log" 2>&1 & P3=$!
FAIL=0
wait "$P2" || FAIL=1
wait "$P3" || FAIL=1
if [[ "$FAIL" != 0 ]]; then
  echo "[ERROR] one or more GEOTR V4G-R4 DIAG10 runs failed"
  echo "  logs/GEOTR_V4GR4_A2_DIAG10_driver_${STAMP}.log"
  echo "  logs/GEOTR_V4GR4_A3_DIAG10_driver_${STAMP}.log"
  exit 1
fi
echo "[PASS] GEOTR V4G-R4 A2+A3 DIAG10 finished"
