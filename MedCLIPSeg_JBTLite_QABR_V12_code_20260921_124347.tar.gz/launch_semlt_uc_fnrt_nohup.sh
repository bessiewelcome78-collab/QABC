#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
DATASET="${DATASET:-BUSI}"; GPU="${GPU:-0}"; SEED="${SEED:-42}"; MODE="${MODE:-DIAG20}"
cd "${PROJECT}"
EXP_ID="UCFNRT_${MODE}_${DATASET}_S${SEED}_$(date +%Y%m%d_%H%M%S)"
LOG="${PROJECT}/logs/${EXP_ID}.log"; RUN_ROOT="${PROJECT}/runs/${EXP_ID}"
mkdir -p "${PROJECT}/logs" "${RUN_ROOT}"
nohup env PROJECT="${PROJECT}" PYTHON="${PYTHON}" DATASET="${DATASET}" GPU="${GPU}" SEED="${SEED}" MODE="${MODE}" EXP_ID="${EXP_ID}" RUN_ROOT="${RUN_ROOT}" bash launch_semlt_uc_fnrt.sh >"${LOG}" 2>&1 &
PID=$!
echo "PID=${PID}"; echo "LOG=${LOG}"; echo "RUN_ROOT=${RUN_ROOT}"; echo "tail -f ${LOG}"
