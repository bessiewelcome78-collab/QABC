#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-/home/tsz-25/MedCLIPSeg-pristine}"
PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
SEED="${SEED:-42}"
GPUS="${GPUS:-0,1,2,3,4,5}"
ROOT_ID="${ROOT_ID:-$(date +%Y%m%d_%H%M%S)}"
MIN_FREE_MIB="${MIN_FREE_MIB:-43000}"
IFS=',' read -r -a GPU_ARR <<< "$GPUS"
VARIANTS=(C0_ORIGINAL C1_RELATIVE_U_ONLY C2_NORMALIZED_RAY_ONLY C3_AGREEMENT_APPLY_ONLY C4_AGREEMENT_DIAG_ONLY F1_DIRECT_SIGNED)
if (( ${#GPU_ARR[@]} != ${#VARIANTS[@]} )); then
  echo "[FAIL] GPUS must provide exactly ${#VARIANTS[@]} physical GPU ids; got ${#GPU_ARR[@]}"
  exit 2
fi
cd "$PROJECT"; mkdir -p logs
# All-or-nothing preflight to avoid a partially launched causal matrix.
for i in "${!VARIANTS[@]}"; do
  gpu="${GPU_ARR[$i]}"; variant="${VARIANTS[$i]}"
  free="$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | awk -F',' -v g="$gpu" '$1+0==g{gsub(/ /,"",$2);print $2;exit}')"
  [[ -n "$free" ]] || { echo "[FAIL] GPU$gpu not found"; exit 3; }
  echo "[PREFLIGHT] $variant GPU$gpu free=${free}MiB"
  (( free >= MIN_FREE_MIB )) || { echo "[FAIL] GPU$gpu free=${free} < $MIN_FREE_MIB"; exit 4; }
done
MASTER="$PROJECT/logs/UCFNRT_ROOTCAUSE_A2_${ROOT_ID}_MATRIX.master.log"
: > "$MASTER"
echo "ROOT_ID=$ROOT_ID" | tee -a "$MASTER"
for i in "${!VARIANTS[@]}"; do
  gpu="${GPU_ARR[$i]}"; variant="${VARIANTS[$i]}"
  log="$PROJECT/logs/UCFNRT_ROOTCAUSE_A2_${ROOT_ID}_${variant}_launcher.log"
  nohup env PROJECT="$PROJECT" PYTHON="$PYTHON" GPU="$gpu" VARIANT="$variant" SEED="$SEED" ROOT_ID="$ROOT_ID" MIN_FREE_MIB="$MIN_FREE_MIB" \
    bash "$PROJECT/launch_ucfnrt_rootcause_diag20_one.sh" > "$log" 2>&1 &
  pid=$!
  echo "$variant GPU=$gpu PID=$pid LOG=$log" | tee -a "$MASTER"
done
echo "[PASS] submitted complete 6-way TRAIN-only matrix" | tee -a "$MASTER"
echo "Monitor: tail -f $MASTER"
echo "After completion: $PYTHON tools/collect_ucfnrt_rootcause_diag20.py --root-id $ROOT_ID --seed $SEED"
