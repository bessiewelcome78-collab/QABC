#!/usr/bin/env bash
set -Eeuo pipefail
PROJECT="${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"; PYTHON="${PYTHON:-/home/tsz-25/miniconda3/envs/py3.10torch2.9.1cu128/bin/python}"
SEED="${SEED:-42}"; EXP_ID="${EXP_ID:-AUTOZERO_$(date +%Y%m%d_%H%M%S)}"; GPUS="${GPUS:-0,1,2,3}"
IFS=',' read -r -a G <<< "${GPUS}"; [[ ${#G[@]} -eq 4 ]] || { echo '[FAIL] GPUS needs 4 ids'; exit 2; }
DATASETS=(BUSI BTMRI ISIC Kvasir); mkdir -p "${PROJECT}/logs"; PIDS=()
for i in 0 1 2 3; do ds="${DATASETS[$i]}"; gpu="${G[$i]}"; echo "[LAUNCH] ${ds} seed=${SEED} gpu=${gpu}"; \
 PROJECT="${PROJECT}" PYTHON="${PYTHON}" DATASET="${ds}" GPU="${gpu}" SEED="${SEED}" EXP_ID="${EXP_ID}" bash "${PROJECT}/launch_semlt_autozero_one_dataset_train.sh" \
 > "${PROJECT}/logs/SEMLT_AUTOZERO_MASTER_${ds}_seed${SEED}_${EXP_ID}.log" 2>&1 & PIDS+=("$!"); done
status=0; for i in 0 1 2 3; do wait "${PIDS[$i]}" || status=1; done; exit "${status}"
