#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${PROJECT:-${SCRIPT_DIR}}"
PYTHON="${PYTHON:-python3}"
DATASETS="${DATASETS:-BUSI Kvasir ISIC}"
CONFIG_DIR="${PROJECT}/configs/semlt_ablation_3gpu_v1"
read -r -a datasets <<< "${DATASETS}"
[[ ${#datasets[@]} -eq 3 ]] || { echo "[FAIL] DATASETS must contain exactly three names" >&2; exit 2; }
command -v "${PYTHON}" >/dev/null 2>&1 || { echo "[FAIL] PYTHON not found: ${PYTHON}" >&2; exit 2; }

cd "${PROJECT}"
for script in \
  launch_semlt_ablation_one_dataset_sequential_v1.sh \
  launch_semlt_ablation_one_dataset_test_sequential_v1.sh \
  launch_semlt_ablation_3datasets_3gpu_v1.sh \
  launch_semlt_ablation_base_one.sh \
  launch_semlt_ablation_variant_one.sh; do
  [[ -f "${script}" ]] || { echo "[FAIL] missing ${script}" >&2; exit 2; }
  bash -n "${script}"
done

"${PYTHON}" - "${CONFIG_DIR}" "${DATASETS}" <<'PY'
import json
import sys
from pathlib import Path
import yaml

config_dir = Path(sys.argv[1])
datasets = sys.argv[2].split()
expected_variants = [
    "A1_REWRITE", "A2_PROB", "A3_NORMAL1D",
    "A4_FREE2D", "A5_SUPPORT", "A6_SEMLT",
]
spec = json.loads((config_dir / "LOCKED_VARIANTS.json").read_text(encoding="utf-8"))
assert spec["protocol"] == "SemLT_locked_causal_ablation_v1"
assert list(spec["variants"]) == expected_variants
reference_base = reference_variant = None
for dataset in datasets:
    base = yaml.safe_load((config_dir / f"{dataset}_BASE100.yaml").read_text(encoding="utf-8"))
    variant = yaml.safe_load((config_dir / f"{dataset}_VARIANTS100.yaml").read_text(encoding="utf-8"))
    for cfg in (base, variant):
        assert cfg["DATASET"]["NAME"] == dataset
        assert cfg["DATASET"]["TRAIN_PATH"] == f"./data/{dataset}/Train_Folder/"
        assert cfg["DATASET"]["VAL_PATH"] == f"./data/{dataset}/Val_Folder/"
        assert cfg["DATASET"]["TEST_PATH"] == f"./data/{dataset}/Test_Folder/"
        assert cfg["DATASET"]["TEXT_PROMPT_PATH"] == f"./data/{dataset}/Prompts_Folder/"
        assert int(cfg["TRAIN"]["NUM_EPOCHS"]) == 100
        assert int(cfg["TRAIN"]["SCHEDULER_TOTAL_EPOCHS"]) == 100
        assert cfg["TRAIN"]["USE_VALIDATION_SELECTION"] is False
    assert base["M1"]["ENABLED"] is False
    assert variant["M1"]["ENABLED"] is True
    assert variant["M1"]["GEOTR_M1_CAUSAL_ABLATION"] is True
    assert variant["M1"]["V469_FREEZE_BASE"] is True
    assert variant["M1"]["GEOTR_M1_DETACH_CONDITIONERS"] is True
    base_science = dict(base); base_science.pop("DATASET")
    variant_science = dict(variant); variant_science.pop("DATASET")
    if reference_base is None:
        reference_base, reference_variant = base_science, variant_science
    else:
        assert base_science == reference_base, f"Base protocol drift for {dataset}"
        assert variant_science == reference_variant, f"variant protocol drift for {dataset}"
print("[PASS] six YAML configs and locked A1-A6 spec are consistent")
PY

for dataset in "${datasets[@]}"; do
  case "${dataset}" in BUSI|Kvasir|ISIC) ;; *) echo "[FAIL] unsupported dataset ${dataset}" >&2; exit 2;; esac
  for path in Train_Folder Val_Folder Test_Folder Prompts_Folder; do
    [[ -e "data/${dataset}/${path}" ]] || { echo "[FAIL] missing data/${dataset}/${path}" >&2; exit 2; }
  done
done
for path in checkpoints/unimed_clip_vit_b16.pt checkpoints/BiomedBERT-base-uncased-abstract; do
  [[ -e "${path}" ]] || { echo "[FAIL] missing checkpoint/resource ${path}" >&2; exit 2; }
done
echo "[PASS] three-dataset 3-GPU ablation preflight complete"
